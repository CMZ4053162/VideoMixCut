# -*- coding: utf-8 -*-
"""VideoMixCut 智能混剪 - 图形界面 (tkinter 深色高级版, 无额外依赖)
用法: 双击 启动.exe / 一键出片界面.bat, 或 pythonw mixcut_gui.py
"""
import os
import re
import json
import sys
import subprocess
import threading
import queue
import time
import random
import tkinter as tk
from tkinter import ttk, filedialog, messagebox

import activation
import updater

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
os.chdir(BASE_DIR)
APP_VERSION = updater.load_config(BASE_DIR).get("version", "")

# ---------- 设计变量 ----------
BG = "#0e1116"        # 窗口底
CARD = "#161b24"      # 卡片底
CARD2 = "#1b2130"     # 次级底/状态栏
BORDER = "#252d3d"    # 卡片描边
INPUT_BG = "#0b0e13"  # 输入框底
TEXT = "#e9edf5"      # 主文字
MUTED = "#7f8a9e"     # 次文字
ACCENT = "#ff6a3d"    # 品牌橙
ACCENT_DK = "#d9501f"
GREEN = "#3fd07c"
YELLOW = "#e8c35a"
LOG_BG = "#0a0d12"
FONT = "Microsoft YaHei UI"


def find_backend_python():
    """后端(混剪)解释器: 发行包便携运行时 -> 虚拟环境 -> 当前解释器。

    Windows 下每个候选都优先用同目录的 pythonw.exe: 后台步骤是无界面任务,
    不需要控制台; 而且本机 python.exe 无 -S 启动会卡死 (tkinter/site 初始化),
    pythonw 不会。找不到 pythonw 时退回原解释器 (客户端机器上 python.exe 不卡)。
    """
    cand = [
        os.path.join(BASE_DIR, "runtime", "python.exe"),
        r"C:\Users\zz6688\.workbuddy\binaries\python\envs\default\Scripts\python.exe",
        os.path.join(BASE_DIR, "venv", "Scripts", "python.exe"),
    ]

    def pick(exe):
        if os.name == "nt" and exe.lower().endswith("python.exe"):
            pw = exe[:-len("python.exe")] + "pythonw.exe"
            if os.path.exists(pw):
                return pw
        return exe

    for p in cand:
        if os.path.exists(p):
            return pick(p)
    return pick(sys.executable)


def backend_script():
    """后端脚本: 发行包用编译后的 .pyc (更新包覆盖即生效), 退回源码 .py"""
    for n in ("mixcut_tool.pyc", "mixcut_tool.py"):
        p = os.path.join(BASE_DIR, n)
        if os.path.exists(p):
            return p
    return os.path.join(BASE_DIR, "mixcut_tool.py")


def style_widget(root):
    """深色主题: clam 引擎 + 全套控件样式"""
    st = ttk.Style(root)
    try:
        st.theme_use("clam")
    except Exception:
        pass
    st.configure(".", background=BG, foreground=TEXT, font=(FONT, 10))
    st.configure("TFrame", background=BG)
    st.configure("Card.TFrame", background=CARD)
    st.configure("TLabel", background=BG, foreground=TEXT)
    st.configure("Card.TLabel", background=CARD, foreground=TEXT)
    st.configure("Muted.TLabel", background=BG, foreground=MUTED)
    st.configure("CardMuted.TLabel", background=CARD, foreground=MUTED)
    st.configure("TEntry", fieldbackground=INPUT_BG, foreground=TEXT,
                 bordercolor=BORDER, lightcolor=BORDER, darkcolor=BORDER,
                 insertcolor=TEXT, padding=4)
    st.map("TEntry", bordercolor=[("focus", ACCENT)])
    st.configure("TCombobox", fieldbackground=INPUT_BG, foreground=TEXT,
                 background=CARD2, arrowcolor=MUTED, bordercolor=BORDER,
                 lightcolor=BORDER, darkcolor=BORDER, padding=3)
    st.map("TCombobox",
           fieldbackground=[("readonly", INPUT_BG)],
           bordercolor=[("focus", ACCENT)])
    root.option_add("*TCombobox*Listbox.background", CARD2)
    root.option_add("*TCombobox*Listbox.foreground", TEXT)
    root.option_add("*TCombobox*Listbox.selectBackground", ACCENT_DK)
    root.option_add("*TCombobox*Listbox.selectForeground", "#ffffff")
    st.configure("TSpinbox", fieldbackground=INPUT_BG, foreground=TEXT,
                 background=CARD2, arrowcolor=MUTED, bordercolor=BORDER,
                 lightcolor=BORDER, darkcolor=BORDER, padding=3)
    st.configure("TRadiobutton", background=CARD, foreground=TEXT,
                 focuscolor=CARD, lightcolor=MUTED, darkcolor=MUTED)
    st.map("TRadiobutton", background=[("active", CARD)])
    st.configure("Horizontal.TProgressbar", background=ACCENT,
                 troughcolor=INPUT_BG, bordercolor=BG,
                 lightcolor=ACCENT, darkcolor=ACCENT_DK, thickness=6)
    st.configure("TCheckbutton", background=CARD, foreground=TEXT)
    return st


def hover_button(btn, normal, hover):
    btn.bind("<Enter>", lambda e: btn.configure(bg=hover))
    btn.bind("<Leave>", lambda e: btn.configure(bg=normal))


FEATURES_DOC = [
    ("t", "■ 项目管理 (多项目并行)"),
    ("h", "一个项目 = 一套素材 + 一套参数 + 自己的成片:  打开软件先进「项目管理」列表, 点【+ 新建项目】起名并选素材文件夹。每个项目双击后是**独立窗口**, 可以同时开好几个项目、各自出片互不干扰; 参数(素材/BGM/贴纸/数量/硬件加速等)改动自动保存, 下次打开还是上次的设置。"),
    ("h", "复制/重命名/删除:  复制=照搬现有项目参数建新项目(换素材就能跑第二组); 删除时可选择是否连成片一起删(默认只删项目配置, 成片保留)。项目数据存在 软件目录/projects/ 下, 每个项目自己的 data(扫描/字幕/分段) 与 output(成片) 完全独立。"),
    ("t", "■ 硬件加速 (出片速度)"),
    ("h", "开机自动体检:  软件每次打开会先检测这台电脑的配置(显卡型号/CPU核数/内存), 并在日志第一行写明用了什么方案, 比如「NVIDIA GeForce RTX 2060 · 12核 · 31.8GB -> 显卡编码(N卡 NVENC)」。不同电脑自动选不同的最快方案, 不用手动调。"),
    ("h", "自动适配规则:  依次尝试 N卡 NVENC → Intel核显 QSV → A卡 AMF → 都没有就用 CPU。实测速度: N卡显卡编码比纯 CPU 快约 4-6 倍(画质一样, PSNR 43dB 无差别); Intel 核显也能快约 2 倍。没有显卡的老机器自动回落 CPU, 成片效果完全一样, 只是慢一些。"),
    ("h", "硬件加速:  自动=按体检结果选(默认, 推荐); 显卡=强制用显卡; CPU=只用CPU(显卡忙或想省电时选)。换电脑/换显卡/更新驱动后, 可在 帮助→重新检测本机硬件配置 让它重新认一次。"),
    ("t", "■ 项目类型: 混剪 / 提取"),
    ("h", "新建项目时可以选类型: 混剪项目 = 素材文件夹 → 出成片; 提取项目 = 一批链接 → 无水印素材。两种项目都在项目列表里, 每行的●标记显示当前状态: 灰=未开始/就绪, 橙=待提取, 黄=运行中, 红=有问题(几条失败), 绿=已完成。"),
    ("h", "提取项目窗口: 粘贴链接(整段抖音分享文字也行, 自动抽链接)一条条加进来, 或从 TXT 批量导入; 每条一行显示状态(等待中/提取中/完成/失败), 点【开始提取】后逐条跑, 状态实时更新并自动保存, 关掉窗口下次打开还在。失败的那条会写明原因, 可以单独重跑。"),
    ("t", "■ 素材获取"),
    ("h", "链接提取:  没素材时, 把抖音/B站/西瓜/小红书/快手/YouTube 的分享链接(或整段分享文字)粘进「链接提取」框点提取——直接拿无水印视频, 自动存进素材文件夹, 提取完点【开始出片】就能混剪。支持 TXT 批量(多个链接放文本里), 已提取过的自动跳过。首次使用会自动装组件(需联网, 约1分钟)。"),
    ("h", "口播文案提取:  勾选「同时提取口播文案」后, 每条视频下载完自动 OCR 识别字幕, 文案存 素材文件夹/文案/ 下, 可直接参考改写。"),
    ("t", "■ 出片设置"),
    ("h", "出片数量:  一次出几条。每条都是独立的随机方案——分段、顺序、文案、画面参数、BGM 全都不同, 条条可用于去重发布。"),
    ("h", "目标时长:  自动=完整结构(9段, 约60-80秒); 30秒=精简版(5段)适合冲完播率; 45/60秒介于两者。段落数量随目标收缩。"),
    ("h", "段间转场:  无=直接切换(节奏快); 溶解=每段切换处0.15秒柔和过渡, 跳脸感更小, 但整体节奏稍缓。"),
    ("t", "■ 主播与叙事"),
    ("h", "音色:  随机=不限制谁出镜(默认); 同主播=同一条片尽量用同一个人的素材, 像原生一条视频; 换主播=每段强制换人, 去重信号最强但跳人感明显。"),
    ("h", "过渡句:  开=在话题切换处(如卖点之间)自动插入一句现成的转场口播(\"再来看\"/\"接下来\"), 叙事更顺。素材里没有这类句子时会提示跳过——多录几句即可。"),
    ("h", "空镜遮切换(B-roll):  在换人切换的瞬间, 画面切到产品空镜0.7秒再切回来, 人声不断——专业混剪的标准手法, 跳脸突兀感基本消失。把产品特写/安装过程等纯画面短视频(不用说话, 每条3秒以上)放进软件目录 build/broll/ 即自动启用。"),
    ("h", "字幕条:  品牌=给成片叠加统一的底部黑条白字字幕, 文字跟随每段口播。作用: ①盖住源视频字幕被切半句的问题 ②统一视觉。无=不加。"),
    ("t", "■ 画面与去重"),
    ("h", "贴纸:  cute=随机可爱卡通贴纸(太阳/星星/爱心/闪光/礼物/火苗, 程序绘制零版权); ai=AI按文案智能选卖点标签; zhongqiu=中秋角标; universal=通用带货徽章(限时特惠/正品保障等8款, 每条随机换+四角轮换); watermark=自定义文字水印; none=不加。"),
    ("h", "风格:  画面参数套数(调色/缩放/画中画)。自动=批量时随机轮换9套, 每条观感不同。"),
    ("h", "镜像:  画面左右翻转, 去重信号强。但源视频内嵌字幕会反字, 所以默认\"自动\"=不翻转; 介意字幕又想去重时再手动\"开启\"。"),
    ("t", "■ 音乐"),
    ("h", "BGM:  原片BGM都会自动去掉只留人声。随机曲库=每条从内置多风格曲库(欢快/舒缓/科技/可爱/励志/动感 6种程序合成免版权)随机选(每条不同, 不再单调); 合成BGM=默认欢快曲; 本地音乐=自己指定; 只留人声=不加配乐。还可在「画面与去重」里点「联网获取素材」下载更多可商用BGM。"),
    ("t", "■ 质量保障(自动进行, 无需设置)"),
    ("b", "句子完整性:  切点自动吸附到说话的自然停顿, 话没说完会延长到说完才切。"),
    ("b", "开头不重样:  批量时每条开头强制轮换, 同一句钩子(哪怕不同人念)不会在两条里重复。"),
    ("b", "数字一致性:  同一条片里\"3合一\"和\"5合一\"这种自相矛盾会自动重新生成。"),
    ("b", "逐段响度归一:  不同主播录音音量自动拉平, 不会忽大忽小。"),
    ("b", "成片回读:  出片后抽帧识别成片字幕与方案比对, 发现错位自动报警。"),
    ("b", "三重自检:  文案(重复/截断) + 画面(黑屏/卡帧) + 音频(静音/爆音)。"),
    ("t", "■ 智能辅助"),
    ("h", "AI优化素材库:  点一下, AI 把素材库每个分段审一遍——归错库的挪正(比如该当开头的被放在卖点里)、质量打分、低质段(半句/脏字/空洞)不再选用、高分段优先。结果缓存, 之后每次出片自动生效; 新增素材后重跑一次即可。需配置 AI 密钥(免费)。"),
    ("h", "AI选段:  开=出方案这一步交给 AI——把开头/卖点/结尾三个素材库的候选文案发给大模型, 由它按叙事逻辑组合每一条的方案(开头不重样/卖点有顺序/话题不重复), 比纯规则打分更\"懂文案\"。失败或没配密钥自动回退规则选段, 不影响出片。需先在 帮助→AI 审片设置 里配置(免费)。"),
    ("h", "AI审片:  开=两层质检——①方案评审: 每条的分段文案交 AI 评叙事连贯/卖点顺序/矛盾, 打分列问题; ②成片终审: 出片后提取成片实际字幕全文, AI 通读找多余字/错字/半句话/逻辑混乱, 有硬伤的分段自动拉黑, 下次生成自动避开(越用越稳)。报告存 build/ai_report.txt。未配置时自动跳过。密钥只存你自己电脑。"),
    ("h", "自动封面:  开=每条成片自动生成封面图(成片名_封面.jpg): 抽取 25% 处画面 + 顶部钩子大字描边 + 品牌贴纸, 发视频时直接可用。"),
    ("h", "画面相似检测(自动):  每段抽帧算视觉指纹, 相邻两段画面太像(同机位连播)会自动换段, 防止\"同一个缸连续讲两段\"的观感。"),
    ("w", "\n提示: 建议先把「同主播+过渡句+空镜」都试一遍对比效果; build/broll/ 空镜素材越丰富, 遮盖效果越好。"),
]

# AI 审片平台预设: (显示名, 接口地址, 模型名, 密钥领取页)
AI_PRESETS = [
    ("智谱GLM (有免费模型, 推荐)", "https://open.bigmodel.cn/api/paas/v4",
     "glm-4-flash", "https://open.bigmodel.cn/usercenter/apikeys"),
    ("DeepSeek (便宜好用)", "https://api.deepseek.com/v1",
     "deepseek-chat", "https://platform.deepseek.com/api_keys"),
    ("Kimi月之暗面", "https://api.moonshot.cn/v1",
     "moonshot-v1-8k", "https://platform.moonshot.cn/console/api-keys"),
    ("通义千问", "https://dashscope.aliyuncs.com/compatible-mode/v1",
     "qwen-turbo", "https://bailian.console.aliyun.com/?apiKey=1#/api-key"),
    ("OpenAI官方", "https://api.openai.com/v1",
     "gpt-4o-mini", "https://platform.openai.com/api-keys"),
]


def load_llm_cfg():
    import json
    try:
        return (json.load(open(os.path.join(BASE_DIR, "config.json"),
                               encoding="utf-8")).get("llm")) or {}
    except (OSError, ValueError):
        return {}


def save_llm_cfg(cfg):
    import json
    p = os.path.join(BASE_DIR, "config.json")
    try:
        full = json.load(open(p, encoding="utf-8"))
    except (OSError, ValueError):
        full = {}
    full["llm"] = cfg
    json.dump(full, open(p, "w", encoding="utf-8"),
              ensure_ascii=False, indent=1)


def card(parent, padx=12, pady=10):
    """深色圆角感卡片(平面描边)"""
    f = tk.Frame(parent, bg=CARD, highlightbackground=BORDER,
                 highlightthickness=1, bd=0)
    f.pack(fill="x", padx=padx, pady=pady)
    return f


def card_title(parent, num, title, hint=""):
    """卡片标题行: 橙色编号块 + 标题 + 灰提示"""
    row = tk.Frame(parent, bg=CARD)
    row.pack(fill="x", padx=12, pady=(10, 4))
    badge = tk.Label(row, text=str(num), bg=ACCENT, fg="#141414",
                     font=(FONT, 10, "bold"), width=2, padx=2)
    badge.pack(side="left")
    tk.Label(row, text=" " + title, bg=CARD, fg=TEXT,
             font=(FONT, 11, "bold")).pack(side="left")
    if hint:
        tk.Label(row, text=hint, bg=CARD, fg=MUTED,
                 font=(FONT, 9)).pack(side="right")


# ---------------- 项目: 存储 ----------------
# 每个项目 = projects/<名字>.json (参数) + projects/<名字>/ (该项目自己的 data/ output/)
# 项目窗口各自独立进程启动, 互不干扰, 可同时开多个同时出片
PROJECTS_DIR = os.path.join(BASE_DIR, "projects")


def _fs_safe(name):
    """项目名 -> 合法文件名"""
    s = re.sub(r'[\\/:*?"<>|\r\n\t]+', "_", str(name or "").strip())
    return s[:60] or "project"


def project_file(name):
    return os.path.join(PROJECTS_DIR, _fs_safe(name) + ".json")


def project_workdir(name):
    return os.path.join(PROJECTS_DIR, _fs_safe(name))


def list_projects():
    """所有项目, 按最近更新倒序"""
    os.makedirs(PROJECTS_DIR, exist_ok=True)
    out = []
    try:
        fns = os.listdir(PROJECTS_DIR)
    except OSError:
        return out
    for fn in fns:
        if not fn.endswith(".json"):
            continue
        try:
            with open(os.path.join(PROJECTS_DIR, fn), encoding="utf-8") as f:
                d = json.load(f)
        except (OSError, ValueError):
            continue
        if isinstance(d, dict) and d.get("name"):
            out.append(d)
    out.sort(key=lambda d: str(d.get("updated") or d.get("created") or ""),
             reverse=True)
    return out


def load_project(name):
    p = project_file(name)
    if os.path.exists(p):
        try:
            with open(p, encoding="utf-8") as f:
                d = json.load(f)
            if isinstance(d, dict) and d.get("name"):
                d.setdefault("params", {})
                return d
        except (OSError, ValueError):
            pass
    return {"name": name, "src": "", "out": "", "workdir": "",
            "params": {}, "created": time.strftime("%Y-%m-%d %H:%M"),
            "updated": "", "last_run": "", "last_output": "", "note": ""}


def _write_json(path, data):
    """写 json: 先写临时文件再落盘 (中途出错不会写坏原文件;
    部分环境禁止直接覆盖/改名, 所以两种方式都试一遍)"""
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    try:                              # 常规: 直接写
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=1)
        return True
    except OSError:
        pass
    try:                              # 兜底: 临时文件 + 原子替换
        tmp = path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=1)
        os.replace(tmp, path)
        return os.path.exists(path)
    except OSError:
        return False


def save_project(cfg):
    os.makedirs(PROJECTS_DIR, exist_ok=True)
    cfg = dict(cfg)
    cfg["updated"] = time.strftime("%Y-%m-%d %H:%M")
    if not cfg.get("created"):
        cfg["created"] = cfg["updated"]
    _write_json(project_file(cfg.get("name", "项目")), cfg)
    return cfg


# ---------------- 运行状态自愈 + 运行日志落盘 ----------------
# 为什么需要: 出片途中关掉窗口/软件被结束, 进程没了但项目里"运行中"标记还在,
# 项目列表就会永远显示"运行中..."并且看不到任何日志。这里用"锁文件+心跳"判断
# 是否真的在跑, 并把日志同步写一份到磁盘, 关窗重开也能看到上次跑到了哪、为什么停。
def project_data_dir(p):
    """项目数据目录: 有独立工作目录就用它, 老项目沿用软件全局目录"""
    if isinstance(p, dict):
        wd = p.get("workdir") or ""
    else:
        wd = project_workdir(str(p or "")) if p else ""
    return os.path.join(wd, "data") if wd else os.path.join(BASE_DIR, "data")


def run_log_path(p):
    return os.path.join(project_data_dir(p), "run.log")


def run_lock_path(p):
    return os.path.join(project_data_dir(p), "run.lock")


def mark_running(p, on):
    """落盘「运行中」标记(锁文件): 锁在=有任务在跑, 锁没了=已结束/被中断"""
    try:
        lp = run_lock_path(p)
        os.makedirs(os.path.dirname(lp), exist_ok=True)
        if on:
            with open(lp, "w", encoding="utf-8") as f:
                f.write("%d %s" % (os.getpid(),
                                   time.strftime("%Y-%m-%d %H:%M:%S")))
        elif os.path.exists(lp):
            os.remove(lp)
    except OSError:
        pass


def running_alive(p, max_idle=90):
    """真的还在跑吗: 锁文件存在且 90 秒内被刷新过 (跑着时每 3 秒刷一次)"""
    try:
        lp = run_lock_path(p)
        return (os.path.exists(lp)
                and (time.time() - os.path.getmtime(lp)) <= max_idle)
    except OSError:
        return False


def start_heartbeat(p):
    """后台心跳: 任务运行期间不断刷新锁文件时间戳"""
    ev = threading.Event()

    def loop():
        while not ev.wait(3):
            try:
                lp = run_lock_path(p)
                if os.path.exists(lp):
                    os.utime(lp, None)
            except OSError:
                pass
    threading.Thread(target=loop, daemon=True).start()
    return ev


def heal_stale_running(p):
    """僵尸"运行中"自愈: 标记还在但根本没进程在跑 -> 清掉。
    返回是否修正过(不改 updated 时间, 免得列表顺序乱跳)"""
    if not p.get("running"):
        return False
    if running_alive(p):
        return False
    p["running"] = False
    if not p.get("last_run"):
        p["note"] = "上次出片被中断"
    mark_running(p, False)
    try:
        _write_json(project_file(p.get("name", "")), p)
    except (OSError, ValueError):
        pass
    return True


def open_run_log(p):
    """打开(或新建)运行日志, 追加模式; 超过 4MB 先只留尾部"""
    try:
        path = run_log_path(p)
        os.makedirs(os.path.dirname(path), exist_ok=True)
        if os.path.exists(path) and os.path.getsize(path) > 4 * 1024 * 1024:
            with open(path, encoding="utf-8", errors="replace") as f:
                tail = f.readlines()[-2000:]
            with open(path, "w", encoding="utf-8") as f:
                f.writelines(tail)
        return open(path, "a", encoding="utf-8", errors="replace")
    except OSError:
        return None


def log_sink(fp, text):
    """日志同步写一份到磁盘: 界面关了, 记录还在"""
    if not fp:
        return
    try:
        fp.write(text)
        fp.flush()
    except (OSError, ValueError):
        pass


def load_log_tail(widget, p, max_lines=400):
    """启动时把上次的运行日志回显到日志框 (关窗重开不再一片空白)"""
    try:
        path = run_log_path(p)
        if not os.path.exists(path) or os.path.getsize(path) == 0:
            return False
        with open(path, encoding="utf-8", errors="replace") as f:
            lines = f.readlines()[-max_lines:]
    except OSError:
        return False
    if not lines:
        return False
    try:
        widget.configure(state="normal")
        widget.insert("end", "——— 上次运行日志 (最近 %d 行; "
                             "完整记录: 项目目录\\data\\run.log) ———\n"
                             % len(lines), "dim")
        widget.insert("end", "".join(lines))
        widget.insert("end", "——— 以上为历史记录, 点「开始出片」开新一轮 ———\n\n",
                      "dim")
        widget.see("end")
        widget.configure(state="disabled")
    except tk.TclError:
        return False
    return True


# ---------------- 后台出片执行器 (关窗也继续跑) ----------------
# 为什么需要: 出片很慢(OCR 一步十几分钟), 用户关掉窗口是为了去干别的活儿,
# 不是要中止任务。所以真正的活儿交给一个"脱离窗口"的独立进程去干, 界面只是看客:
#   · 后端输出  -> 项目目录\data\run.log      (界面只读, 用来实时显示)
#   · 进度状态  -> 项目目录\data\runstate.json (第几步/共几步/成功失败)
#   · 心跳      -> 项目目录\data\run.lock      (每 3 秒刷新, 界面靠它判断"真在跑")
#   · 中止指令  -> 项目目录\data\stop.flag     (界面放这个文件, 执行器就停)
# 界面关掉/退出后执行器照跑; 重开项目窗口会自动"接上"它, 日志和进度都是实时的。
def task_json_path(p):
    return os.path.join(project_data_dir(p), "task.json")


def state_json_path(p):
    return os.path.join(project_data_dir(p), "runstate.json")


def stop_flag_path(p):
    return os.path.join(project_data_dir(p), "stop.flag")


def read_run_state(p):
    """读后台任务的进度状态 (任务没跑过/正在写 -> 返回空 dict)"""
    try:
        with open(state_json_path(p), encoding="utf-8") as f:
            d = json.load(f)
        return d if isinstance(d, dict) else {}
    except (OSError, ValueError):
        return {}


def request_stop(p):
    """给后台任务下"中止"指令 (执行器看到 stop.flag 会杀掉当前步骤并收尾)"""
    try:
        sp = stop_flag_path(p)
        os.makedirs(os.path.dirname(sp), exist_ok=True)
        with open(sp, "w", encoding="utf-8") as f:
            f.write(time.strftime("%Y-%m-%d %H:%M:%S"))
        return True
    except OSError:
        return False


def _run_no_win():
    """后台进程不弹黑色控制台窗口 (仅 Windows)"""
    return 0x08000000 if os.name == "nt" else 0


def _kill_tree(pid):
    """杀整棵进程树 (ffmpeg 之类的子进程也要清干净)"""
    try:
        if os.name == "nt":
            subprocess.run(["taskkill", "/F", "/T", "/PID", str(pid)],
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                           timeout=20)
        else:
            os.kill(pid, 9)
    except Exception:
        pass


def detached_python():
    """跑后台任务的解释器: 用 windowless 的 pythonw.exe。

    关键: 本机 python.exe (控制台版) 在无 -S 时启动会卡在 tkinter/site 初始化
    (表现就是后台任务永远起不来); 而 pythonw.exe 无窗口、启动正常, 且后台任务
    本就把所有日志写到 run.log, 不需要控制台。找不到 pythonw 时退回原解释器
    (客户端机器上 python.exe 不卡, 退回也安全)。
    """
    exe = sys.executable
    if os.name == "nt" and exe.lower().endswith("python.exe"):
        cand = exe[:-len("python.exe")] + "pythonw.exe"
        if os.path.exists(cand):
            return cand
    return exe


def run_task_mode(task_path):
    """--run-task 模式: 独立后台进程, 依次跑完所有步骤。

    关键点: 它不依赖界面进程 —— 界面关掉/被杀, 它照样把活干完。
    返回 0(全部成功) / 1(失败或被中止) / 2(任务文件读不了)。
    """
    try:
        with open(task_path, encoding="utf-8") as f:
            task = json.load(f)
    except (OSError, ValueError):
        return 2

    log_path = task.get("log") or ""
    state_path = task.get("state") or ""
    lock_path = task.get("lock") or ""
    stop_path = task.get("stop") or ""
    steps = task.get("steps") or []
    cwd = task.get("cwd") or BASE_DIR
    py = task.get("py") or sys.executable
    script = task.get("script") or ""
    out_dir = task.get("out") or ""
    proj_name = task.get("proj") or ""
    env = dict(os.environ)
    env.update({k: str(v) for k, v in (task.get("env") or {}).items()})
    env["PYTHONIOENCODING"] = "utf-8"
    env["PYTHONUTF8"] = "1"

    try:
        os.makedirs(os.path.dirname(log_path), exist_ok=True)
    except OSError:
        pass
    for leftover in (stop_path,):
        try:
            if leftover:
                os.remove(leftover)
        except OSError:
            pass

    fp = None
    try:
        fp = open(log_path, "a", encoding="utf-8", errors="replace")
    except OSError:
        pass
    started = time.time()
    total = max(1, len(steps))

    def log(t):
        if fp is None:
            return
        try:
            fp.write(t)
            fp.flush()
        except (OSError, ValueError):
            pass

    def beat(step, title, status="running", extra=None):
        """刷新进度 + 心跳 (界面每 0.5 秒读一次)"""
        d = {"pid": os.getpid(), "status": status, "step": step, "total": total,
             "title": title, "proj": proj_name, "started": started,
             "elapsed": round(time.time() - started, 1), "hb": time.time()}
        if extra:
            d.update(extra)
        try:
            with open(state_path, "w", encoding="utf-8") as f:
                json.dump(d, f, ensure_ascii=False)
        except OSError:
            pass
        try:
            os.utime(lock_path, None)
        except OSError:
            pass

    log("\n========== 后台任务启动  %s   (任务进程 PID %d) ==========\n"
        "[说明] 任务与窗口已分离: 关掉窗口/退出软件它都会继续跑, "
        "回项目列表能看到进度, 再点「打开」可接上实时日志。\n"
        % (time.strftime("%Y-%m-%d %H:%M:%S"), os.getpid()))
    beat(0, "准备...")

    status, note, done_step = "done", "", 0
    idx = 0
    while idx < len(steps):
        step = steps[idx] if isinstance(steps[idx], dict) else {}
        title = step.get("title") or ("第 %d 步" % (idx + 1))
        args = step.get("args") or []
        idx += 1
        done_step = idx
        log("\n========== %s ==========\n" % title)
        beat(idx, title)
        cmd = [py, "-u", script] + [str(x) for x in args]
        try:
            proc = subprocess.Popen(cmd, stdout=fp, stderr=subprocess.STDOUT,
                                    cwd=cwd, env=env,
                                    creationflags=_run_no_win())
        except OSError as e:
            log("\n✗ 无法启动后端进程: %s\n" % e)
            status, note = "error", "无法启动后端进程"
            break
        rc = 0
        stopped = False
        while True:
            try:
                rc = proc.wait(timeout=3)
                break
            except subprocess.TimeoutExpired:
                pass
            beat(idx, title)                       # 每 3 秒心跳
            if stop_path and os.path.exists(stop_path):
                log("\n[收到中止指令] 正在结束当前步骤...\n")
                _kill_tree(proc.pid)
                try:
                    proc.wait(timeout=20)
                except Exception:
                    pass
                stopped = True
                break
        if stopped:
            status, note = "stopped", "已手动中止"
            log("\n[已中止] 本次出片被手动停止。已完成的步骤成果保留, "
                "下次出片会自动跳过。\n")
            break
        if rc != 0:
            log("\n✗ 步骤失败 (退出码 %d), 请检查上方日志\n" % rc)
            status, note = "error", "第 %d 步失败 (退出码 %d)" % (idx, rc)
            break

    if status == "done":
        log("\n✅ 全部完成! 成片在: %s\n" % (out_dir or "项目成片目录"))
    log("\n[%s] 任务结束  %s   (共 %.1f 分钟)\n"
        % ({"done": "成功", "error": "失败", "stopped": "已中止"}[status],
           time.strftime("%Y-%m-%d %H:%M:%S"),
           (time.time() - started) / 60.0))
    beat(total if status == "done" else done_step, "", status=status,
         extra={"note": note, "finished": time.time()})
    if fp is not None:
        try:
            fp.close()
        except (OSError, ValueError):
            pass
    for pth in (lock_path, stop_path):
        try:
            if pth:
                os.remove(pth)
        except OSError:
            pass
    try:
        os.remove(task_path)
    except OSError:
        pass
    return 0 if status == "done" else 1


def new_project(name, src="", copy_from=None, ptype="mix"):
    cfg = load_project(name)
    cfg["name"] = name
    cfg["src"] = src
    cfg["out"] = ""
    cfg["type"] = ptype or "mix"
    if ptype == "grab":
        cfg.setdefault("tasks", [])
        cfg.setdefault("grab_text", "1")
    cfg["workdir"] = project_workdir(name)
    cfg["last_run"] = ""
    cfg["last_output"] = ""
    cfg["created"] = time.strftime("%Y-%m-%d %H:%M")
    if copy_from:
        base = load_project(copy_from)
        cfg["params"] = dict(base.get("params") or {})
        if not src:
            cfg["src"] = base.get("src", "")
    return save_project(cfg)


def rename_project(old, new):
    if _fs_safe(old) == _fs_safe(new):
        return load_project(new)
    cfg = load_project(old)
    od, nd = project_workdir(old), project_workdir(new)
    if os.path.isdir(od) and not os.path.exists(nd):
        try:
            os.rename(od, nd)
        except OSError:
            pass
    try:
        if os.path.exists(project_file(old)):
            os.remove(project_file(old))
    except OSError:
        pass
    cfg["name"] = new
    cfg["workdir"] = nd
    return save_project(cfg)


def delete_project(name, drop_files=False):
    """删除项目配置; drop_files=True 时连该项目目录(含成片)一起删"""
    try:
        if os.path.exists(project_file(name)):
            os.remove(project_file(name))
    except OSError:
        pass
    if drop_files:
        import shutil
        wd = project_workdir(name)
        if os.path.isdir(wd):
            try:
                shutil.rmtree(wd)
            except OSError:
                pass


def gui_script():
    """界面脚本自身 (用于给项目开独立窗口)"""
    for n in ("mixcut_gui.py", "mixcut_gui.pyc"):
        p = os.path.join(BASE_DIR, n)
        if os.path.exists(p):
            return p
    return os.path.abspath(__file__)


def open_project_window(name):
    """独立进程打开项目窗口: 一个项目一个窗口, 可多开"""
    exe = sys.executable
    if os.name == "nt" and exe.lower().endswith("python.exe"):
        pw = exe[:-10] + "pythonw.exe"
        if os.path.exists(pw):
            exe = pw
    no_win = 0x08000000 if os.name == "nt" else 0
    try:
        subprocess.Popen([exe, gui_script(), "--project", name],
                         cwd=BASE_DIR, creationflags=no_win)
        return True, ""
    except OSError as e:
        return False, str(e)


class ScrollFrame:
    """带滚动条的容器 (tkinter 原生没有)"""

    def __init__(self, parent, bg=BG):
        self.outer = tk.Frame(parent, bg=bg)
        self.canvas = tk.Canvas(self.outer, bg=bg, highlightthickness=0, bd=0)
        sb = ttk.Scrollbar(self.outer, orient="vertical",
                           command=self.canvas.yview)
        self.inner = tk.Frame(self.canvas, bg=bg)
        self.win = self.canvas.create_window((0, 0), window=self.inner,
                                             anchor="nw")
        self.canvas.configure(yscrollcommand=sb.set)
        sb.pack(side="right", fill="y")
        self.canvas.pack(side="left", fill="both", expand=True)
        self.inner.bind("<Configure>", lambda e: self.canvas.configure(
            scrollregion=self.canvas.bbox("all")))
        self.canvas.bind("<Configure>", lambda e: self.canvas.itemconfig(
            self.win, width=e.width))
        for w in (self.canvas, self.inner):
            w.bind("<MouseWheel>", self._wheel)

    def pack(self, **kw):
        self.outer.pack(**kw)

    def _wheel(self, e):
        self.canvas.yview_scroll(int(-1 * (e.delta / 120)), "units")


class ProjectManager:
    """项目管理主窗口: 新建 / 打开 / 复制 / 重命名 / 删除项目"""

    def __init__(self, root):
        self.root = root
        root.title("VideoMixCut 项目管理"
                   + (" v" + APP_VERSION if APP_VERSION else ""))
        root.geometry("780x600")
        root.minsize(680, 460)
        root.configure(bg=BG)
        style_widget(root)
        self._status_labels = []
        self._build()
        self.refresh()
        self._tick()

    # ---------------- UI ----------------
    def _build(self):
        hd = tk.Frame(self.root, bg=CARD, highlightbackground=BORDER,
                      highlightthickness=1)
        hd.pack(fill="x", padx=12, pady=(12, 6))
        inner = tk.Frame(hd, bg=CARD)
        inner.pack(fill="x", padx=14, pady=12)
        logo = tk.Canvas(inner, width=44, height=44, bg=CARD,
                         highlightthickness=0)
        logo.pack(side="left", padx=(0, 10))
        logo.create_oval(2, 2, 42, 42, fill=ACCENT, outline="")
        logo.create_text(22, 22, text="剪", fill="#141414",
                         font=(FONT, 17, "bold"))
        tbox = tk.Frame(inner, bg=CARD)
        tbox.pack(side="left")
        tk.Label(tbox, text="VideoMixCut  项目管理",
                 bg=CARD, fg=TEXT, font=(FONT, 15, "bold")).pack(anchor="w")
        tk.Label(tbox, text="一个项目 = 一套素材 + 一套参数 + 自己的成片, "
                            "可同时开多个项目窗口各自出片",
                 bg=CARD, fg=MUTED, font=(FONT, 9)).pack(anchor="w")
        btns = tk.Frame(inner, bg=CARD)
        btns.pack(side="right")
        b_new = tk.Button(btns, text="+ 新建项目", command=self.new_proj,
                          bg=ACCENT, fg="#141414", activebackground=ACCENT_DK,
                          activeforeground="#fff", relief="flat", padx=14,
                          cursor="hand2", font=(FONT, 10, "bold"))
        b_new.pack(side="left", padx=3)
        hover_button(b_new, ACCENT, ACCENT_DK)
        b_lib = tk.Button(btns, text="项目文件夹", command=self.open_dir,
                          bg=CARD2, fg=TEXT, activebackground=BORDER,
                          activeforeground=TEXT, relief="flat", padx=12,
                          cursor="hand2", font=(FONT, 10))
        b_lib.pack(side="left", padx=3)
        hover_button(b_lib, CARD2, BORDER)

        self.body = ScrollFrame(self.root)
        self.body.pack(fill="both", expand=True, padx=12, pady=6)

        ft = tk.Frame(self.root, bg=CARD2)
        ft.pack(fill="x", side="bottom")
        self.tip = tk.Label(ft, text="双击项目卡片即可打开该项目的独立窗口",
                            bg=CARD2, fg=MUTED, font=(FONT, 9))
        self.tip.pack(side="left", padx=12, pady=6)

    # ---------------- 列表 ----------------
    def refresh(self):
        for w in self.body.inner.winfo_children():
            w.destroy()
        self._status_labels = []
        pros = list_projects()
        if not pros:
            tk.Label(self.body.inner, text="还没有项目, 点右上角「+ 新建项目」"
                                           "创建第一个",
                     bg=BG, fg=MUTED, font=(FONT, 11)).pack(pady=40)
            return
        for p in pros:
            self._row(self.body.inner, p)

    def _tick(self):
        """每 2 秒刷新一次状态文字 (项目窗口跑起来时这里会显示"运行中")"""
        try:
            proj = list_projects()
            # 僵尸"运行中"自愈: 上次关窗/崩溃留下的标记, 这里自动清掉
            for p in proj:
                heal_stale_running(p)
            cur = {p["name"]: p for p in proj}
            for name, lab in list(self._status_labels):
                p = cur.get(name)
                if not p:
                    continue
                txt, fg = project_status(p)
                if lab.cget("text").strip() != ("● " + txt):
                    lab.configure(text="  ● " + txt + "  ", fg=fg)
        except (OSError, ValueError):
            pass
        self.root.after(2000, self._tick)

    def _row(self, parent, p):
        name = p.get("name", "?")
        ptype = p.get("type") or "mix"
        c = card(parent, pady=(0, 8))
        c.pack(fill="x", pady=(0, 8))
        left = tk.Frame(c, bg=CARD)
        left.pack(side="left", fill="x", expand=True, padx=12, pady=10)
        top = tk.Frame(left, bg=CARD)
        top.pack(anchor="w", fill="x")
        tk.Label(top, text=name, bg=CARD, fg=TEXT,
                 font=(FONT, 12, "bold")).pack(side="left")
        tk.Label(top, text="  %s  " % ("提取" if ptype == "grab" else "混剪"),
                 bg=ACCENT if ptype == "grab" else CARD2,
                 fg="#141414" if ptype == "grab" else MUTED,
                 font=(FONT, 8, "bold"), padx=3).pack(side="left", padx=4)
        st_txt, st_fg = project_status(p)
        lab = tk.Label(top, text="  ● " + st_txt + "  ", bg=CARD, fg=st_fg,
                       font=(FONT, 9, "bold"))
        lab.pack(side="left", padx=4)
        self._status_labels.append((name, lab))
        if ptype == "grab":
            n = len(p.get("tasks") or [])
            src = "链接 %d 条" % n
        else:
            src = p.get("src") or "(未设置素材文件夹)"
            if len(src) > 58:
                src = "..." + src[-55:]
            src = "素材: " + src
        tk.Label(left, text=src, bg=CARD, fg=MUTED,
                 font=(FONT, 9)).pack(anchor="w")
        extra = p.get("updated") or p.get("created") or ""
        tk.Label(left, text="更新: %s" % extra, bg=CARD, fg=MUTED,
                 font=(FONT, 9)).pack(anchor="w")
        right = tk.Frame(c, bg=CARD)
        right.pack(side="right", padx=12)
        spec = (("打 开", ACCENT, "#141414", lambda n=name: self.open_proj(n)),
                ("复 制", CARD2, TEXT, lambda n=name: self.copy_proj(n)),
                ("重命名", CARD2, TEXT, lambda n=name: self.rename_proj(n)),
                ("删 除", CARD2, "#ff6b6b", lambda n=name: self.del_proj(n)))
        for txt, bgc, fg, cmd in spec:
            b = tk.Button(right, text=txt, command=cmd, bg=bgc, fg=fg,
                          activebackground=BORDER, activeforeground=fg,
                          relief="flat", padx=10, cursor="hand2",
                          font=(FONT, 9, "bold" if txt == "打 开" else ""))
            b.pack(side="left", padx=3)
            hover_button(b, bgc, ACCENT_DK if bgc == ACCENT else BORDER)
        for w in (c, left):
            w.bind("<Double-Button-1>", lambda e, n=name: self.open_proj(n))

    # ---------------- 操作 ----------------
    def open_proj(self, name):
        ok, err = open_project_window(name)
        if not ok:
            messagebox.showerror("打开失败", err)
        else:
            self.tip.configure(text="已打开项目窗口: " + name)

    def _ask_name(self, title, init=""):
        """简易输入框, 返回名字或 None"""
        dlg = tk.Toplevel(self.root)
        dlg.title(title)
        dlg.geometry("520x220")
        dlg.configure(bg=BG)
        style_widget(dlg)
        dlg.transient(self.root)
        dlg.grab_set()
        tk.Label(dlg, text=title, bg=BG, fg=TEXT,
                 font=(FONT, 13, "bold")).pack(pady=(16, 4))
        var = tk.StringVar(value=init)
        tk.Label(dlg, text="项目名称 (比如: 牙膏-双十一 / 王哥口播A版)",
                 bg=BG, fg=MUTED, font=(FONT, 9)).pack()
        e = ttk.Entry(dlg, textvariable=var, width=44,
                      font=(FONT, 11))
        e.pack(pady=6, ipady=4)
        e.focus_set()
        e.select_range(0, "end")
        src_var = tk.StringVar()
        row = tk.Frame(dlg, bg=BG)
        row.pack()
        ttk.Entry(row, textvariable=src_var, width=36).pack(side="left")
        b = tk.Button(row, text="选素材文件夹", bg=CARD2, fg=TEXT,
                      activebackground=BORDER, activeforeground=TEXT,
                      relief="flat", padx=10, cursor="hand2", font=(FONT, 9),
                      command=lambda: src_var.set(
                          os.path.normpath(filedialog.askdirectory(
                              title="选择素材文件夹")) or src_var.get()))
        b.pack(side="left", padx=(6, 0))
        type_var = tk.StringVar(value="mix")
        trow = tk.Frame(dlg, bg=BG)
        trow.pack(pady=(10, 0))
        tk.Label(trow, text="项目类型:", bg=BG, fg=MUTED,
                 font=(FONT, 9)).pack(side="left")
        for txt, val, hint in (("混剪项目", "mix", "素材 → 出成片"),
                               ("提取项目", "grab", "链接 → 无水印素材")):
            ttk.Radiobutton(trow, text="%s (%s)" % (txt, hint), value=val,
                            variable=type_var).pack(side="left", padx=8)
        res = {"name": None, "src": ""}

        def ok_():
            n = var.get().strip()
            if not n:
                messagebox.showwarning("提示", "请填写项目名称")
                return
            if _fs_safe(n) != _fs_safe(x) and project_file(n) and \
                    os.path.exists(project_file(n)):
                messagebox.showwarning("提示", "已存在同名项目")
                return
            res["name"] = n
            res["src"] = src_var.get().strip()
            res["type"] = type_var.get()
            dlg.destroy()

        x = init
        e.bind("<Return>", lambda ev: ok_())
        frm = tk.Frame(dlg, bg=BG)
        frm.pack(pady=14)
        b1 = tk.Button(frm, text="确 定", command=ok_, bg=ACCENT, fg="#141414",
                       activebackground=ACCENT_DK, activeforeground="#fff",
                       relief="flat", padx=22, cursor="hand2",
                       font=(FONT, 10, "bold"))
        b1.pack(side="left", padx=6)
        hover_button(b1, ACCENT, ACCENT_DK)
        b2 = tk.Button(frm, text="取消", command=dlg.destroy, bg=CARD2,
                       fg=TEXT, activebackground=BORDER, activeforeground=TEXT,
                       relief="flat", padx=18, cursor="hand2", font=(FONT, 10))
        b2.pack(side="left", padx=6)
        hover_button(b2, CARD2, BORDER)
        self.root.wait_window(dlg)
        if not res["name"]:
            return (None, "", "mix")
        return (res["name"], res["src"], res.get("type", "mix"))

    def new_proj(self):
        name, src, ptype = self._ask_name("新建项目", "")
        if not name:
            return
        new_project(name, src, ptype=ptype)
        self.refresh()
        if messagebox.askyesno("新建成功", "项目「%s」已创建, 现在打开吗?" % name):
            self.open_proj(name)

    def copy_proj(self, name):
        new, src, ptype = self._ask_name("复制为新建项目", name + "-副本")
        if not new:
            return
        old = load_project(name)
        new_project(new, src, copy_from=name,
                    ptype=ptype or (old.get("type") or "mix"))
        self.refresh()

    def rename_proj(self, name):
        new, _src = self._ask_name("重命名项目", name)
        if not new or new == name:
            return
        rename_project(name, new)
        self.refresh()

    def del_proj(self, name):
        if not messagebox.askyesno("删除项目",
                                   "确定删除项目「%s」吗?" % name):
            return
        drop = messagebox.askyesno(
            "删除项目",
            "是否同时删除该项目的成片与中间文件?\n\n"
            "选「否」只删除项目配置, 成片文件夹会保留")
        delete_project(name, drop_files=drop)
        self.refresh()

    def open_dir(self):
        os.makedirs(PROJECTS_DIR, exist_ok=True)
        try:
            os.startfile(PROJECTS_DIR)
        except OSError:
            pass


# ---------------- 提取项目 (链接批量提取, 每条独立看状态) ----------------
GRAB_URL_RE = re.compile(r"https?://[^\s，,、；;）)\]\}'\"】」]+")


def extract_urls(text):
    """从一段文字里抽出链接 (分享原文混着文案也能抽出来)"""
    out = []
    for m in GRAB_URL_RE.finditer(text or ""):
        u = m.group(0).rstrip("。，、；：！？")
        if u and u not in out:
            out.append(u)
    return out


def project_status(p):
    """项目状态: (文字, 颜色) —— 项目列表每行显示

    后台任务跑起来时这里显示真实进度(第几步/共几步), 关窗去干别的活儿
    回来也能一眼看到跑到哪了。
    """
    st = read_run_state(p) if isinstance(p, dict) else {}
    stt = st.get("status") or ""
    if stt == "running" or p.get("running"):
        # 不只看标记, 还要确认心跳还在 (关窗/崩溃后标记会残留)
        if running_alive(p):
            step, tot = st.get("step") or 0, st.get("total") or 0
            if step and tot:
                return ("后台运行中 %d/%d 步" % (step, tot), YELLOW)
            return ("后台运行中...", YELLOW)
        return ("上次中断 · 可重新出片", "#ff9f43")
    if stt == "stopped":
        return ("上次已中止 · 可重新出片", "#ff9f43")
    if stt == "error":
        return ("上次失败 · 请点开看日志", "#ff6b6b")
    if (p.get("type") or "mix") == "grab":
        tasks = p.get("tasks") or []
        if not tasks:
            return ("未开始 · 还没加链接", MUTED)
        st = [t.get("status") for t in tasks]
        ok_n = sum(1 for x in st if x == "完成")
        bad_n = sum(1 for x in st if x == "失败")
        pend = sum(1 for x in st if x in ("等待中", "提取中"))
        if bad_n:
            return ("有问题 · %d 条失败" % bad_n, "#ff6b6b")
        if pend:
            return ("待提取 %d 条 (已完成 %d)" % (pend, ok_n), ACCENT)
        return ("已完成 · %d 条" % ok_n, GREEN)
    if p.get("last_run"):
        return ("已出片 %s" % p["last_run"], GREEN)
    if p.get("src"):
        return ("就绪 · 还没出片", MUTED)
    return ("未设置素材", MUTED)


class GrabApp:
    """提取项目窗口: 一个项目管一批链接, 每条一行显示状态"""

    def __init__(self, root, project=None):
        self.root = root
        self.proj = project or load_project("提取项目")
        self.proj["type"] = "grab"
        self.proj_name = self.proj.get("name", "提取项目")
        self.tasks = [dict(t) for t in (self.proj.get("tasks") or [])]
        self.out_var = tk.StringVar(value=self.proj.get("out") or "")
        self.text_var = tk.StringVar(value=self.proj.get("grab_text") or "1")
        self.running = False
        self.proc = None
        self.stop_flag = False
        self.hb_ev = None
        self.log_q = queue.Queue()
        root.title("VideoMixCut · 提取: %s%s" % (
            self.proj_name, " v" + APP_VERSION if APP_VERSION else ""))
        root.geometry("900x760")
        root.minsize(800, 600)
        root.configure(bg=BG)
        style_widget(root)
        self._build()
        self._log_fp = open_run_log(self.proj)
        load_log_tail(self.log, self.proj)
        self._poll()

    # ---------------- UI ----------------
    def _build(self):
        hd = tk.Frame(self.root, bg=CARD, highlightbackground=BORDER,
                      highlightthickness=1)
        hd.pack(fill="x", padx=12, pady=(12, 6))
        inner = tk.Frame(hd, bg=CARD)
        inner.pack(fill="x", padx=14, pady=10)
        tk.Label(inner, text="提取项目: " + self.proj_name, bg=CARD, fg=TEXT,
                 font=(FONT, 15, "bold")).pack(side="left")
        tk.Label(inner, text="  链接提取 · 无水印下载 + 口播文案",
                 bg=CARD, fg=MUTED, font=(FONT, 9)).pack(side="left")
        b = tk.Button(inner, text="项目列表 / 切换项目",
                      command=lambda: open_project_window("__manager__"),
                      bg=CARD2, fg=ACCENT, activebackground=BORDER,
                      activeforeground=ACCENT, relief="flat", padx=12,
                      cursor="hand2", font=(FONT, 9, "bold"))
        b.pack(side="right")
        hover_button(b, CARD2, BORDER)

        body = tk.Frame(self.root, bg=BG)
        body.pack(fill="both", expand=True)

        c1 = card(body)
        card_title(c1, 1, "链接列表", "每条一行, 状态实时更新")
        add_row = tk.Frame(c1, bg=CARD)
        add_row.pack(fill="x", padx=12, pady=(2, 6))
        self.url_var = tk.StringVar()
        e = ttk.Entry(add_row, textvariable=self.url_var)
        e.pack(side="left", fill="x", expand=True, ipady=3)
        e.bind("<Return>", lambda ev: self.add_url())
        for txt, cmd, fg in (("添加链接", self.add_url, ACCENT),
                             ("从TXT导入", self.import_txt, GREEN),
                             ("清空列表", self.clear_tasks, "#ff6b6b")):
            bb = tk.Button(add_row, text=txt, command=cmd, bg=CARD2, fg=fg,
                           activebackground=BORDER, activeforeground=fg,
                           relief="flat", padx=10, cursor="hand2",
                           font=(FONT, 9, "bold"))
            bb.pack(side="left", padx=(6, 0))
            hover_button(bb, CARD2, BORDER)
        tk.Label(c1, text="提示: 整段抖音分享文字直接粘进来也行, 会自动抽出链接",
                 bg=CARD, fg=MUTED, font=(FONT, 8)).pack(anchor="w", padx=12)

        wrap = tk.Frame(c1, bg=CARD)
        wrap.pack(fill="both", expand=True, padx=12, pady=(4, 10))
        st = ttk.Style(self.root)
        st.configure("Grab.Treeview", background=INPUT_BG, foreground=TEXT,
                     fieldbackground=INPUT_BG, bordercolor=BORDER,
                     rowheight=25)
        st.configure("Grab.Treeview.Heading", background=CARD2,
                     foreground=TEXT)
        self.tree = ttk.Treeview(wrap, columns=("no", "url", "status",
                                                "result"),
                                 show="headings", style="Grab.Treeview",
                                 height=7)
        for c, w, t in (("no", 44, "#"), ("url", 360, "链接"),
                        ("status", 92, "状态"), ("result", 250, "结果")):
            self.tree.heading(c, text=t)
            self.tree.column(c, width=w, anchor="w")
        sb = ttk.Scrollbar(wrap, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=sb.set)
        sb.pack(side="right", fill="y")
        self.tree.pack(side="left", fill="both", expand=True)
        for tag, fg in (("done", GREEN), ("bad", "#ff6b6b"), ("run", YELLOW),
                        ("wait", MUTED)):
            self.tree.tag_configure(tag, foreground=fg)

        c2 = card(body)
        card_title(c2, 2, "保存位置与提取")
        r = tk.Frame(c2, bg=CARD)
        r.pack(fill="x", padx=12, pady=(2, 6))
        ttk.Entry(r, textvariable=self.out_var).pack(
            side="left", fill="x", expand=True)
        bb = tk.Button(r, text="浏览", command=self.pick_out, bg=CARD2,
                       fg=TEXT, activebackground=BORDER, activeforeground=TEXT,
                       relief="flat", padx=12, cursor="hand2", font=(FONT, 10))
        bb.pack(side="left", padx=(8, 0))
        hover_button(bb, CARD2, BORDER)
        r2 = tk.Frame(c2, bg=CARD)
        r2.pack(fill="x", padx=12, pady=(0, 10))
        self.redo_var = tk.StringVar(
            value=self.proj.get("grab_redo") or "0")
        ttk.Checkbutton(r2, text="同时提取口播文案 (OCR, 每条约半分钟)",
                        variable=self.text_var).pack(side="left")
        ttk.Checkbutton(r2, text="已提取过的也重新下载",
                        variable=self.redo_var).pack(side="left", padx=(14, 0))
        self.stop_btn = tk.Button(r2, text="停 止", command=self.stop,
                                  bg=CARD2, fg=TEXT, activebackground=BORDER,
                                  activeforeground=TEXT, relief="flat",
                                  padx=16, cursor="hand2", font=(FONT, 10),
                                  state="disabled")
        self.stop_btn.pack(side="right")
        hover_button(self.stop_btn, CARD2, BORDER)
        self.go_btn = tk.Button(r2, text="开 始 提 取", command=self.start,
                                bg=ACCENT, fg="#141414",
                                activebackground=ACCENT_DK,
                                activeforeground="#fff", relief="flat",
                                padx=18, cursor="hand2", font=(FONT, 11,
                                                               "bold"))
        self.go_btn.pack(side="right", padx=(0, 8))
        hover_button(self.go_btn, ACCENT, ACCENT_DK)
        self.prog = ttk.Progressbar(c2, mode="determinate")
        self.prog.pack(fill="x", padx=12, pady=(0, 10))

        c3 = card(body, pady=(6, 6))
        c3.pack_configure(fill="both", expand=True)
        card_title(c3, "▮", "提取日志")
        self.log = tk.Text(c3, height=7, state="disabled", wrap="none",
                           font=("Consolas", 9), bg=LOG_BG, fg="#c9d3e0",
                           insertbackground=TEXT, relief="flat")
        sb2 = ttk.Scrollbar(c3, command=self.log.yview)
        self.log.configure(yscrollcommand=sb2.set)
        sb2.pack(side="right", fill="y")
        self.log.pack(side="left", fill="both", expand=True, padx=(12, 0),
                      pady=(0, 10))
        self._refresh_tree()

    # ---------------- 列表 ----------------
    def _save(self, out=None, grab_text=None):
        """保存项目 (工作线程里也能调: 不碰 tk 变量, 值由参数带进来)"""
        if out is None:
            try:
                out = self.out_var.get().strip()
            except Exception:
                out = self.proj.get("out", "")
        if grab_text is None:
            try:
                grab_text = self.text_var.get()
            except Exception:
                grab_text = self.proj.get("grab_text", "1")
        self.proj["tasks"] = self.tasks
        self.proj["out"] = out or ""
        self.proj["grab_text"] = grab_text or "1"
        self.proj["name"] = self.proj_name
        save_project(self.proj)

    def _refresh_tree(self):
        for i in self.tree.get_children():
            self.tree.delete(i)
        for i, t in enumerate(self.tasks, 1):
            stt = t.get("status", "等待中")
            tag = {"完成": "done", "失败": "bad", "提取中": "run"}.get(
                stt, "wait")
            self.tree.insert("", "end", values=(
                i, t.get("url", "")[:70], stt, t.get("result", "")),
                tags=(tag,))

    def add_url(self):
        raw = self.url_var.get().strip()
        if not raw:
            return
        urls = extract_urls(raw)
        if not urls:
            messagebox.showwarning("提示", "没识别到链接, 请粘贴含 http 的链接")
            return
        have = {t.get("url") for t in self.tasks}
        n = 0
        for u in urls:
            if u not in have:
                self.tasks.append({"url": u, "status": "等待中",
                                   "result": ""})
                n += 1
        self.url_var.set("")
        self._refresh_tree()
        self._save()
        self.log_write("已添加 %d 条链接 (当前共 %d 条)\n"
                       % (n, len(self.tasks)), "dim")

    def import_txt(self):
        p = filedialog.askopenfilename(
            title="选择包含链接的文本",
            filetypes=[("文本文件", "*.txt *.md *.csv"), ("所有文件", "*.*")])
        if not p:
            return
        try:
            with open(p, encoding="utf-8", errors="ignore") as f:
                urls = extract_urls(f.read())
        except OSError as e:
            messagebox.showerror("读取失败", str(e))
            return
        have = {t.get("url") for t in self.tasks}
        n = 0
        for u in urls:
            if u not in have:
                self.tasks.append({"url": u, "status": "等待中", "result": ""})
                n += 1
        self._refresh_tree()
        self._save()
        self.log_write("从文本导入 %d 条链接 (共 %d 条)\n"
                       % (n, len(self.tasks)), "dim")

    def clear_tasks(self):
        if not self.tasks:
            return
        if not messagebox.askyesno("清空", "清空这 %d 条链接吗?" % len(self.tasks)):
            return
        self.tasks = []
        self._refresh_tree()
        self._save()

    def pick_out(self):
        d = filedialog.askdirectory(title="选择视频保存目录")
        if d:
            self.out_var.set(os.path.normpath(d))
            self._save()

    def out_dir(self):
        try:
            d = self.out_var.get().strip()
        except Exception:
            d = self.proj.get("out", "")
        if not d:
            wd = self.proj.get("workdir") or ""
            d = os.path.join(wd, "videos") if wd else os.path.join(
                BASE_DIR, "output")
        os.makedirs(d, exist_ok=True)
        return d

    # ---------------- 提取 ----------------
    def start(self):
        if self.running:
            return
        pend = [t for t in self.tasks
                if t.get("status") in ("等待中", "失败")]
        if not pend:
            messagebox.showinfo("提示", "没有待提取的链接 (可先添加)")
            return
        self.running = True
        self.stop_flag = False
        # tk 变量只能在主线程读, 这里先取好给工作线程用
        self._want_text = (self.text_var.get() == "1")
        self._out_dir = self.out_dir()
        self.go_btn.configure(state="disabled", text="提 取 中 ...")
        self.stop_btn.configure(state="normal")
        self.prog.configure(value=0, maximum=len(pend))
        threading.Thread(target=self._worker, args=(pend,), daemon=True).start()

    def stop(self):
        self.stop_flag = True
        if self.proc and self.proc.poll() is None:
            try:
                self.proc.kill()
            except OSError:
                pass
        self.log_write("\n已请求停止, 等当前这条结束后停下...\n", "warn")

    def _worker(self, pend):
        py = find_backend_python()
        out_d = getattr(self, "_out_dir", None) or self.out_dir()
        want_text = getattr(self, "_want_text", True)
        no_win = 0x08000000 if os.name == "nt" else 0
        self.proj["running"] = True
        mark_running(self.proj, True)
        self.hb_ev = start_heartbeat(self.proj)
        self._save(out=out_d, grab_text="1" if want_text else "0")
        done_n = 0
        total = len(pend)

        def run_one(t):
            t["status"] = "提取中"
            self.log_q.put(("refresh", None))
            self.log_write("\n===== 提取 %s =====\n" % t.get("url"), "step")
            cmd = [py, "-u", backend_script(), "grab", t["url"],
                   "--out", out_d, "--retry", "1"]
            if want_text:
                cmd.append("--text")
            try:
                env = dict(os.environ, PYTHONIOENCODING="utf-8")
                self.proc = subprocess.Popen(
                    cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                    cwd=BASE_DIR, env=env, encoding="utf-8",
                    errors="replace", creationflags=no_win)
                buf = []
                for line in self.proc.stdout:
                    buf.append(line)
                    self.log_write(line)
                self.proc.wait()
                txt = "".join(buf)
                ok = self.proc.returncode == 0 and "✓" in txt
                m = re.search(r"✓\s*(.+?\.mp4)\s*\(([\d.]+)s\)", txt)
                skipped = bool(re.search(r"跳过 [1-9]", txt))
                if ok and m:
                    t["status"] = "完成"
                    t["result"] = "%s · %.1fs" % (m.group(1)[:34],
                                                  float(m.group(2)))
                elif ok:
                    t["status"] = "完成"
                    t["result"] = "已保存到项目目录"
                elif skipped and self.proc.returncode == 0:
                    # 之前提取过, 文件已经在了 —— 不算失败
                    t["status"] = "完成"
                    t["result"] = "之前已提取过 (勾'重新下载'可重下)"
                else:
                    t["status"] = "失败"
                    if ("风控" in txt) or ("验证码" in txt):
                        t["result"] = "抖音风控 · 等会单独重跑这条"
                    else:
                        err = [l for l in txt.splitlines()
                               if "✗" in l or "失败" in l]
                        t["result"] = (err[-1].strip()[:40] if err
                                       else "提取失败 · 看日志")
            except Exception as e:
                t["status"] = "失败"
                t["result"] = str(e)[:40]
            self._save(out=out_d, grab_text="1" if want_text else "0")
            self.log_q.put(("refresh", None))

        # ---------------- 第一轮 ----------------
        for i, t in enumerate(pend):
            if self.stop_flag:
                break
            run_one(t)
            done_n += 1
            self.log_q.put(("prog", done_n))
            if not self.stop_flag and i < total - 1:
                time.sleep(random.uniform(2.0, 4.0))   # 链接间降频, 减风控

        # -------- 风控自动补救: 冷风一轮后把失败的自动重跑一遍 --------
        retry_list = [t for t in pend if t.get("status") == "失败"]
        if retry_list and not self.stop_flag:
            cooldown = 75
            self.log_write(
                "\n检测到 %d 条失败(多为抖音风控). 冷却 %d 秒后自动重跑这一轮...\n"
                % (len(retry_list), cooldown), "warn")
            for _ in range(cooldown):
                if self.stop_flag:
                    break
                time.sleep(1)
            if not self.stop_flag:
                for t in retry_list:
                    t["status"] = "等待中"
                    t["result"] = "风控冷却后自动重跑"
                self.log_q.put(("refresh", None))
                self.log_write("冷却结束, 开始重跑失败的 %d 条...\n"
                               % len(retry_list), "step")
                for i, t in enumerate(retry_list):
                    if self.stop_flag:
                        break
                    run_one(t)
                    if not self.stop_flag and i < len(retry_list) - 1:
                        time.sleep(random.uniform(3.0, 6.0))

        self.proj["running"] = False
        if getattr(self, "hb_ev", None):
            self.hb_ev.set()
        mark_running(self.proj, False)
        self._save(out=out_d, grab_text="1" if want_text else "0")
        self.log_q.put(("grab_done", None))

    # ---------------- 日志 ----------------
    def log_write(self, text, tag=None):
        self.log_q.put(("log", text, tag))
        log_sink(getattr(self, "_log_fp", None), text)

    def _poll(self):
        try:
            while True:
                item = self.log_q.get_nowait()
                if item[0] == "log":
                    _, text, tag = item
                    self.log.configure(state="normal")
                    self.log.insert("end", text, tag or ())
                    self.log.see("end")
                    self.log.configure(state="disabled")
                elif item[0] == "refresh":
                    self._refresh_tree()
                elif item[0] == "prog":
                    self.prog.configure(value=item[1])
                elif item[0] == "grab_done":
                    self.running = False
                    self.proc = None
                    self.go_btn.configure(state="normal", text="开 始 提 取")
                    self.stop_btn.configure(state="disabled")
                    ok_n = sum(1 for t in self.tasks if t.get("status") == "完成")
                    bad_n = sum(1 for t in self.tasks if t.get("status") == "失败")
                    self.log_write(
                        "\n提取结束: 完成 %d 条, 失败 %d 条 -> %s\n"
                        % (ok_n, bad_n, self.out_dir()), "ok")
        except queue.Empty:
            pass
        self.root.after(120, self._poll)

    def close(self):
        busy = bool(self.proc and self.proc.poll() is None)
        if self.running and busy:
            if not messagebox.askyesno(
                    "任务进行中",
                    "还有链接在提取, 关闭窗口会中止本次提取。\n\n确定关闭吗?"):
                return
        if busy:
            try:
                self.proc.kill()
            except (OSError, ValueError):
                pass
        if getattr(self, "hb_ev", None):
            self.hb_ev.set()
        mark_running(self.proj, False)
        self.proj["running"] = False
        if getattr(self, "running", False):
            self.log_write("\n[窗口已关闭] 本次提取被中断, 重开本项目可继续提取剩下的。\n",
                           "warn")
        self._save()
        try:
            if getattr(self, "_log_fp", None):
                self._log_fp.close()
        except (OSError, ValueError):
            pass
        self._log_fp = None
        self.root.destroy()


class App:
    def __init__(self, root, project=None):
        self.root = root
        self.proj = project or load_project("默认项目")
        self.proj_name = self.proj.get("name", "默认项目")
        self._loading = True
        root.title("VideoMixCut · %s%s" % (
            self.proj_name, " v" + APP_VERSION if APP_VERSION else ""))
        root.geometry("820x760")
        root.minsize(760, 700)
        root.configure(bg=BG)
        style_widget(root)
        self.log_q = queue.Queue()
        # 帮助菜单: 检查更新 / 导入更新包 / 授权信息
        menubar = tk.Menu(root)
        m_proj = tk.Menu(menubar, tearoff=0)
        m_proj.add_command(label="新建项目 (复制当前参数)...",
                           command=self.proj_new)
        m_proj.add_command(label="项目列表 / 切换项目...",
                           command=self.proj_list)
        m_proj.add_separator()
        m_proj.add_command(label="打开本项目素材文件夹",
                           command=self.proj_open_src)
        m_proj.add_command(label="打开本项目成片目录",
                           command=self.proj_open_out)
        menubar.add_cascade(label="项目", menu=m_proj)
        m_help = tk.Menu(menubar, tearoff=0)
        m_help.add_command(label="检查更新", command=self.check_update)
        m_help.add_command(label="功能说明", command=self.show_features)
        m_help.add_command(label="AI 审片设置...", command=self.show_ai_settings)
        m_help.add_command(label="重新检测本机硬件配置...",
                           command=self.hw_redetect)
        m_help.add_command(label="导入更新包 (微信收到的zip)...",
                           command=self.import_update)
        m_help.add_separator()
        m_help.add_command(label="授权信息", command=self.show_license)
        menubar.add_cascade(label="帮助", menu=m_help)
        root.config(menu=menubar)
        self.running = False
        self.proc = None
        self.hb_ev = None
        self._log_fp = None
        self.hw_note_val = ""
        # 后台任务相关: attached=本窗口正"接"着一个后台任务(只是看客)
        self.attached = False
        self.runner = None
        self._tail_off = 0
        self._last_state = {}
        self._last_sync = 0.0
        self._build_ui()
        self._load_params()
        self._bind_autosave()
        self._loading = False
        # 运行日志落盘 + 回显上次运行记录 (关窗重开不再一片空白)
        self._log_fp = open_run_log(self.proj)
        if not self._attach_if_running():
            load_log_tail(self.log, self.proj)
            if heal_stale_running(self.proj):
                self.log_write("[提示] 上次出片没有正常结束(窗口被关闭或软件被"
                               "结束后没来得及收尾), 状态已自动重置, "
                               "直接点「开始出片」重新跑即可。\n\n", "warn")
            else:
                self._note_last_result()
        threading.Thread(target=self._hw_boot, daemon=True).start()
        self._poll_log()
        # 开机自动检查更新(静默, 有新版本则后台自动应用)
        self.auto_update_on_launch()

    # ---------------- 后台任务: 接上 / 实时同步 / 中止 ----------------
    def _attach_if_running(self):
        """打开项目窗口时, 若这个项目正在后台跑 -> 直接接上(实时日志+进度)"""
        st = read_run_state(self.proj)
        alive = running_alive(self.proj)
        if not (alive or st.get("status") == "running"):
            return False
        self.attached = True
        self.running = True
        self.proj["running"] = True
        try:
            os.makedirs(project_data_dir(self.proj), exist_ok=True)
        except OSError:
            pass
        self.log.configure(state="normal")
        self.log.delete("1.0", "end")
        self.log.configure(state="disabled")
        step = st.get("step") or 0
        total = st.get("total") or 0
        self._append_log(
            "\n===== 已接上正在后台运行的任务%s =====\n"
            "本窗口只是「看客」: 日志/进度实时刷新, 关掉窗口任务照样继续跑。\n\n"
            % ((" (第 %d/%d 步 %s)" % (step, total, st.get("title") or ""))
               if step and total else ""), "ok")
        load_log_tail(self.log, self.proj)
        try:
            self._tail_off = os.path.getsize(run_log_path(self.proj))
        except OSError:
            self._tail_off = 0
        self._last_state = st
        self._last_sync = 0.0
        self._set_run_ui(True)
        if step and total:
            self.prog.configure(value=step)
            self.status_var.set("后台运行中 · 第 %d/%d 步" % (step, total))
        else:
            self.status_var.set("后台运行中...")
        return True

    def _note_last_result(self):
        """上次的活是在窗口关着的时候跑完的 -> 开窗时先告诉用户结果"""
        st = read_run_state(self.proj)
        s = st.get("status")
        if s not in ("done", "error", "stopped"):
            return
        try:
            fin = float(st.get("finished") or 0)
        except (TypeError, ValueError):
            fin = 0
        if not fin or (time.time() - fin) > 7 * 86400:
            return
        stamp = time.strftime("%m-%d %H:%M", time.localtime(fin))
        txt, tag = {"done": ("✅ 出片成功", "ok"),
                    "error": ("✗ 出片失败", "err"),
                    "stopped": ("⏹ 已中止", "warn")}[s]
        keep = st.get("note") or ""
        self.log_write("[上次后台任务 · %s] %s%s\n\n"
                       % (stamp, txt, ("  —  " + keep) if keep else ""), tag)

    def _tail_backend(self):
        """把后台任务写下的新日志贴进窗口 (任务进程独立写文件, 这里只读)"""
        if not getattr(self, "attached", False):
            return
        path = run_log_path(self.proj)
        try:
            size = os.path.getsize(path)
        except OSError:
            return
        if size < self._tail_off:          # 日志被清空/轮转过 -> 从头读
            self._tail_off = 0
        if size <= self._tail_off:
            return
        try:
            with open(path, encoding="utf-8", errors="replace") as f:
                f.seek(self._tail_off)
                chunk = f.read()
                self._tail_off = f.tell()
        except OSError:
            return
        if chunk:
            self._append_log(chunk)

    def _sync_state(self):
        """读后台任务进度: 更新进度条/状态栏; 跑完了就收尾"""
        if not getattr(self, "attached", False):
            return
        st = read_run_state(self.proj)
        if st:
            self._last_state = st
        else:
            st = self._last_state or {}
        status = st.get("status")
        if status == "running":
            step = int(st.get("step") or 0)
            total = int(st.get("total") or 5)
            self.prog.configure(value=step)
            ti = st.get("title") or ""
            self.status_var.set("后台运行中 · 第 %d/%d 步  %s" % (step, total, ti))
            return
        if status in ("done", "error", "stopped"):
            # 防误判: 刚点完开始出片时, 状态文件可能还是上一轮的旧结果
            try:
                sd = float(st.get("started") or 0)
            except (TypeError, ValueError):
                sd = 0
            t0 = getattr(self, "_run_t0", 0)
            if sd and t0 and sd < t0 - 2:
                return
            self._detach_finish(status, st)
            return
        if not st and getattr(self, "runner", None) is not None:
            # 状态文件还没出现, 但任务进程已经退了 -> 启动就失败了
            try:
                if self.runner.poll() is not None and not running_alive(self.proj):
                    self._detach_finish("unknown", {})
                    return
            except OSError:
                pass
        if not running_alive(self.proj):        # 状态文件没读到 且 心跳也没了
            self._detach_finish("unknown", st)

    def _detach_finish(self, status, st):
        """后台任务结束 -> 界面恢复, 并按结果给提示"""
        if not getattr(self, "attached", False):
            return
        self.attached = False
        self.running = False
        self.runner = None
        self._tail_backend()                    # 把最后几行补上
        mark_running(self.proj, False)
        self.proj["running"] = False
        self.proj["note"] = ""
        self._set_run_ui(False)
        if getattr(self, "hb_ev", None):
            self.hb_ev.set()
        outdir = self.proj_out_dir()
        if status == "done":
            self.prog.configure(value=5)
            self.status_var.set("完成 ✓")
            self.proj["last_run"] = time.strftime("%Y-%m-%d %H:%M")
            self.proj["last_output"] = outdir
            self._save_params()
            self.log_write("\n✅ 出片完成! 成片在: %s\n" % outdir, "ok")
            # 直接打开成片目录(非弹窗), 不再用 messagebox 打断
            try:
                os.startfile(outdir)            # noqa: S606
            except Exception:
                pass
        elif status == "stopped":
            self.prog.configure(value=0)
            self.status_var.set("已中止 · 可重新出片")
            self._save_params()
            self.log_write("\n⏹ 本次出片已停止, 已完成步骤成果保留, "
                          "再点「开始出片」会接着跑。\n", "warn")
        elif status == "unknown":
            self.status_var.set("后台任务已结束 · 详见日志")
            self.log_write("\n[后台任务已结束] 没读到结束记录(可能被强制结束), "
                           "请按上面的日志确认结果。\n", "warn")
            self._save_params()
        else:                                   # error
            self.prog.configure(value=0)
            self.status_var.set("失败 · 详见日志")
            self._save_params()
            messagebox.showerror("失败", "出片失败: %s\n请查看日志中的报错信息"
                                 % (st.get("note") or ""))

    def stop_run(self):
        """中途停止本次出片 (给后台任务下 stop.flag)"""
        if not (getattr(self, "attached", False) or running_alive(self.proj)):
            return
        if not messagebox.askyesno(
                "停止出片",
                "确定停止本次出片吗?\n\n"
                "已经跑完的步骤成果不会丢(例如已识别好的字幕), "
                "下次点「开始出片」会自动跳过已完成的部分。"):
            return
        request_stop(self.proj)
        self.log_write("\n[已发出停止指令] 正在结束当前步骤, 请稍候...\n", "warn")
        self.status_var.set("正在停止...")

    # ---------------- 项目参数 ----------------
    def _param_vars(self):
        """项目要保存的参数: (存储键, tk变量)"""
        pairs = [("src", "src_var"), ("out", "out_var"),
                 ("bgm_mode", "bgm_mode"), ("bgm_file", "bgm_file_var"),
                 ("bgm_name", "bgm_name_var"), ("sticker", "sticker_var"),
                 ("wm", "wm_var"), ("variant", "variant_var"),
                 ("mirror", "mirror_var"), ("count", "count_var"),
                 ("duration", "duration_var"), ("transition", "transition_var"),
                 ("voice", "voice_var"), ("flow", "flow_var"),
                 ("broll", "broll_var"), ("subtitle", "subtitle_var"),
                 ("polish", "polish_var"), ("aiplan", "aiplan_var"),
                 ("cover", "cover_var"), ("encoder", "enc_var")]
        return [(k, getattr(self, v)) for k, v in pairs
                if hasattr(self, v)]

    def _load_params(self):
        p = self.proj.get("params") or {}
        src = self.proj.get("src") or ""
        out = self.proj.get("out") or ""
        for key, var in self._param_vars():
            val = p.get(key)
            if key == "src" and src:
                val = src
            if key == "out" and out:
                val = out
            if val not in (None, ""):
                try:
                    var.set(val)
                except Exception:
                    pass

    def _save_params(self):
        if getattr(self, "_loading", False):
            return
        try:
            p = {k: v.get() for k, v in self._param_vars()}
            self.proj["params"] = p
            self.proj["src"] = p.get("src", "")
            self.proj["out"] = p.get("out", "")
            self.proj["name"] = self.proj_name
            save_project(self.proj)
        except Exception:
            pass

    def _bind_autosave(self):
        for _k, var in self._param_vars():
            var.trace_add("write", lambda *_a: self._save_params())

    # ---------------- 硬件自检 (每台电脑配置不同, 自动选最优方案) ----------------
    def _hw_query(self, refresh=False):
        """调后端做硬件体检, 返回人话描述 (如: RTX 2060 · 12核 -> 显卡编码)"""
        try:
            args = [find_backend_python(), "-u", backend_script(), "hwinfo"]
            if refresh:
                args.append("--refresh")
            no_win = 0x08000000 if os.name == "nt" else 0
            r = subprocess.run(args, capture_output=True, cwd=BASE_DIR,
                               timeout=240, encoding="utf-8",
                               errors="replace", creationflags=no_win)
            for line in (r.stdout or "").splitlines():
                if line.strip().startswith("本机:"):
                    return line.strip().replace("本机:", "").strip()
        except Exception:
            pass
        return ""

    def _hw_boot(self):
        """开机自检: 日志首行显示本机方案, 让用户知道有没有用上显卡"""
        note = self._hw_query(False)
        if note:
            self.log_q.put(("hw_done", note, True))

    def hw_redetect(self):
        """手动重新检测 (换了电脑/装了新显卡/驱动更新后用)"""
        self.log_write("\n正在重新检测本机配置...\n", "dim")

        def work():
            note = self._hw_query(True)
            self.log_q.put(("hw_done", note, False))
        threading.Thread(target=work, daemon=True).start()

    def proj_dir(self):
        """本项目工作目录 (空=沿用软件全局 data/output, 老项目兼容)"""
        return self.proj.get("workdir") or ""

    def proj_out_dir(self):
        return (self.out_var.get().strip()
                or (os.path.join(self.proj_dir(), "output")
                    if self.proj_dir() else os.path.join(BASE_DIR, "output")))

    def proj_new(self):
        dlg = tk.Toplevel(self.root)
        dlg.title("新建项目 (复制当前参数)")
        dlg.geometry("480x170")
        dlg.configure(bg=BG)
        style_widget(dlg)
        dlg.transient(self.root)
        dlg.grab_set()
        tk.Label(dlg, text="新项目名称", bg=BG, fg=TEXT,
                 font=(FONT, 12, "bold")).pack(pady=(16, 6))
        var = tk.StringVar(value=self.proj_name + "-副本")
        e = ttk.Entry(dlg, textvariable=var, width=40, font=(FONT, 11))
        e.pack(ipady=4)
        e.focus_set()
        e.select_range(0, "end")
        res = {"name": None}

        def ok_():
            n = var.get().strip()
            if not n:
                return
            res["name"] = n
            dlg.destroy()

        e.bind("<Return>", lambda ev: ok_())
        frm = tk.Frame(dlg, bg=BG)
        frm.pack(pady=16)
        b1 = tk.Button(frm, text="创建并打开", command=ok_, bg=ACCENT,
                       fg="#141414", activebackground=ACCENT_DK,
                       activeforeground="#fff", relief="flat", padx=18,
                       cursor="hand2", font=(FONT, 10, "bold"))
        b1.pack(side="left", padx=6)
        hover_button(b1, ACCENT, ACCENT_DK)
        b2 = tk.Button(frm, text="取消", command=dlg.destroy, bg=CARD2,
                       fg=TEXT, activebackground=BORDER, activeforeground=TEXT,
                       relief="flat", padx=14, cursor="hand2", font=(FONT, 10))
        b2.pack(side="left", padx=6)
        hover_button(b2, CARD2, BORDER)
        self.root.wait_window(dlg)
        if not res["name"]:
            return
        self._save_params()
        new_project(res["name"], self.proj.get("src", ""),
                    copy_from=self.proj_name)
        open_project_window(res["name"])

    def proj_list(self):
        open_project_window("__manager__")

    def proj_open_src(self):
        d = self.src_var.get().strip()
        if d and os.path.isdir(d):
            try:
                os.startfile(d)
            except OSError:
                pass
        else:
            messagebox.showinfo("提示", "本项目还没设置素材文件夹")

    def proj_open_out(self):
        d = self.proj_out_dir()
        os.makedirs(d, exist_ok=True)
        try:
            os.startfile(d)
        except OSError:
            pass

    # ---------------- UI ----------------
    def _build_ui(self):
        self._build_header()
        body = tk.Frame(self.root, bg=BG)
        body.pack(fill="both", expand=True)
        self._build_step1(body)
        self._build_step2(body)
        self._build_step3(body)
        self._build_step4(body)
        self._build_go(body)
        self._build_log(body)
        self._build_statusbar()

    def _build_header(self):
        hd = tk.Frame(self.root, bg=CARD, highlightbackground=BORDER,
                      highlightthickness=1, bd=0)
        hd.pack(fill="x", padx=12, pady=(12, 6))
        inner = tk.Frame(hd, bg=CARD)
        inner.pack(fill="x", padx=14, pady=12)
        logo = tk.Canvas(inner, width=44, height=44, bg=CARD,
                         highlightthickness=0)
        logo.pack(side="left", padx=(0, 10))
        logo.create_oval(2, 2, 42, 42, fill=ACCENT, outline="")
        logo.create_text(22, 22, text="剪", fill="#141414",
                         font=(FONT, 17, "bold"))
        tbox = tk.Frame(inner, bg=CARD)
        tbox.pack(side="left")
        tk.Label(tbox, text="项目: " + self.proj_name,
                 bg=CARD, fg=TEXT, font=(FONT, 15, "bold")).pack(anchor="w")
        tk.Label(tbox, text="扫描 → 文案分析 → 人声分离 → 配乐混剪 → 去重出片 → 自检",
                 bg=CARD, fg=MUTED, font=(FONT, 9)).pack(anchor="w")
        b_pl = tk.Button(tbox, text="切换/新建项目", command=self.proj_list,
                         bg=CARD2, fg=ACCENT, activebackground=BORDER,
                         activeforeground=ACCENT, relief="flat", padx=10,
                         cursor="hand2", font=(FONT, 9, "bold"))
        b_pl.pack(anchor="w", pady=(4, 0))
        hover_button(b_pl, CARD2, BORDER)
        chips = tk.Frame(inner, bg=CARD)
        chips.pack(side="right")
        ok, info = activation.verify_license()
        if ok:
            exp = info.get("exp")
            lic = "永久授权" if not exp else time.strftime(
                "授权至 %m-%d", time.localtime(exp))
            lic_color = GREEN
        else:
            lic, lic_color = "未激活", YELLOW
        for txt, fg, bgc in ((("v" + APP_VERSION) if APP_VERSION else "v?", ACCENT, "#241a15"),
                             (lic, lic_color, "#15241b")):
            c = tk.Label(chips, text="  " + txt + "  ", bg=bgc, fg=fg,
                         font=(FONT, 9, "bold"), padx=4)
            c.pack(side="left", padx=3)

    def _build_step1(self, parent):
        c1 = card(parent)
        card_title(c1, 1, "素材文件夹", "自动扫描所有子文件夹")
        row = tk.Frame(c1, bg=CARD)
        row.pack(fill="x", padx=12, pady=(2, 10))
        ttk.Entry(row, textvariable=self._sv("src_var")).pack(
            side="left", fill="x", expand=True)
        b = tk.Button(row, text="浏览", command=self.pick_src, bg=CARD2,
                      fg=TEXT, activebackground=BORDER, activeforeground=TEXT,
                      relief="flat", padx=14, cursor="hand2",
                      font=(FONT, 10))
        b.pack(side="left", padx=(8, 0))
        hover_button(b, CARD2, BORDER)
        # 链接提取已独立为「提取项目」类型, 不再内嵌在混剪窗口里(更整洁)

    def _build_grab(self, parent, c1):
        """链接提取: 分享链接 -> 无水印视频(+口播文案) -> 直接进素材文件夹"""
        g = tk.Frame(c1, bg=CARD, highlightbackground=BORDER,
                     highlightthickness=1)
        g.pack(fill="x", padx=12, pady=(0, 10))
        tk.Label(g, text="链接提取  没素材? 粘贴抖音/B站等分享链接直接拿",
                 bg=CARD, fg=ACCENT, font=(FONT, 10, "bold")).pack(
            anchor="w", padx=10, pady=(8, 2))
        row = tk.Frame(g, bg=CARD)
        row.pack(fill="x", padx=10, pady=(0, 4))
        self.grab_url_var = tk.StringVar()
        ttk.Entry(row, textvariable=self.grab_url_var).pack(
            side="left", fill="x", expand=True, ipady=3)
        self.grab_btn = tk.Button(row, text="提取", command=self.grab_one,
                                  bg=ACCENT, fg="#141414",
                                  activebackground=ACCENT_DK,
                                  activeforeground="#141414", relief="flat",
                                  padx=14, cursor="hand2",
                                  font=(FONT, 9, "bold"))
        self.grab_btn.pack(side="left", padx=(8, 0))
        hover_button(self.grab_btn, ACCENT, ACCENT_DK)
        row2 = tk.Frame(g, bg=CARD)
        row2.pack(fill="x", padx=10, pady=(0, 8))
        self.grab_txt_var = tk.StringVar()
        ttk.Entry(row2, textvariable=self.grab_txt_var, width=30,
                  state="readonly").pack(side="left")
        tk.Button(row2, text="TXT批量", command=self.pick_grab_txt,
                  bg=CARD2, fg=TEXT, activebackground=BORDER,
                  activeforeground=TEXT, relief="flat", padx=10,
                  cursor="hand2", font=(FONT, 9)).pack(side="left", padx=6)
        self.grab_batch_btn = tk.Button(row2, text="批量提取",
                                        command=self.grab_batch,
                                        bg=CARD2, fg=GREEN,
                                        activebackground=BORDER,
                                        activeforeground=GREEN, relief="flat",
                                        padx=10, cursor="hand2",
                                        font=(FONT, 9, "bold"))
        self.grab_batch_btn.pack(side="left", padx=6)
        self.grab_text_var = tk.StringVar(value="1")
        ttk.Checkbutton(row2, text="同时提取口播文案",
                        variable=self.grab_text_var).pack(side="left",
                                                          padx=(10, 0))
        tk.Label(row2, text="(提取的视频自动存进上面的素材文件夹, 可直接开始出片)",
                 bg=CARD, fg=MUTED, font=(FONT, 8)).pack(side="right")

    def pick_grab_txt(self):
        p = filedialog.askopenfilename(
            title="选择包含链接的文本", filetypes=[("文本文件", "*.txt *.md *.csv")])
        if p:
            self.grab_txt_var.set(p)

    def _grab_worker(self, url_or_txt):
        ok = True
        try:
            py = find_backend_python()
            env = dict(os.environ, PYTHONIOENCODING="utf-8")
            models_dir = os.path.join(BASE_DIR, "models")
            if os.path.isdir(models_dir):
                env.setdefault("TORCH_HOME", models_dir)
            no_win = 0x08000000 if os.name == "nt" else 0
            cmd = [py, "-u", backend_script(), "grab", url_or_txt,
                   "--out", self._sv("src_var").get().strip()
                   or os.path.join(BASE_DIR, "output")]
            if self.grab_text_var.get() == "1":
                cmd.append("--text")
            proc = subprocess.Popen(
                cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                cwd=BASE_DIR, env=env, encoding="utf-8", errors="replace",
                creationflags=no_win)
            for line in proc.stdout:
                self.log_write(line)
            proc.wait()
            if proc.returncode != 0:
                ok = False
                self.log_write("\n✗ 提取失败, 请看上方日志\n", "err")
            if ok:
                self.log_write("\n✅ 提取完成! 视频已在素材文件夹里, "
                               "点【开始出片】即可混剪\n", "ok")
        except Exception as e:
            self.log_write("\n✗ 发生异常: %s\n" % e, "err")
            ok = False
        self.log_q.put(("grab_done", ok))

    def grab_one(self):
        if self.running:
            messagebox.showinfo("提示", "当前有任务在执行, 请等完成后再提取")
            return
        url = self.grab_url_var.get().strip()
        if not url:
            messagebox.showwarning("提示", "请先粘贴视频分享链接 (整段分享文字也行)")
            return
        self.running = True
        self.grab_btn.configure(state="disabled")
        self.grab_batch_btn.configure(state="disabled")
        self.status_var.set("提取中 · 下载视频" +
                            ("+文案" if self.grab_text_var.get() == "1" else ""))
        threading.Thread(target=self._grab_worker, args=(url,),
                         daemon=True).start()

    def grab_batch(self):
        if self.running:
            messagebox.showinfo("提示", "当前有任务在执行, 请等完成后再提取")
            return
        p = self.grab_txt_var.get().strip()
        if not p or not os.path.exists(p):
            messagebox.showwarning("提示", "请先选择包含链接的 TXT 文件")
            return
        self.running = True
        self.grab_btn.configure(state="disabled")
        self.grab_batch_btn.configure(state="disabled")
        self.status_var.set("批量提取中...")
        threading.Thread(target=self._grab_worker, args=(p,),
                         daemon=True).start()

    def _sv(self, name):
        """惰性创建 StringVar(重写UI时保持变量名兼容)"""
        if not hasattr(self, name):
            setattr(self, name, tk.StringVar())
        return getattr(self, name)

    def _build_step2(self, parent):
        c2 = card(parent)
        card_title(c2, 2, "背景音乐", "原片BGM自动去除, 只保留人声")
        row = tk.Frame(c2, bg=CARD)
        row.pack(fill="x", padx=12, pady=(2, 4))
        self.bgm_mode = tk.StringVar(value="random")
        for txt, val in [("随机曲库", "random"), ("合成BGM", "synth"),
                         ("本地音乐", "file"), ("指定曲名", "name"),
                         ("按文案情绪", "mood"), ("只留人声", "none")]:
            ttk.Radiobutton(row, text=txt, value=val, variable=self.bgm_mode,
                            command=self._bgm_refresh,
                            style="TRadiobutton").pack(side="left", padx=7)
        self.bgm_name_var = tk.StringVar()
        self.bgm_name_combo = ttk.Combobox(c2, textvariable=self.bgm_name_var,
                                           state="readonly")
        self.bgm_file_var = tk.StringVar()
        self.bgm_file_row = tk.Frame(c2, bg=CARD)
        ttk.Entry(self.bgm_file_row, textvariable=self.bgm_file_var).pack(
            side="left", fill="x", expand=True, pady=(0, 4))
        b = tk.Button(self.bgm_file_row, text="选择音乐", command=self.pick_bgm,
                      bg=CARD2, fg=TEXT, activebackground=BORDER,
                      activeforeground=TEXT, relief="flat", padx=12,
                      cursor="hand2", font=(FONT, 10))
        b.pack(side="left", padx=(8, 0))
        hover_button(b, CARD2, BORDER)
        self._bgm_refresh()
        tk.Frame(c2, bg=CARD, height=8).pack()

    def _build_step3(self, parent):
        c3 = card(parent)
        card_title(c3, 3, "画面与去重", "每条随机轮换 9 套画面参数")
        row = tk.Frame(c3, bg=CARD)
        row.pack(fill="x", padx=12, pady=(2, 10))
        self.sticker_var = tk.StringVar(value="cute")
        self.wm_var = tk.StringVar()
        self.variant_var = tk.StringVar(value="自动")
        self.mirror_var = tk.StringVar(value="自动")
        self.dedup_var = tk.StringVar(value="关")
        fields = [("贴纸", self.sticker_var,
                  ["cute", "ai", "zhongqiu", "universal", "watermark", "none"], 12),
                  ("风格", self.variant_var,
                   ["自动", "1", "2", "3", "4", "5", "6", "7", "8", "9"], 6),
                  ("镜像", self.mirror_var, ["自动", "开启", "关闭"], 6),
                  ("去重", self.dedup_var, ["关", "开"], 6)]
        for label, var, vals, w in fields:
            tk.Label(row, text=label, bg=CARD, fg=MUTED,
                     font=(FONT, 10)).pack(side="left")
            ttk.Combobox(row, textvariable=var, state="readonly",
                         width=w, values=vals).pack(side="left", padx=(4, 10))
        tk.Label(row, text="水印文字", bg=CARD, fg=MUTED,
                 font=(FONT, 10)).pack(side="left")
        ttk.Entry(row, textvariable=self.wm_var, width=14).pack(
            side="left", padx=4)
        # 联网获取可商用素材(BGM) 按钮
        frow = tk.Frame(c3, bg=CARD)
        frow.pack(fill="x", padx=12, pady=(2, 10))
        fb = tk.Button(frow, text="联网获取素材(可商用BGM)",
                       command=self.fetch_assets, bg=CARD2, fg=TEXT,
                       activebackground=BORDER, activeforeground=TEXT,
                       relief="flat", padx=12, cursor="hand2", font=(FONT, 10))
        fb.pack(side="left")
        hover_button(fb, CARD2, BORDER)
        tk.Label(frow, text="(从内置可商用清单下载 BGM 到曲库, 失败自动跳过)",
                 bg=CARD, fg=MUTED, font=(FONT, 8)).pack(side="left", padx=8)

    def _build_step4(self, parent):
        c4 = card(parent)
        card_title(c4, 4, "出片设置", "批量条条独立随机方案")
        row = tk.Frame(c4, bg=CARD)
        row.pack(fill="x", padx=12, pady=(2, 10))
        self.out_var = tk.StringVar()
        self.count_var = tk.StringVar(value="1")
        self.duration_var = tk.StringVar(value="自动")
        self.transition_var = tk.StringVar(value="无")
        ttk.Entry(row, textvariable=self.out_var).pack(
            side="left", fill="x", expand=True)
        b = tk.Button(row, text="导出到...", command=self.pick_out, bg=CARD2,
                      fg=TEXT, activebackground=BORDER, activeforeground=TEXT,
                      relief="flat", padx=12, cursor="hand2", font=(FONT, 10))
        b.pack(side="left", padx=(8, 0))
        hover_button(b, CARD2, BORDER)
        row2 = tk.Frame(c4, bg=CARD)
        row2.pack(fill="x", padx=12, pady=(0, 10))
        pairs = [("出片数量", [("1", "1"), ("5", "5"), ("10", "10"), ("20", "20")]),
                 ("目标时长", [("自动", "自动"), ("30秒", "30秒"), ("45秒", "45秒"), ("60秒", "60秒")]),
                 ("段间转场", [("无", "无"), ("溶解", "溶解")])]
        self._cb_vars = {}
        for label, vals in pairs:
            tk.Label(row2, text=label, bg=CARD, fg=MUTED,
                     font=(FONT, 10)).pack(side="left")
            cb = ttk.Combobox(row2, state="readonly", width=5,
                              values=[v[1] for v in vals])
            cb.set(vals[0][1])
            cb.pack(side="left", padx=(4, 12))
        # 用具名变量接管
        self.count_var_cb = None
        # 出片数量用 Spinbox, 时长/转场用 Combobox 绑定已有变量
        row2.pack_forget()
        row2 = tk.Frame(c4, bg=CARD)
        row2.pack(fill="x", padx=12, pady=(0, 10))
        tk.Label(row2, text="出片数量", bg=CARD, fg=MUTED,
                 font=(FONT, 10)).pack(side="left")
        ttk.Spinbox(row2, from_=1, to=50, textvariable=self.count_var,
                    width=5).pack(side="left", padx=(4, 14))
        tk.Label(row2, text="目标时长", bg=CARD, fg=MUTED,
                 font=(FONT, 10)).pack(side="left")
        ttk.Combobox(row2, textvariable=self.duration_var, state="readonly",
                     width=5, values=["自动", "30秒", "45秒", "60秒"]).pack(
                         side="left", padx=(4, 14))
        tk.Label(row2, text="段间转场", bg=CARD, fg=MUTED,
                 font=(FONT, 10)).pack(side="left")
        ttk.Combobox(row2, textvariable=self.transition_var, state="readonly",
                     width=5, values=["无", "溶解"]).pack(side="left", padx=4)
        row3 = tk.Frame(c4, bg=CARD)
        row3.pack(fill="x", padx=12, pady=(0, 10))
        self.voice_var = tk.StringVar(value="auto")
        self.flow_var = tk.StringVar(value="off")
        self.broll_var = tk.StringVar(value="auto")
        self.subtitle_var = tk.StringVar(value="none")
        self.polish_var = tk.StringVar(value="off")
        self.aiplan_var = tk.StringVar(value="off")
        self.cover_var = tk.StringVar(value="开")
        self.enc_var = tk.StringVar(value="自动")
        for label, var, vals in (
                ("音色", self.voice_var, ["随机", "同主播", "换主播"]),
                ("过渡句", self.flow_var, ["关", "开"]),
                ("空镜遮切换", self.broll_var, ["自动", "开启", "关闭"]),
                ("字幕条", self.subtitle_var, ["无", "品牌"]),
                ("AI选段", self.aiplan_var, ["关", "开"]),
                ("AI审片", self.polish_var, ["关", "开"]),
                ("自动封面", self.cover_var, ["开", "关"])):
            tk.Label(row3, text=label, bg=CARD, fg=MUTED,
                     font=(FONT, 10)).pack(side="left")
            ttk.Combobox(row3, textvariable=var, state="readonly", width=5,
                         values=vals).pack(side="left", padx=(4, 12))
        row4 = tk.Frame(c4, bg=CARD)
        row4.pack(fill="x", padx=12, pady=(0, 10))
        tk.Label(row4, text="硬件加速", bg=CARD, fg=MUTED,
                 font=(FONT, 10)).pack(side="left")
        ttk.Combobox(row4, textvariable=self.enc_var, state="readonly",
                     width=6, values=["自动", "显卡", "CPU"]).pack(
                         side="left", padx=(4, 8))
        tk.Label(row4, text="有独立显卡时编码快约 6 倍 (画质一样)",
                 bg=CARD, fg=ACCENT, font=(FONT, 9)).pack(side="left")
        tk.Button(row3, text="功能说明", command=self.show_features,
                  bg=CARD2, fg=ACCENT, activebackground=BORDER,
                  activeforeground=ACCENT, relief="flat", padx=10,
                  cursor="hand2", font=(FONT, 9, "bold")).pack(side="right")
        tk.Button(row3, text="AI优化素材库", command=self.run_ailib,
                  bg=CARD2, fg="#7fb4ff", activebackground=BORDER,
                  activeforeground="#a8cdff", relief="flat", padx=10,
                  cursor="hand2", font=(FONT, 9, "bold")).pack(side="right",
                                                               padx=(0, 8))

    def run_ailib(self):
        """AI 优化素材库: 后台跑 ailib 命令, 日志实时显示"""
        if self.running:
            messagebox.showinfo("提示", "当前有任务在执行, 请等完成后再优化")
            return
        if not load_llm_cfg().get("api_key"):
            if not messagebox.askyesno(
                    "先配置 AI",
                    "AI优化素材库需要先配置 AI 密钥 (免费的, 一次配置)。\n"
                    "现在打开「AI 审片设置」吗?"):
                return
            self.show_ai_settings()
            return
        self.running = True
        self.go_btn.configure(state="disabled", text="AI 优化素材库中 ...")
        self.log_write("\n========== AI 优化素材库 ==========\n", "step")

        def work():
            ok = True
            try:
                py = find_backend_python()
                env = dict(os.environ, PYTHONIOENCODING="utf-8")
                models_dir = os.path.join(BASE_DIR, "models")
                if os.path.isdir(models_dir):
                    env.setdefault("TORCH_HOME", models_dir)
                no_win = 0x08000000 if os.name == "nt" else 0
                proc = subprocess.Popen(
                    [py, "-u", backend_script(), "ailib"],
                    stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                    cwd=BASE_DIR, env=env, encoding="utf-8", errors="replace",
                    creationflags=no_win)
                for line in proc.stdout:
                    self.log_write(line)
                proc.wait()
                ok = proc.returncode == 0
            except Exception as e:
                self.log_write("\n✗ 发生异常: %s\n" % e, "err")
                ok = False
            self.log_q.put(("ailib_done", ok))
        threading.Thread(target=work, daemon=True).start()

    def _build_go(self, parent):
        row = tk.Frame(parent, bg=BG)
        row.pack(fill="x", padx=12, pady=6)
        btf = tk.Frame(row, bg=BG)
        btf.pack(fill="x")
        self.go_btn = tk.Button(btf, text="开 始 出 片",
                                font=(FONT, 13, "bold"), bg=ACCENT, fg="#141414",
                                activebackground=ACCENT_DK, activeforeground="#fff",
                                relief="flat", cursor="hand2",
                                command=self.start, height=1, pady=10)
        self.go_btn.pack(side="left", fill="x", expand=True)
        hover_button(self.go_btn, ACCENT, ACCENT_DK)
        # 「停止」按钮: 默认不显示, 出片时 pack 出来 (关窗=后台继续, 要停就点它)
        self.stop_btn = tk.Button(btf, text="停 止", width=8,
                                  font=(FONT, 11, "bold"), bg=CARD2, fg="#ff6b6b",
                                  activebackground=BORDER,
                                  activeforeground="#ff6b6b",
                                  relief="flat", cursor="hand2",
                                  command=self.stop_run, height=1, pady=10)
        hover_button(self.stop_btn, CARD2, BORDER)
        self.prog = ttk.Progressbar(row, mode="determinate", maximum=5)
        self.prog.pack(fill="x", pady=(8, 0))

    def _set_run_ui(self, running):
        """出片中: 开始按钮置灰 + 露出「停止」; 结束: 恢复"""
        try:
            if running:
                self.go_btn.configure(state="disabled", text="出 片 中 ...")
                self.stop_btn.pack(side="left", padx=(8, 0))
            else:
                self.go_btn.configure(state="normal", text="开 始 出 片")
                self.stop_btn.pack_forget()
        except tk.TclError:
            pass

    def _build_log(self, parent):
        c5 = card(parent, pady=(6, 6))
        c5.pack_configure(fill="both", expand=True)
        card_title(c5, "▮", "处理日志", "实时输出")
        self.log = tk.Text(c5, height=10, state="disabled", wrap="none",
                           font=("Consolas", 9), bg=LOG_BG, fg="#c9d3e0",
                           insertbackground=TEXT, relief="flat",
                           selectbackground=ACCENT_DK)
        sb = ttk.Scrollbar(c5, command=self.log.yview)
        self.log.configure(yscrollcommand=sb.set)
        sb.pack(side="right", fill="y", padx=(0, 8), pady=(0, 8))
        self.log.pack(fill="both", expand=True, padx=(8, 0), pady=(0, 8))
        for tag, fg in (("ok", GREEN), ("err", "#ff6b6b"), ("dim", MUTED),
                        ("warn", YELLOW), ("step", ACCENT)):
            self.log.tag_configure(tag, foreground=fg)

    def _build_statusbar(self):
        sb = tk.Frame(self.root, bg=CARD2, highlightbackground=BORDER,
                      highlightthickness=1, bd=0)
        sb.pack(fill="x", side="bottom")
        self.status_var = tk.StringVar(value="就绪")
        tk.Label(sb, textvariable=self.status_var, bg=CARD2, fg=MUTED,
                 font=(FONT, 9)).pack(side="left", padx=12, pady=5)
        tk.Label(sb, text=("v" + APP_VERSION if APP_VERSION else "") +
                 "  ·  批量条条独立方案  ·  授权绑定机器",
                 bg=CARD2, fg=MUTED, font=(FONT, 9)).pack(
                     side="right", padx=12)

    def _bgm_refresh(self):
        m = self.bgm_mode.get()
        self.bgm_name_combo.pack_forget()
        self.bgm_file_row.pack_forget()
        if m == "name":
            names = self._list_bgm()
            self.bgm_name_combo["values"] = names
            if names and not self.bgm_name_var.get():
                self.bgm_name_var.set(names[0])
            self.bgm_name_combo.pack(fill="x", padx=12, pady=(0, 8))
        elif m == "file":
            self.bgm_file_row.pack(fill="x", padx=12)

    def _list_bgm(self):
        d = os.path.join(BASE_DIR, "bgm_library")
        if not os.path.isdir(d):
            return []
        return sorted(f for f in os.listdir(d)
                      if f.lower().endswith((".mp3", ".wav")))

    def pick_src(self):
        d = filedialog.askdirectory(title="选择成片视频所在文件夹")
        if d:
            self.src_var.set(os.path.normpath(d))

    def pick_bgm(self):
        f = filedialog.askopenfilename(title="选择背景音乐",
                                       filetypes=[("音频", "*.mp3 *.wav *.m4a *.flac *.aac"), ("所有文件", "*.*")])
        if f:
            self.bgm_file_var.set(os.path.normpath(f))

    def pick_out(self):
        d = filedialog.askdirectory(title="选择导出文件夹")
        if d:
            self.out_var.set(os.path.normpath(d))

    def fetch_assets(self):
        """联网获取可商用素材(BGM)到本地曲库 (后台子进程跑 fetchassets)"""
        if self.running:
            messagebox.showinfo("提示", "当前有任务在执行, 请等完成后再获取")
            return
        self.log_write("\n=== 联网获取可商用素材 ===\n", "ok")
        threading.Thread(target=self._fetch_worker, daemon=True).start()

    def _fetch_worker(self):
        try:
            py = find_backend_python()
            env = dict(os.environ, PYTHONIOENCODING="utf-8")
            models_dir = os.path.join(BASE_DIR, "models")
            if os.path.isdir(models_dir):
                env.setdefault("TORCH_HOME", models_dir)
            no_win = 0x08000000 if os.name == "nt" else 0
            cmd = [py, "-u", backend_script(), "fetchassets"]
            proc = subprocess.Popen(
                cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                cwd=BASE_DIR, env=env, encoding="utf-8", errors="replace",
                creationflags=no_win)
            for line in proc.stdout:
                self.log_write(line)
            proc.wait()
            self.log_write("\n[联网获取素材] 完成, 可在「BGM: 指定曲名」里选新下载的曲子\n",
                          "ok")
        except Exception as e:
            self.log_write("\n联网获取失败: %s\n" % e, "err")

    def log_write(self, text, tag=None):
        self.log_q.put(("log", text, tag))
        # 后台任务在跑时 run.log 由任务进程写, 界面别再插进去
        # (否则"实时接日志"会把界面的话重复显示一遍)
        if not getattr(self, "attached", False):
            log_sink(getattr(self, "_log_fp", None), text)

    def _append_log(self, text, tag=None):
        """直接贴进日志框 (后台任务的实时日志走这里, 不回写文件)"""
        try:
            self.log.configure(state="normal")
            self.log.insert("end", text, tag or ())
            self.log.see("end")
            self.log.configure(state="disabled")
        except tk.TclError:
            pass

    def _poll_log(self):
        try:
            while True:
                item = self.log_q.get_nowait()
                if item[0] == "log":
                    _, text, tag = item
                    self.log.configure(state="normal")
                    self.log.insert("end", text, tag or ())
                    self.log.see("end")
                    self.log.configure(state="disabled")
                elif item[0] == "step":
                    self.prog.configure(value=item[1])
                    self.status_var.set("处理中 · 第 %d/5 步" % item[1]
                                        if item[1] < 5 else "收尾中...")
                elif item[0] == "done":
                    self._finish(item[1])
                elif item[0] == "hw_done":
                    _, note, silent = item
                    if note:
                        self.hw_note_val = note
                        self.log_write("[本机配置] %s\n\n" % note, "dim")
                        if not silent:
                            messagebox.showinfo("本机配置", note)
                    elif not silent:
                        messagebox.showwarning(
                            "检测失败", "没能读取到本机配置, 将使用 CPU 编码")
                elif item[0] == "ailib_done":
                    self.running = False
                    self.go_btn.configure(state="normal", text="开 始 出 片")
                    if item[1]:
                        self.status_var.set("素材库优化完成 ✓")
                        self.log_write("\n✅ 素材库优化完成, 之后出片自动生效\n",
                                       "ok")
                    else:
                        self.status_var.set("素材库优化失败 · 详见日志")
                elif item[0] == "grab_done":
                    self.running = False
                    self.grab_btn.configure(state="normal")
                    self.grab_batch_btn.configure(state="normal")
                    self.status_var.set("提取完成 ✓" if item[1]
                                        else "提取失败 · 详见日志")
                elif item[0] == "update_found":
                    self._update_found(item[1])
                elif item[0] == "update_done":
                    self._update_done(item[1])
        except queue.Empty:
            pass
        # 后台任务: 实时接日志 + 同步进度 (窗口只是看客, 任务在独立进程里跑)
        self._tail_backend()
        if getattr(self, "attached", False):
            now = time.time()
            if now - getattr(self, "_last_sync", 0.0) >= 0.5:
                self._last_sync = now
                self._sync_state()
        self.root.after(80, self._poll_log)

    # ---------------- 在线更新 ----------------
    def check_update(self):
        threading.Thread(target=self._check_update_worker, daemon=True).start()

    def _check_update_worker(self):
        m = updater.check_update(BASE_DIR)
        if m:
            self.log_q.put(("update_found", m))
        else:
            self.log_q.put(("log", "\n当前已是最新版本\n", "dim"))

    def _update_found(self, m):
        note = str(m.get("note", "")).strip()
        ask = ("发现新版本 v%s!\n\n%s\n\n现在更新吗? (更新后软件会自动关闭, 重新打开即可)"
               % (m.get("version"), note or "修复与优化若干"))
        if messagebox.askyesno("发现新版本", ask):
            threading.Thread(target=self._do_update_worker,
                             args=(m,), daemon=True).start()

    def _do_update_worker(self, m):
        okc, why = updater.check_compatible(BASE_DIR)
        if not okc:
            messagebox.showwarning("无法更新", why)
            return
        self.log_q.put(("log", "\n正在下载更新包 v%s...\n" % m.get("version"), "dim"))
        cfg = updater.load_config(BASE_DIR)
        src = updater.resolve_update_url(m["url"], cfg.get("update_url", ""))
        import tempfile
        dest = os.path.join(tempfile.mkdtemp(prefix="vmc_upd_"), "update.zip")
        try:
            updater._fetch(src, dest)
        except OSError as e:
            self.log_q.put(("update_done", (False, "下载失败: %s" % e)))
            return
        self.log_q.put(("log", "下载完成, 正在应用更新...\n", "dim"))
        ok, msg = updater.apply_update_zip(
            dest, BASE_DIR,
            log=lambda s: self.log_q.put(("log", s + "\n", "dim")))
        self.log_q.put(("update_done", (ok, msg)))

    def _update_done(self, ok_msg):
        ok, msg = ok_msg
        if ok:
            # 优先用启动脚本(启动.vbs/启动.bat)重启; 都没有则直接重启自身进程
            launcher = None
            for nm in ("启动.vbs", "启动.bat"):
                p = os.path.join(BASE_DIR, nm)
                if os.path.exists(p):
                    launcher = p
                    break
            if launcher:
                if messagebox.askyesno(
                        "更新完成",
                        "已更新到 v%s!\n软件即将关闭, 请重新打开。\n"
                        "现在重启软件吗?" % msg):
                    try:
                        os.startfile(launcher)
                    except OSError:
                        pass
                    self.close()
            else:
                # 源码工作目录等无启动脚本的情况: 直接重新拉起自身
                if messagebox.askyesno(
                        "更新完成",
                        "已更新到 v%s!\n软件即将关闭。\n"
                        "现在重启软件吗?" % msg):
                    try:
                        import sys, subprocess
                        subprocess.Popen(
                            [sys.executable, os.path.abspath(sys.argv[0])])
                    except Exception:
                        pass
                    self.close()
        else:
            messagebox.showerror("更新失败", str(msg))

    def import_update(self):
        """手动导入更新包: 老板微信发来的 zip 双击不了时用这里"""
        p = filedialog.askopenfilename(
            title="选择更新包 zip", filetypes=[("更新包", "*.zip")])
        if not p:
            return
        okc, why = updater.check_compatible(BASE_DIR)
        if not okc:
            messagebox.showwarning("无法更新", why)
            return
        self.log_write("\n正在导入更新包: %s\n" % p, "dim")

        def work():
            ok, msg = updater.apply_update_zip(
                p, BASE_DIR,
                log=lambda s: self.log_q.put(("log", s + "\n", "dim")))
            self.log_q.put(("update_done", (ok, msg)))
        threading.Thread(target=work, daemon=True).start()

    # ---------------- 开机自动更新 (无感) ----------------
    def auto_update_on_launch(self):
        """开机自动检测: 有新版本则静默下载并应用, 完成后提示重启。
        仅在 config.update_url 已配置时生效; 同一进程仅自动检查一次。"""
        if getattr(type(self), "_auto_launched", False):
            return
        type(self)._auto_launched = True
        threading.Thread(target=self._auto_update_worker, daemon=True).start()

    def _auto_update_worker(self):
        try:
            m = updater.check_update(BASE_DIR)
        except Exception:
            return
        if not m:
            return
        self.log_q.put(("log",
                        "\n发现新版本 v%s, 正在后台自动更新(无需操作)...\n"
                        % m.get("version"), "ok"))
        okc, why = updater.check_compatible(BASE_DIR)
        if not okc:
            self.log_q.put(("log", "本次自动更新跳过: %s\n" % why, "warn"))
            return
        cfg = updater.load_config(BASE_DIR)
        src = updater.resolve_update_url(m["url"], cfg.get("update_url", ""))
        import tempfile as _tf
        dest = os.path.join(_tf.mkdtemp(prefix="vmc_upd_"), "update.zip")
        try:
            updater._fetch(src, dest)
        except OSError as e:
            self.log_q.put(("log", "自动更新下载失败: %s\n" % e, "warn"))
            return
        self.log_q.put(("log", "下载完成, 正在应用更新...\n", "dim"))
        ok, msg = updater.apply_update_zip(
            dest, BASE_DIR,
            log=lambda s: self.log_q.put(("log", s + "\n", "dim")))
        if ok:
            self.log_q.put(("log",
                            "已自动更新到 v%s, 下次打开软件即生效。\n" % msg, "ok"))
            try:
                messagebox.showinfo(
                    "更新完成",
                    "已自动更新到 v%s!\n\n软件将在下次打开时生效, "
                    "建议关闭后重新打开本软件。" % msg)
            except Exception:
                pass
        else:
            self.log_q.put(("log", "自动更新失败: %s\n" % msg, "warn"))

    def show_license(self):
        messagebox.showinfo(
            "授权信息",
            "VideoMixCut 智能混剪 v%s\n\n本版本为【全开放版】, "
            "无需机器码 / 激活码, 解压即用。" % (APP_VERSION or "?"))

    def show_features(self):
        """功能说明: 每个选项是干什么的, 什么场景开"""
        win = tk.Toplevel(self.root)
        win.title("功能说明")
        win.geometry("720x640")
        win.configure(bg=BG)
        style_widget(win)
        hd = tk.Frame(win, bg=CARD, highlightbackground=BORDER,
                      highlightthickness=1)
        hd.pack(fill="x")
        tk.Label(hd, text="功能说明", bg=CARD, fg=TEXT,
                 font=(FONT, 14, "bold")).pack(pady=(12, 2), padx=14, anchor="w")
        tk.Label(hd, text="每个选项的作用与建议用法", bg=CARD, fg=MUTED,
                 font=(FONT, 9)).pack(pady=(0, 12), padx=14, anchor="w")
        txt = tk.Text(win, wrap="word", bg=LOG_BG, fg="#c9d3e0",
                      relief="flat", padx=16, pady=12,
                      font=(FONT, 10), spacing1=4, spacing3=4)
        sb = ttk.Scrollbar(win, command=txt.yview)
        txt.configure(yscrollcommand=sb.set)
        sb.pack(side="right", fill="y", padx=(0, 8), pady=8)
        txt.pack(fill="both", expand=True, padx=(8, 0), pady=8)
        for tag, fg in (("h", ACCENT), ("b", GREEN), ("w", YELLOW)):
            txt.tag_configure(tag, foreground=fg)
        txt.tag_configure("t", foreground=TEXT,
                          font=(FONT, 11, "bold"))
        for part in FEATURES_DOC:
            if part[0] == "t":
                txt.insert("end", "\n" + part[1] + "\n", "t")
            else:
                txt.insert("end", part[1] + "\n", part[0])
        txt.configure(state="disabled")
        win.transient(self.root)

    def show_ai_settings(self):
        """AI 审片设置: 三步引导 (选平台→拿密钥→自动配好), 密钥存本机"""
        win = tk.Toplevel(self.root)
        win.title("AI 审片设置")
        win.geometry("640x520")
        win.configure(bg=BG)
        win.resizable(False, False)
        style_widget(win)
        self._ai_win_alive = True
        cfg = load_llm_cfg()
        configured = bool(cfg.get("api_key"))

        hd = tk.Frame(win, bg=CARD, highlightbackground=BORDER,
                      highlightthickness=1)
        hd.pack(fill="x")
        tk.Label(hd, text="AI 审片设置", bg=CARD, fg=TEXT,
                 font=(FONT, 14, "bold")).pack(pady=(12, 2), padx=14, anchor="w")
        state = ("已配置 ✓ (出片时把「AI审片」选\"开\"即可生效)"
                 if configured else "未配置 — AI审片会自动跳过")
        tk.Label(hd, text=state, bg=CARD, fg=GREEN if configured else MUTED,
                 font=(FONT, 9)).pack(pady=(0, 12), padx=14, anchor="w")

        steps = tk.Label(win, bg="#12241a", fg="#7fe0a8", justify="left",
                         font=(FONT, 10), padx=12, pady=10, anchor="w",
                         text="三步搞定 (全程约2分钟, 免费):\n"
                              " ① 选平台 → 接口地址和模型自动填好\n"
                              " ② 点【打开密钥页面】→ 注册账号 → 生成并复制密钥\n"
                              " ③ 回到本窗口 → 自动检测剪贴板填入 + 自动保存 + 自动测试")
        steps.pack(fill="x", padx=10, pady=(10, 6))

        body = tk.Frame(win, bg=BG)
        body.pack(fill="both", expand=True, padx=10, pady=6)

        r1 = tk.Frame(body, bg=BG); r1.pack(fill="x", pady=5)
        tk.Label(r1, text="① 选平台", bg=BG, fg=ACCENT,
                 font=(FONT, 10, "bold"), width=12, anchor="w").pack(side="left")
        preset_var = tk.StringVar(value="")
        combo = ttk.Combobox(r1, textvariable=preset_var, state="readonly",
                             width=30, values=[p[0] for p in AI_PRESETS])
        combo.pack(side="left", padx=(0, 8))
        open_btn = tk.Button(r1, text="② 打开密钥页面 ↗", state="disabled",
                             command=lambda: self._ai_open_key_page(preset_var),
                             bg=CARD2, fg="#7fb4ff", activebackground=BORDER,
                             activeforeground="#a8cdff", relief="flat",
                             padx=12, pady=3, cursor="hand2", font=(FONT, 9, "bold"))
        open_btn.pack(side="left")
        self._ai_open_btn = open_btn

        r2 = tk.Frame(body, bg=BG); r2.pack(fill="x", pady=5)
        tk.Label(r2, text="接口地址(自动)", bg=BG, fg=MUTED,
                 font=(FONT, 9), width=12, anchor="w").pack(side="left")
        base_var = tk.StringVar(value=cfg.get("api_base", ""))
        e1 = ttk.Entry(r2, textvariable=base_var, width=44, state="readonly")
        e1.pack(side="left")

        r3 = tk.Frame(body, bg=BG); r3.pack(fill="x", pady=5)
        tk.Label(r3, text="③ API密钥", bg=BG, fg=MUTED,
                 font=(FONT, 9), width=12, anchor="w").pack(side="left")
        key_var = tk.StringVar(value=cfg.get("api_key", ""))
        e2 = ttk.Entry(r3, textvariable=key_var, width=36, show="*")
        e2.pack(side="left", padx=(0, 6))
        tk.Button(r3, text="手动粘贴", command=lambda: self._ai_paste_key(
            win, key_var, base_var, model_var, status_var),
            bg=CARD2, fg=TEXT, activebackground=BORDER,
            activeforeground=TEXT, relief="flat", padx=8, pady=2,
            cursor="hand2", font=(FONT, 9)).pack(side="left")

        r4 = tk.Frame(body, bg=BG); r4.pack(fill="x", pady=5)
        tk.Label(r4, text="模型名(自动)", bg=BG, fg=MUTED,
                 font=(FONT, 9), width=12, anchor="w").pack(side="left")
        model_var = tk.StringVar(value=cfg.get("model", ""))
        ttk.Entry(r4, textvariable=model_var, width=30).pack(side="left")

        foot = tk.Frame(win, bg=BG)
        foot.pack(fill="x", padx=10, pady=(2, 10))
        tk.Button(foot, text="保存配置", command=lambda: self._ai_save(
            win, base_var, key_var, model_var, status_var, manual=True),
            bg=ACCENT, fg="#141414", activebackground=ACCENT_DK,
            activeforeground="#141414", relief="flat", padx=16, pady=4,
            cursor="hand2", font=(FONT, 10, "bold")).pack(side="left")
        tk.Button(foot, text="测试连通", command=lambda: self._ai_test(
            win, base_var, key_var, model_var, status_var),
            bg=CARD2, fg=TEXT, activebackground=BORDER,
            activeforeground=TEXT, relief="flat", padx=16, pady=4,
            cursor="hand2", font=(FONT, 10)).pack(side="left", padx=8)
        status_var = tk.StringVar(value="")
        tk.Label(foot, textvariable=status_var, bg=BG, fg=GREEN,
                 font=(FONT, 9), wraplength=300, justify="left").pack(
            side="left", padx=8)

        def on_preset(_e=None):
            for label, base, model, _kp in AI_PRESETS:
                if label == preset_var.get():
                    base_var.set(base)
                    model_var.set(model)
                    open_btn.configure(state="normal")
                    status_var.set("② 点【打开密钥页面】→ 注册并复制密钥 → 回来自动配好")
                    break
        combo.bind("<<ComboboxSelected>>", on_preset)
        win.protocol("WM_DELETE_WINDOW",
                     lambda: (setattr(self, "_ai_win_alive", False), win.destroy()))
        win.transient(self.root)
        self._ai_watch_clipboard(win, key_var, base_var, model_var, status_var)

    def _ai_open_key_page(self, preset_var):
        import webbrowser
        for label, _b, _m, keypage in AI_PRESETS:
            if label == preset_var.get():
                webbrowser.open(keypage)
                self.log_write("已打开密钥页面: " + keypage)
                return
        messagebox.showinfo("提示", "请先在①里选择一个平台")

    def _ai_paste_key(self, win, key_var, base_var, model_var, status_var):
        try:
            txt = win.clipboard_get().strip()
        except Exception:
            txt = ""
        if txt:
            key_var.set(txt)
            self._ai_save(win, base_var, key_var, model_var, status_var)

    def _ai_watch_clipboard(self, win, key_var, base_var, model_var, status_var):
        """剪贴板监听: 复制密钥回到窗口 -> 自动填入+保存+测试"""
        if not getattr(self, "_ai_win_alive", False):
            return
        try:
            txt = win.clipboard_get().strip()
        except Exception:
            txt = ""
        if (txt and "\n" not in txt and " " not in txt and len(txt) >= 20
                and txt != key_var.get()
                and (txt.lower().startswith("sk-") or len(txt) >= 32)):
            key_var.set(txt)
            status_var.set("检测到剪贴板里的密钥, 自动填入...")
            self._ai_save(win, base_var, key_var, model_var, status_var)
        win.after(1500, lambda: self._ai_watch_clipboard(
            win, key_var, base_var, model_var, status_var))

    def _ai_save(self, win, base_var, key_var, model_var, status_var,
                 manual=False):
        base = base_var.get().strip()
        key = key_var.get().strip()
        model = model_var.get().strip()
        if not (base and key and model):
            if manual:
                messagebox.showwarning(
                    "提示", "接口地址 / API密钥 / 模型名 都要有。\n"
                    "在①里选平台后地址和模型会自动填好。")
            return
        if not base.lower().startswith(("http://", "https://")):
            messagebox.showerror(
                "接口地址不对",
                "接口地址是一个网址(如 https://open.bigmodel.cn/api/paas/v4),\n"
                "不是激活码/机器码。请在①里选平台, 自动填好。")
            return
        save_llm_cfg({"api_base": base, "api_key": key, "model": model})
        self.log_write("AI 审片配置已保存 (密钥存本机 config.json)")
        status_var.set("已保存 ✓ 正在自动测试...")
        self._ai_test(win, base_var, key_var, model_var, status_var)

    def _ai_test(self, win, base_var, key_var, model_var, status_var):
        base = base_var.get().strip().rstrip("/")
        key = key_var.get().strip()
        model = model_var.get().strip()
        if not (base and key and model):
            status_var.set("请先填好三项")
            return
        status_var.set("测试中...")

        def work():
            import json as _json
            import urllib.request
            try:
                req = urllib.request.Request(
                    base + "/chat/completions",
                    data=_json.dumps({"model": model, "messages": [
                        {"role": "user", "content": "回复:连通"}],
                        "max_tokens": 10}).encode("utf-8"),
                    headers={"Content-Type": "application/json",
                             "Authorization": "Bearer " + key})
                with urllib.request.urlopen(req, timeout=30) as r:
                    data = _json.loads(r.read().decode("utf-8"))
                reply = data["choices"][0]["message"]["content"]
                msg = ("连通 ✓ AI审片已可用, 出片时把「AI审片」选\"开\"即可"
                       + (" | 模型回复: " + reply[:20] if reply else ""))
                win.after(0, lambda: status_var.set(msg))
                self.log_write("AI 审片连通测试成功")
            except Exception as e:
                hint = str(e)
                if "401" in hint or "Unauthorized" in hint or "api key" in hint.lower():
                    hint = "密钥不对(401): 检查是否复制完整, sk-开头"
                elif "url type" in hint.lower():
                    hint = "接口地址不是网址: 请在①里选平台自动填"
                win.after(0, lambda: status_var.set("失败: " + hint))
                self.log_write("AI 审片连通测试失败: " + hint)
        threading.Thread(target=work, daemon=True).start()

    # ---------------- 执行 ----------------
    def start(self):
        if self.running:
            return
        src = self.src_var.get().strip()
        if not src or not os.path.isdir(src):
            messagebox.showwarning("提示", "请先选择成片视频所在文件夹")
            return
        bgm = self.bgm_mode.get()
        if bgm == "file":
            bgm_arg = self.bgm_file_var.get().strip()
            if not bgm_arg or not os.path.exists(bgm_arg):
                messagebox.showwarning("提示", "请选择本地背景音乐文件")
                return
        elif bgm == "name":
            bgm_arg = self.bgm_name_var.get().strip() or "random"
        elif bgm == "mood":
            bgm_arg = "mood"
        else:
            bgm_arg = bgm  # random / synth / none

        sticker = self.sticker_var.get()
        wm = self.wm_var.get().strip()
        if sticker == "watermark" and not wm:
            wm = "VideoMixCut"
        try:
            count = max(1, min(50, int(self.count_var.get())))
        except ValueError:
            count = 1

        style = self.variant_var.get()
        mirror_map = {"自动": "auto", "开启": "on", "关闭": "off"}
        dur_map = {"自动": "0", "30秒": "30", "45秒": "45", "60秒": "60"}
        trans_map = {"无": "none", "溶解": "xfade"}
        voice_map = {"随机": "auto", "同主播": "same", "换主播": "alternate"}
        flow_map = {"关": "off", "开": "on"}
        broll_map = {"自动": "auto", "开启": "on", "关闭": "off"}
        sub_map = {"无": "none", "品牌": "brand"}
        polish_map = {"关": "off", "开": "on"}
        aiplan_map = {"关": "off", "开": "on"}
        cover_map = {"开": "on", "关": "off"}
        enc_map = {"自动": "auto", "显卡": "gpu", "CPU": "cpu"}
        if (polish_map.get(self.polish_var.get()) == "on"
                or aiplan_map.get(self.aiplan_var.get()) == "on") \
                and not load_llm_cfg().get("api_key"):
            self.log_write("提示: AI选段/AI审片还没配置密钥, 本次将自动跳过 — "
                           "可在 帮助→AI 审片设置 里三步配好(免费)", "warn")
        self.log.configure(state="normal")
        self.log.delete("1.0", "end")
        self.log.configure(state="disabled")
        self.prog.configure(value=0)
        self._set_run_ui(True)
        self.status_var.set("启动后台任务...")
        self.running = True
        # 标记运行中的项目 (项目列表里会显示"运行中...")
        self.proj["running"] = True
        self.proj["note"] = ""
        self._save_params()
        # 落盘"运行中"锁: 项目列表立刻显示运行中 (心跳由后台任务进程刷新)
        mark_running(self.proj, True)
        self.hb_ev = None
        self.attached = True            # 本窗口转入"看客"模式, 任务在独立进程里跑
        self._last_state = {}
        self._last_sync = 0.0
        self._run_t0 = time.time()
        try:
            os.remove(state_json_path(self.proj))   # 清掉上一轮进度, 免得误判
        except OSError:
            pass
        self.log_write("\n========== 开始出片  %s  ==========\n"
                       % time.strftime("%Y-%m-%d %H:%M:%S"), "step")
        args = dict(src=src, bgm=bgm_arg, sticker=sticker, wm=wm,
                    variant=None if style == "自动" else style,
                    mirror=mirror_map.get(self.mirror_var.get(), "auto"),
                    duration=dur_map.get(self.duration_var.get(), "0"),
                    transition=trans_map.get(self.transition_var.get(), "none"),
                    voice=voice_map.get(self.voice_var.get(), "auto"),
                    flow=flow_map.get(self.flow_var.get(), "off"),
                    broll=broll_map.get(self.broll_var.get(), "auto"),
                    subtitle=sub_map.get(self.subtitle_var.get(), "none"),
                    polish=polish_map.get(self.polish_var.get(), "off"),
                    encoder=enc_map.get(self.enc_var.get(), "auto"),
                    ai_plan=aiplan_map.get(self.aiplan_var.get(), "off"),
                    cover=cover_map.get(self.cover_var.get(), "on"),
                    dedup=({"关": "off", "开": "on"}.get(self.dedup_var.get(), "off")),
                    out=self.out_var.get().strip(), count=count)
        # 日志起点: 只贴后台任务新写的内容(历史行上面已经回显过了)
        try:
            self._tail_off = os.path.getsize(run_log_path(self.proj))
        except OSError:
            self._tail_off = 0
        steps = self._build_steps(args)
        if not self._spawn_backend_task(steps, self._backend_env(args), args["out"]):
            self.attached = False
            self.running = False
            self.proj["running"] = False
            mark_running(self.proj, False)
            self._save_params()
            self._set_run_ui(False)
            self.status_var.set("启动失败 · 详见日志")
            return
        self.log_write("[后台] 任务已交给独立进程(PID %s)运行: 关掉本窗口它也会继续跑,"
                       " 回项目列表能看到跑到第几步; 想中途停就点右边「停止」。\n"
                       % getattr(self.runner, "pid", "?"), "ok")
        self.prog.configure(value=0)
        self.status_var.set("后台运行中 · 第 1/5 步")

    def _build_steps(self, a):
        """5 步流程 -> 任务清单 (交给独立后台进程执行)"""
        mix_args = (["mix", "--src", a["src"], "--bgm", a["bgm"]]
                    + ([] if not a.get("variant")
                       else ["--variant", a["variant"]])
                    + ["--mirror", a.get("mirror", "auto"),
                       "--duration", a.get("duration", "0"),
                       "--transition", a.get("transition", "none"),
                       "--voice", a.get("voice", "auto"),
                       "--flow", a.get("flow", "off"),
                       "--broll", a.get("broll", "auto"),
                       "--subtitle", a.get("subtitle", "none"),
                       "--polish", a.get("polish", "off"),
                       "--ai-plan", a.get("ai_plan", "off"),
                       "--cover", a.get("cover", "on"),
                       "--sticker", a["sticker"],
                       "--wm-text", a["wm"],
                       "--count", str(a["count"])]
                    + (["--out", a["out"]] if a["out"] else []))
        return [
            {"title": "[1/5] 扫描视频 (含所有子文件夹)",
             "args": ["scan", "--src", a["src"]]},
            {"title": "[2/5] 字幕识别 (新素材 OCR, 每条约 20 秒, 请耐心等待)",
             "args": ["subs", "--src", a["src"]]},
            {"title": "[3/5] 文案分析自动拼装分段表", "args": ["plan"]},
            {"title": "[4/5] 人声分离 + 混剪出片", "args": mix_args},
            {"title": "[5/5] 自检 (文案重复/截断 + 画面黑屏卡帧 + 音频静音爆音)",
             "args": ["selfcheck"]},
        ]

    def _backend_env(self, a):
        """后端环境变量: 项目工作目录(隔离多开) + 硬件编码 + 模型目录"""
        env = {"PYTHONIOENCODING": "utf-8", "PYTHONUTF8": "1"}
        wd = self.proj_dir()
        if wd:
            try:
                os.makedirs(wd, exist_ok=True)
            except OSError:
                pass
            env["VMC_PROJECT_DIR"] = wd
        # 硬件加速: auto=有显卡就用, gpu=强制显卡, cpu=只用CPU
        env["VMC_ENCODER"] = a.get("encoder") or "auto"
        # demucs 模型随包分发时指向包内目录 (免联网下载)
        models_dir = os.path.join(BASE_DIR, "models")
        if os.path.isdir(models_dir):
            env["TORCH_HOME"] = models_dir
        return env

    def _spawn_backend_task(self, steps, env, out_dir):
        """把任务清单写成 task.json, 拉起独立后台进程去干 (关窗不影响)"""
        task = {"cwd": BASE_DIR, "py": find_backend_python(),
                "script": backend_script(),
                "log": run_log_path(self.proj),
                "state": state_json_path(self.proj),
                "lock": run_lock_path(self.proj),
                "stop": stop_flag_path(self.proj),
                "proj": self.proj_name, "out": out_dir or "",
                "env": env, "steps": steps}
        tj = task_json_path(self.proj)
        try:
            os.makedirs(os.path.dirname(tj), exist_ok=True)
        except OSError:
            pass
        if not _write_json(tj, task):
            self.log_write("✗ 任务文件写不进去: %s\n" % tj, "err")
            return False
        flags = _run_no_win() | (0x00000200 if os.name == "nt" else 0)
        try:
            self.runner = subprocess.Popen(
                [detached_python(), gui_script(), "--run-task", tj],
                cwd=BASE_DIR, stdin=subprocess.DEVNULL,
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                close_fds=True, creationflags=flags)
        except OSError as e:
            self.log_write("✗ 启动后台任务失败: %s\n" % e, "err")
            return False
        return True

    def _finish(self, ok):
        """兼容旧调用: 结果 -> 统一走 _detach_finish 收尾"""
        self._detach_finish("done" if ok else "error", {})

    def close(self):
        """关窗: 任务默认转后台继续跑 (中途想停就点「停止」或在这里选"停止")"""
        alive = running_alive(self.proj)
        busy = (getattr(self, "attached", False) or alive
                or bool(self.proc and self.proc.poll() is None))
        keep = False
        if busy:
            ans = messagebox.askyesnocancel(
                "任务正在后台运行",
                "「是」—  关掉窗口, 出片在后台继续跑  (推荐)\n"
                "「否」—  停止本次出片, 然后关窗\n"
                "「取消」— 不关窗\n\n"
                "关窗后进度在哪看: 回到项目列表, 该项目会显示「后台运行中 x/5 步」;\n"
                "再点「打开」就能重新接上实时日志。跑完会自动记下结果。")
            if ans is None:
                return
            if ans:
                keep = True
            else:
                request_stop(self.proj)
        if keep:
            # 关键: 不杀进程! 任务由独立进程继续跑, 只把窗口这层"看客"关掉
            self.attached = False
            self.running = False
            self._set_run_uioff_safe()
            try:
                with open(run_log_path(self.proj), "a",
                          encoding="utf-8") as f:
                    f.write("\n[窗口已关闭 %s] 任务转入后台继续运行 "
                            "(进度见项目列表; 想停就重开窗口点「停止」)\n"
                            % time.strftime("%H:%M:%S"))
            except OSError:
                pass
            self.proj["running"] = True          # 保持"运行中", 让它显示真实进度
            try:
                save_project(self.proj)
            except Exception:
                pass
        else:
            if getattr(self, "hb_ev", None):
                self.hb_ev.set()                 # 停心跳
            mark_running(self.proj, False)       # 清"运行中"锁
            self.proj["running"] = False
            if getattr(self, "attached", False):
                self.attached = False
                self.proj["note"] = "上次出片被中断"
                self.log_write("\n[窗口已关闭] 本次出片已停止。\n"
                               "日志已存到 项目目录\\data\\run.log; "
                               "重开本项目点「开始出片」即可再跑。\n", "warn")
            try:
                self._save_params()
            except Exception:
                pass
        log_sink(getattr(self, "_log_fp", None), "")
        try:
            if getattr(self, "_log_fp", None):
                self._log_fp.close()
        except (OSError, ValueError):
            pass
        self._log_fp = None
        self.root.destroy()

    def _set_run_uioff_safe(self):
        """关窗时把运行态 UI 复位 (窗口马上销毁, 失败也无所谓)"""
        try:
            self._set_run_ui(False)
        except Exception:
            pass


class ActivationDialog:
    """激活窗口: 未激活时挡在主界面之前 (深色风格)"""

    def __init__(self, root):
        self.root = root
        self.ok = False
        style_widget(root)
        root.title("VideoMixCut 智能混剪 - 激活")
        root.geometry("560x360")
        root.configure(bg=BG)
        root.resizable(False, False)
        hd = tk.Frame(root, bg=CARD, highlightbackground=BORDER,
                      highlightthickness=1)
        hd.pack(fill="x")
        tk.Label(hd, text="VideoMixCut  智能混剪", bg=CARD, fg=TEXT,
                 font=(FONT, 16, "bold")).pack(pady=(16, 2))
        tk.Label(hd, text="把【机器码】发给卖家, 输入激活码后即可使用",
                 bg=CARD, fg=MUTED, font=(FONT, 10)).pack(pady=(0, 16))
        frm = tk.Frame(root, bg=BG)
        frm.pack(fill="both", expand=True, padx=28, pady=18)

        row1 = tk.Frame(frm, bg=BG); row1.pack(fill="x", pady=6)
        tk.Label(row1, text="机器码", bg=BG, fg=MUTED,
                 font=(FONT, 10), width=8).pack(side="left")
        self.mc_var = tk.StringVar(value=activation.machine_code())
        e1 = ttk.Entry(row1, textvariable=self.mc_var, width=26,
                       state="readonly")
        e1.pack(side="left", padx=4)
        b = tk.Button(row1, text="复制", command=self.copy_mc, bg=CARD2,
                      fg=TEXT, activebackground=BORDER, activeforeground=TEXT,
                      relief="flat", padx=14, cursor="hand2", font=(FONT, 10))
        b.pack(side="left")
        hover_button(b, CARD2, BORDER)

        row2 = tk.Frame(frm, bg=BG); row2.pack(fill="x", pady=12)
        tk.Label(row2, text="激活码", bg=BG, fg=MUTED,
                 font=(FONT, 10), width=8).pack(side="left")
        self.code_var = tk.StringVar()
        e2 = ttk.Entry(row2, textvariable=self.code_var, width=29)
        e2.pack(side="left", padx=4)
        e2.focus_set()
        e2.bind("<Return>", lambda ev: self.activate())

        self.msg_var = tk.StringVar(value="")
        tk.Label(frm, textvariable=self.msg_var, bg=BG, fg="#ff6b6b",
                 font=(FONT, 10)).pack()
        go = tk.Button(frm, text="激  活", command=self.activate, bg=ACCENT,
                       fg="#141414", activebackground=ACCENT_DK,
                       activeforeground="#fff", relief="flat", cursor="hand2",
                       font=(FONT, 12, "bold"), pady=8)
        go.pack(fill="x", pady=10, ipadx=20)
        hover_button(go, ACCENT, ACCENT_DK)

    def copy_mc(self):
        self.root.clipboard_clear()
        self.root.clipboard_append(self.mc_var.get())
        self.msg_var.set("机器码已复制, 发给卖家即可")

    def activate(self):
        code = self.code_var.get().strip()
        ok, msg = activation.write_license(activation.machine_code(), code)
        if ok:
            self.ok = True
            messagebox.showinfo("激活", msg)
            self.root.destroy()
        else:
            self.msg_var.set(msg)


def main():
    # --run-task <task.json>: 独立后台进程模式 (界面用它跑出片, 与窗口完全分离,
    # 所以关掉窗口/退出软件后任务照样继续跑)。这个分支不碰任何界面。
    if "--run-task" in sys.argv:
        i = sys.argv.index("--run-task")
        if i + 1 < len(sys.argv):
            sys.exit(run_task_mode(sys.argv[i + 1]))
        sys.exit(2)
    if "--selftest" in sys.argv:
        root = tk.Tk()
        root.withdraw()
        ok, info = activation.verify_license()
        print("SELFTEST license:", ok)
        print("SELFTEST_OK")
        root.destroy()
        return
    root = tk.Tk()
    style_widget(root)
    # 激活门: 未激活先弹激活窗口
    ok, _info = activation.verify_license()
    if not ok:
        dlg = ActivationDialog(root)
        root.protocol("WM_DELETE_WINDOW", root.destroy)
        root.mainloop()
        if not dlg.ok:
            return          # 直接关闭 = 退出软件
        root = tk.Tk()
        style_widget(root)
    # --project <名字>: 打开指定项目的独立窗口; 不带参数: 打开项目管理列表
    pname = None
    if "--project" in sys.argv:
        i = sys.argv.index("--project")
        if i + 1 < len(sys.argv):
            pname = sys.argv[i + 1]
    if pname == "__manager__":
        ProjectManager(root)
        root.mainloop()
        return
    if not pname:
        if not list_projects():
            # 老用户升级: 自动建一个默认项目, 且沿用原来的 data/output
            # (workdir 留空 = 软件全局目录, 已扫描的字幕和素材不会丢)
            save_project(load_project("默认项目"))
        ProjectManager(root)
        root.mainloop()
        return
    proj = load_project(pname)
    if (proj.get("type") or "mix") == "grab":
        app = GrabApp(root, proj)
        root.protocol("WM_DELETE_WINDOW", app.close)
        root.mainloop()
        return
    app = App(root, proj)
    root.protocol("WM_DELETE_WINDOW", app.close)
    # 启动时静默检查更新 (有配置检查地址才查)
    if updater.load_config(BASE_DIR).get("update_url"):
        root.after(1500, app.check_update)
    root.mainloop()


if __name__ == "__main__":
    main()
