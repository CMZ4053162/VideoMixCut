Set WshShell = CreateObject("WScript.Shell")
WshShell.Run """runtime_gui\pythonw.exe"" ""mixcut_gui.py""", 0, False
