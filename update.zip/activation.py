# -*- coding: utf-8 -*-
"""VideoMixCut 激活系统 (客户端校验与老板端生成共用, 纯标准库)
- 机器码:   本机硬件指纹 -> 16位数字 XXXX-XXXX-XXXX-XXXX
- 激活码:   HMAC-SHA256(内置密钥, 机器码|有效期) -> 19位数字
            格式: 有效期4位 + 校验14位, 展示为 XXXX-XXXXX-XXXXX-XXXXX
- 授权文件: data/license.dat, 含机器码/客户备注/有效期 + 防篡改签名
"""
import hashlib
import hmac
import json
import os
import platform
import time
import uuid

APP_NAME = "VideoMixCut"
LICENSE_FILE = os.path.join("data", "license.dat")

# 内置密钥 (两段异或还原, 防文本直接搜索)
_KEY_A = bytes.fromhex(
    "453b20a6f5297176081d931f9f32d8eefe97507a4d5ca4efc279f083ebd5071e")
_KEY_B = bytes.fromhex(
    "28f5383b41629277f155de0e59e7ff45db76532a684c84149b778a1eae32b10d")


def _key():
    return bytes(x ^ y for x, y in zip(_KEY_A, _KEY_B))


def _digits(n, width):
    return str(int(n) % (10 ** width)).zfill(width)


def machine_code():
    """本机硬件指纹 -> 1234-5678-9012-3456 (MAC+CPU+主机名, 重装系统不变)"""
    ident = "%s|%s|%s|%s" % (
        uuid.getnode(),
        os.environ.get("PROCESSOR_IDENTIFIER", ""),
        os.environ.get("NUMBER_OF_PROCESSORS", ""),
        platform.node())
    h = hashlib.sha256(("vmc-mc1|" + ident).encode("utf-8")).hexdigest()
    s = _digits(int(h[:16], 16), 16)
    return "-".join(s[i:i + 4] for i in (0, 4, 8, 12))


def make_activation_code(mc, days=0):
    """生成激活码。mc: 客户机器码(带不带横杠都行); days: 0=永久, 其他为天数"""
    mc = (mc or "").replace("-", "").strip()
    days = int(days or 0)
    msg = ("%s|%d" % (mc, days)).encode("utf-8")
    h = hmac.new(_key(), msg, hashlib.sha256).hexdigest()
    code = _digits(int(h[:18], 16), 14)
    return "%04d-%s-%s-%s" % (days, code[:5], code[5:10], code[10:14])


def check_activation_code(mc, code):
    """校验激活码是否匹配本机/指定机器码, 返回 (ok, days)"""
    mc = (mc or "").replace("-", "").strip()
    code = (code or "").replace("-", "").replace(" ", "").strip()
    if len(code) != 18 or not code.isdigit():
        return False, 0
    days = int(code[:4])
    if days not in (0, 7, 30, 90, 180, 365, 730, 1095, 1825):
        return False, 0
    want = make_activation_code(mc, days).replace("-", "")
    return hmac.compare_digest(want, code), days


def _sig(mc, note, ts, exp):
    msg = "%s|%s|%s|%s" % (mc, note, ts, exp)
    return hmac.new(_key(), msg.encode("utf-8"),
                    hashlib.sha256).hexdigest()


def write_license(mc, code, note=""):
    """激活: 校验激活码并写入授权文件, 返回 (ok, 消息)"""
    ok, days = check_activation_code(mc, code)
    if not ok:
        return False, "激活码不正确 (请核对机器码/激活码是否输错)"
    exp = None if days == 0 else int(time.time()) + days * 86400
    mc_disp = "-".join(mc.replace("-", "")[i:i + 4] for i in (0, 4, 8, 12))
    data = {"mc": mc_disp, "note": note, "ts": int(time.time()),
            "exp": exp, "sig": _sig(mc_disp, note, int(time.time()), exp)}
    os.makedirs(os.path.dirname(LICENSE_FILE) or ".", exist_ok=True)
    with open(LICENSE_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False)
    return True, "激活成功" + ("" if days == 0 else " (有效期 %d 天)" % days)


def verify_license():
    """读取并校验授权, 返回 (ok, info字典)

    全开放版: 不绑定机器码、不需要激活码, 直接返回已授权。
    (后端 main() 与各界面激活门都会走到这里, 统一放行。)
    """
    return True, {"note": "全开放版", "exp": None, "mc": machine_code()}


if __name__ == "__main__":
    import sys
    if len(sys.argv) >= 2 and sys.argv[1] in ("mc", "show"):
        print(machine_code())
    elif len(sys.argv) >= 3 and sys.argv[1] == "gen":
        print(make_activation_code(sys.argv[2],
                                   int(sys.argv[3]) if len(sys.argv) > 3 else 0))
    else:
        print("用法: python activation.py mc | gen <机器码> [天数]")
