# -*- coding: utf-8 -*-
"""在线更新模块 (纯标准库, 界面与命令行共用)
- 检查: 从 config.json 的 update_url (http链接 或 局域网/本地路径) 读 version.json
- 下载: http 下载或直接复制更新包 zip
- 应用: 解压后逐文件覆盖 (只增改不删除, 永不触碰 data/ 客户数据与授权文件)
- 版本: config.json 的 version 字段, 更新包内 config.json 只取 version 合并
"""
import json
import os
import shutil
import tempfile
import urllib.request
import zipfile

# 更新时永不覆盖的顶层目录/文件 (客户数据/授权/本地配置)
PROTECTED = {"data", "output", "build", "config.json"}


def load_config(app_dir):
    p = os.path.join(app_dir, "config.json")
    try:
        with open(p, encoding="utf-8") as f:
            cfg = json.load(f)
        if isinstance(cfg, dict):
            return cfg
    except (OSError, ValueError):
        pass
    return {"version": "0.0.0", "update_url": ""}


def save_config(app_dir, cfg):
    with open(os.path.join(app_dir, "config.json"), "w", encoding="utf-8") as f:
        json.dump(cfg, f, ensure_ascii=False, indent=1)


def ver_tuple(v):
    try:
        return tuple(int(x) for x in str(v).strip().split("."))
    except ValueError:
        return (0,)


def is_newer(a, b):
    return ver_tuple(a) > ver_tuple(b)


def fetch_manifest(url, timeout=8):
    """读取 version.json (http 或 本地/UNC 路径), 返回 dict 或 None"""
    try:
        if str(url).lower().startswith("http"):
            with urllib.request.urlopen(url, timeout=timeout) as r:
                data = r.read()
        else:
            with open(url, "rb") as f:
                data = f.read()
        m = json.loads(data.decode("utf-8"))
        if not (isinstance(m, dict) and m.get("version") and m.get("url")):
            return None
        return m
    except (OSError, ValueError):
        return None


def check_update(app_dir):
    """有新版本时返回 manifest dict, 否则 None"""
    cfg = load_config(app_dir)
    url = cfg.get("update_url", "")
    if not url:
        return None
    m = fetch_manifest(url)
    if m and is_newer(m.get("version", "0"), cfg.get("version", "0")):
        return m
    return None


def resolve_update_url(manifest_url, update_url):
    """manifest 里的 url 若是相对文件名, 则按检查地址所在目录解析。
    http(s) 基址统一用 '/' 拼接, 避免 Windows os.sep(反斜杠)污染 URL 导致下载失败。"""
    u = str(manifest_url)
    if u.lower().startswith("http") or os.path.exists(u):
        return u
    base = os.path.dirname(str(update_url))
    if base.lower().startswith("http"):
        cand = base.rstrip("/") + "/" + u.lstrip("/")
    else:
        cand = os.path.join(base, u)
    return cand if os.path.exists(cand) else u


def _fetch(src, dest):
    if str(src).lower().startswith("http"):
        with urllib.request.urlopen(src, timeout=60) as r, open(dest, "wb") as f:
            shutil.copyfileobj(r, f)
    else:
        shutil.copyfile(src, dest)


def install_kind(app_dir):
    """判断安装形态: portable=便携版(带自带运行时, 可用更新包); source=源码版(不支持)"""
    for sub in ("runtime", "runtime_gui"):
        for exe in ("python.exe", "pythonw.exe"):
            if os.path.exists(os.path.join(app_dir, sub, exe)):
                return "portable"
    if os.path.exists(os.path.join(app_dir, "mixcut_tool.pyc")):
        return "portable"
    return "source"


def check_compatible(app_dir):
    """更新包只适用于 v2.0.0 起的便携版 (自带运行时 + pyc)。
    源码版客户会拿到不匹配的文件, 这里提前拦住并给正确指引。"""
    if install_kind(app_dir) == "portable":
        return True, ""
    return False, ("当前安装不是便携版(缺少自带运行时), 更新包不适用。\n\n"
                   "请向作者索取【完整安装包】解压覆盖安装即可,\n"
                   "素材、授权、设置都不会丢。")


def apply_update_zip(zip_path, app_dir, log=None):
    """把更新包内容合并进软件目录 (只增改不删除)。
    返回 (ok, 新版本号 或 错误信息)"""
    tmp = tempfile.mkdtemp(prefix="vmc_upd_")
    try:
        with zipfile.ZipFile(zip_path) as z:
            bad = [n for n in z.namelist()
                   if n.startswith(("/", "\\")) or ".." in n or (":" in n and n[1] == ":")]
            if bad:
                return False, "更新包内含非法路径: %s" % bad[0]
            z.extractall(tmp)
        # 更新包内 config.json 只取 version/update_url (保留客户自己的其他设置)
        new_ver = None
        new_url = None
        pkg_cfg = os.path.join(tmp, "config.json")
        if os.path.exists(pkg_cfg):
            try:
                with open(pkg_cfg, encoding="utf-8") as f:
                    pc = json.load(f)
                new_ver = pc.get("version")
                new_url = pc.get("update_url")
            except ValueError:
                pass
        n_files = 0
        for dirpath, _, files in os.walk(tmp):
            rel = os.path.relpath(dirpath, tmp)
            top = rel.split(os.sep)[0] if rel != "." else ""
            if top in PROTECTED:
                continue
            for fn in files:
                if rel == "." and fn in PROTECTED:
                    continue
                src = os.path.join(dirpath, fn)
                dst = os.path.join(app_dir, os.path.relpath(src, tmp))
                os.makedirs(os.path.dirname(dst), exist_ok=True)
                shutil.copy2(src, dst)
                n_files += 1
                if log:
                    log("  更新文件: " + os.path.relpath(src, tmp))
        cfg = load_config(app_dir)
        if new_ver:
            cfg["version"] = new_ver
        if new_url:
            cfg["update_url"] = new_url      # 更新包携带检查地址 -> 一次导入, 终身自动更新
        save_config(app_dir, cfg)
        return True, new_ver or "(未标注版本)"
    except (OSError, zipfile.BadZipFile) as e:
        return False, "更新失败: %s" % e
