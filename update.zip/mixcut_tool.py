#!/usr/bin/env python3
# -*- coding: utf-8 -*-
r"""
VideoMixCut — 带货视频智能混剪工具（单文件 CLI）

流水线: 扫描视频 -> 字幕时间轴 -> 文案角色分析自动拼装 -> 抽取分段音频
        -> demucs 人声分离(去原BGM) -> 去重滤镜混剪 -> 混入可商用BGM -> 贴纸/水印叠加

用法:
  python mixcut_tool.py scan  --src <视频目录>        # 扫描视频, 生成时长清单
  python mixcut_tool.py subs  --src <视频目录>        # 生成字幕模板 data/subtitles.json
  python mixcut_tool.py plan                          # 文案分析 -> 自动拼装 segments.json
  python mixcut_tool.py audio --src <视频目录>        # 按分段表抽取音频
  python mixcut_tool.py sep                           # demucs 人声分离(去原BGM)
  python mixcut_tool.py mix  --src <视频目录>         # 混剪合成出片
  python mixcut_tool.py all   --src <视频目录>        # 一键全流程
  python mixcut_tool.py bgm                           # 查看 BGM 曲库

常用选项 (作用于 mix / all):
  --bgm synth|random|曲名|音频路径     BGM 选择, 默认 synth(程序合成免版权)
  --count N                            批量出片: 每条独立随机方案(分段/顺序/文案都不同)
                                       + 每条随机画面参数(6套) + random BGM 每条换曲
  --variant 1-9                        单条出片时指定画面参数套数 (批量时自动随机轮换)
  --mirror auto|on|off                 画面镜像: auto=不镜像(默认, 内嵌字幕不反字),
                                       on=全部镜像(去重最强, 但字幕会反), off=同auto
  --sticker zhongqiu|watermark|none|PNG路径   贴纸方案
  --wm-text 文字                       水印文字(--sticker watermark 时生效)
  --name 输出文件名                    默认 混剪_成片_v<variant>
"""
import argparse
import csv
import difflib
import glob
import hashlib
import json
import math
import os
import random
import re
import shutil
import struct
import subprocess
import sys
import time
import wave

import activation

# === 隐藏所有子进程控制台窗口 (避免扫描/转码时频繁弹黑窗) ===
# ffmpeg/ffprobe 是控制台程序; 后端被 GUI 以 no_window 启动后没有可继承的
# 控制台, Windows 会为每次 ffmpeg 调用新建一个黑窗。统一给所有 subprocess
# 调用加上 CREATE_NO_WINDOW, 彻底杜绝扫描/混剪过程中的黑窗闪烁。
try:
    if not hasattr(subprocess, "CREATE_NO_WINDOW"):
        subprocess.CREATE_NO_WINDOW = 0x08000000
    _VMC_NOWIN = subprocess.CREATE_NO_WINDOW
except Exception:
    _VMC_NOWIN = 0x08000000

_vmc_orig_run = subprocess.run
_vmc_orig_popen = subprocess.Popen


def _vmc_run(*a, **k):
    if sys.platform.startswith("win") and "creationflags" not in k:
        k["creationflags"] = k.get("creationflags", 0) | _VMC_NOWIN
    return _vmc_orig_run(*a, **k)


def _vmc_popen(*a, **k):
    if sys.platform.startswith("win") and "creationflags" not in k:
        k["creationflags"] = k.get("creationflags", 0) | _VMC_NOWIN
    return _vmc_orig_popen(*a, **k)


subprocess.run = _vmc_run
subprocess.Popen = _vmc_popen
# ===============================================================

ROOT = os.path.dirname(os.path.abspath(__file__))
BIN = os.path.join(ROOT, "bin")
FFMPEG = os.path.join(BIN, "ffmpeg.exe")
FFPROBE = os.path.join(BIN, "ffprobe.exe")
LIB = os.path.join(ROOT, "bgm_library")
# 多项目支持: 环境变量 VMC_PROJECT_DIR 指向项目工作目录时,
# 该项目的 扫描/字幕/分段表 与 成片输出 都放在项目自己的目录里 (互不干扰),
# build/ 仍是全局: 人声分离中间产物按视频名缓存, 跨项目复用, 不重复分离
_PROJ = os.environ.get("VMC_PROJECT_DIR", "").strip()
PROJ = _PROJ if _PROJ else ""
DATA = os.path.join(_PROJ, "data") if _PROJ else os.path.join(ROOT, "data")
BUILD = os.path.join(ROOT, "build")
STICKER_DIR = os.path.join(ROOT, "stickers")
OUTDIR = os.path.join(_PROJ, "output") if _PROJ else os.path.join(ROOT, "output")
SUBS_JSON = os.path.join(DATA, "subtitles.json")
SEG_JSON = os.path.join(DATA, "segments.json")
VIDEOS_JSON = os.path.join(DATA, "videos.json")
BGM_SYNTH = os.path.join(BUILD, "bgm_synth.wav")

# ---------------- 去重变体参数: (缩放, eq调色, hue色相, 画面偏移dx/dy) ----------------
# 批量时每条随机轮换一套, 画面观感各不相同 (参数差异控制在肉眼舒适范围内)
# 镜像默认关闭(源视频多带内嵌字幕, 翻转会反字): 仅 --mirror on 时整体镜像;
# 画中画 pip=dict(w,dx,dy,bg) 主画面缩小叠在虚化/深色背景上
VARIANTS = {
    1: dict(scale=1120, eq="eq=brightness=0.025:saturation=1.12:contrast=1.05",
            hue="hue=h=2", dx=0, dy=0),
    2: dict(scale=1104, eq="eq=brightness=0.04:saturation=1.06:contrast=1.08",
            hue="hue=h=-3", dx=8, dy=10),
    3: dict(scale=1136, eq="eq=brightness=0.01:saturation=1.18:contrast=1.03",
            hue="hue=h=6", dx=-10, dy=-8),
    4: dict(scale=1096, eq="eq=brightness=0.05:saturation=1.02:contrast=1.10",
            hue="hue=h=-6", dx=-6, dy=14),
    5: dict(scale=1128, eq="eq=brightness=-0.02:saturation=1.15:contrast=1.06",
            hue="hue=h=10", dx=12, dy=-12),
    6: dict(scale=1112, eq="eq=brightness=0.03:saturation=1.08:contrast=1.09",
            hue="hue=h=-9", dx=-12, dy=6),
    7: dict(scale=1120, eq="eq=brightness=0.015:saturation=1.10:contrast=1.07",
            hue="hue=h=4", dx=0, dy=0,
            pip=dict(w=820, dx=0, dy=-30, bg="blur")),
    8: dict(scale=1120, eq="eq=brightness=0.03:saturation=1.14:contrast=1.05",
            hue="hue=h=-5", dx=0, dy=0,
            pip=dict(w=780, dx=60, dy=40, bg="blur")),
    9: dict(scale=1120, eq="eq=brightness=0.0:saturation=1.08:contrast=1.10",
            hue="hue=h=8", dx=0, dy=0,
            pip=dict(w=860, dx=-40, dy=-60, bg="dark")),
}
FPS = 30
FRAME_GRID = 1.0 / FPS
XFADE_D = 0.15          # 段间溶解转场时长 (视频 xfade / 音频 acrossfade 必须一致)


def snap_frame(t):
    """把时间点吸附到 1/30s 帧网格。

    每段视频按 fps=30 编码, 帧数只能落在 1/30s 网格上; 若段时长不是帧长的
    整数倍, 每段就会差最多 33ms, 多段拼接后累积成"越往后口型越对不上"的音画
    漂移。切点先吸附到帧网格, 视频帧数与音频时长就严格相等 (误差 0)。
    """
    return round(round(float(t) * FPS) / FPS, 4)


# ---------------- 文案角色分类规则 (可按品类自行扩充) ----------------
RULES = [
    ("CTA",   r"活动|特价|中秋|国庆|让利|优惠|价格|小黄车|去看看|上一单|安排一个|看看吧|有需要|有喜欢|下单|便宜|划算|错过"),
    ("招呼",  r"看过来|朋友们|家人们|老铁|老板们|各位|家里有|养小型鱼|养鱼的|想要给|不想|给家里|它来了"),
    ("痛点",  r"忽高忽低|容易生病|笨重|千万不要选大|乱糟糟|过冬|担心|问题|发浑|腥臭|浑浊|水浑|黄水|绿水|死鱼|白点|水质差|发臭"),
    ("外观",  r"体积小|个头不大|不碍眼|机身小巧|美观|干净好看|颜值|外观"),
    ("材质",  r"材质|玻璃|石英|硅胶|不锈钢|面料|原矿|烧制|微孔|活性炭|细菌屋|火山石"),
    ("安全",  r"保护壳|保护盒|烫伤|安全|热源|碰到|不粉化|不起絮|不散"),
    ("显示",  r"数显|实时温度|一目了然|当前温度|设置温度|随时去看|控制器|控温器|设定温度"),
    ("温控",  r"温控|15-34|调节|调温|随心|伸进水|碰水"),
    ("功效",  r"效果|水清|空气缸|硝化细菌|鱼亮|培养|净化|过滤强|透亮|1\+1大于2"),
]
TEMPLATE = ["痛点", "引入", "外观", "材质", "功效", "安全", "显示", "温控", "CTA"]
# 爆款要素: 开头钩子 / 卖点数字 / 结尾行动号召
HOOK_PAT = r"千万|别再|还在|居然|竟然|没想到|必看|后悔|亏|注意|揭秘|真相|秘密|为什么|怎么|如何|不敢信|原来|第一次|一试|试过|才知道"
SELL_PAT = r"\d+合一|\d+种|\d+倍|\d+层|\d+天|\d+年|科学|配比|搭配|专业|双重|双效|进口|原矿|升级|新款|专利|超微孔|硝化|净水|净化"
CTA_END_PAT = r"价格|便宜|划算|下单|小黄车|去看看|抓紧|赶紧|赶快|最后|机会|活动|特价|优惠|链接|下方|有需要|有喜欢"
PICK = {s: [s] for s in TEMPLATE}
PICK["引入"] = ["招呼", "介绍"]


def sh(cmd, check=True, tail=600):
    r = subprocess.run(cmd, capture_output=True)
    if check and r.returncode != 0:
        err = (r.stderr or b"").decode("utf-8", "ignore")[-tail:]
        print(f"[FAIL] {' '.join(os.path.basename(str(c)) for c in cmd[:3])}\n{err}")
        sys.exit(1)
    return r


def need_ffmpeg():
    if not (os.path.exists(FFMPEG) and os.path.exists(FFPROBE)):
        print("未找到 ffmpeg/ffprobe, 请先运行:  python get_ffmpeg.py")
        sys.exit(1)


# ---------------- 切点吸附: 分段切点对齐到说话人的自然停顿 ----------------
# 字幕时间轴切分容易把一句话拦腰切断(话说一半就跳下一段)。源视频自带 BGM,
# 原始音轨找不到静音, 必须用 demucs 分离出的「干净人声」判断停顿。
# v3 做法: 先对每个视频的全片人声做一次 silencedetect 得到「语音区间表」(缓存),
# 再在区间表上吸附切点:
#   出点: 优先吸附到「句间长停顿」(>=0.45s); 若 t1 后话还在继续, 一路向后
#         延长到下一个句间停顿(最多+8s), 从根上杜绝话说一半硬切;
#         长停顿找不到才依次退到气口(>=0.25s)/任意停顿(>=0.10s)。
#   入点: 对齐到实际开口的时刻, 去掉上一句残留的尾音。

# 以这些词收尾的段基本是半句话(连词/悬着的成分), 选段时优先排除。
# 末尾可带语气词(啊/呢/嘛/呀/吧/哟/哦/喔/哈) —— "而且啊" / "但是呢" 这类也算半截话。
BAD_END_TAIL = re.compile(
    r"(而且|但是|然后|并且|可是|还是|就是|最主要|还能|还可以|因为|所以|如果|"
    r"让|把|跟|与|这|这个|这种|非常|特别)"
    r"(啊|呢|嘛|呀|吧|哟|哦|喔|哈)?$")

# 段首这些词说明是"承接前文"的半截话(它/这个/而且...), 放在开头没头没脑。
# 同样兼容带语气词的情况("而且啊" / "但是呢" 开头也不要)。
HANG_START = re.compile(
    r"^(它|这个|这款|这东西|这玩意|这里|这样|那这个|那个|他们|而且|然后|"
    r"但是|所以|因为|接着|接下来|另外|还有|再加上|其次|所以说)"
    r"(啊|呢|嘛|呀|吧|哟|哦|喔|哈)?")

# 数字型卖点: 同一条片里说法必须一致 (不能前段3合一后段5合一)
NUM_CLAIM = re.compile(r"(\d+)\s*(合一|种|层|天|年|倍|重|级|代|号|代)")


def extract_num_claims(text):
    """文案里的数字型卖点声明 -> {单位: 数值}"""
    out = {}
    for m in NUM_CLAIM.finditer(text):
        out.setdefault(m.group(2), m.group(1))
    return out


def speaker_of(video):
    """主播身份: 用视频相对路径的第一级文件夹名 (宋雅轩/侯佳豪...)"""
    return video.split("/")[0] if "/" in video else "(根目录)"


# 过渡句口播特征 (用于自动识别素材里现成的转场话术)
TRANSITION_PAT = r"再来看|接下来|注意看|重点来了|看这里|教你一招|划重点|那么问题|还有一个|另外大家|说了这么多"


# ---------------- 相邻画面相似检测 (dHash 帧指纹, 防同机位连播) ----------------
def frame_dhash(src_path, t, cache):
    """抽中间帧算 dHash 64bit 指纹; 相同机位/画面的段距离很小"""
    key = f"{src_path}|{t:.1f}"
    if key in cache:
        return cache[key]
    import tempfile
    tmpd = tempfile.mkdtemp(prefix="vmc_fh_")
    jpg = os.path.join(tmpd, "f.jpg")
    h = None
    try:
        sh([FFMPEG, "-y", "-ss", f"{max(0.0, t):.2f}", "-i", src_path,
            "-frames:v", "1", "-vf", "scale=72:90", "-q:v", "5", jpg],
           check=False)
        from PIL import Image
        img = Image.open(jpg).convert("L").resize((9, 8))
        px = list(img.getdata())
        bits = 0
        for row in range(8):
            for col in range(8):
                bits = (bits << 1) | (1 if px[row * 9 + col] <
                                      px[row * 9 + col + 1] else 0)
        h = bits
    except Exception:
        h = None
    finally:
        try:
            os.remove(jpg)
            os.rmdir(tmpd)
        except OSError:
            pass
    cache[key] = h
    return h

VAD_JSON = os.path.join(BUILD, "vad_cache.json")
VAD_VER = 2   # 阈值 -30dB: 兼容 demucs 人声里残留的轻 BGM (-35dB 会漏检全部停顿)


def load_vad_cache():
    if os.path.exists(VAD_JSON):
        try:
            with open(VAD_JSON, encoding="utf-8") as f:
                _c = json.load(f)
            if _c.get("ver") == VAD_VER:
                return _c.get("videos", {})
        except (OSError, ValueError):
            pass
    return {}


def get_vad(voc_path, cache, band=False):
    """视频的语音区间表 [[起,止],...]: 在干净人声上做一次 silencedetect, 结果缓存。
    band=True 时滤到人声频带(250-3400Hz)+更低阈值, 用于残留 BGM 盖过阈值的视频。
    key 直接用人声文件所在的内容寻址目录名。"""
    key = os.path.basename(os.path.dirname(voc_path)) + ("_vb" if band else "")
    if key in cache:
        return cache[key]
    af = ("highpass=f=250,lowpass=f=3400,silencedetect=noise=-25dB:d=0.10"
          if band else "silencedetect=noise=-30dB:d=0.10")
    r = subprocess.run(
        [FFMPEG, "-hide_banner", "-i", voc_path,
         "-af", af, "-f", "null", "-"],
        capture_output=True)
    err = (r.stderr or b"").decode("utf-8", "ignore")
    dm = re.search(r"Duration: (\d+):(\d+):(\d+(?:\.\d+)?)", err)
    dur = (int(dm.group(1)) * 3600 + int(dm.group(2)) * 60 + float(dm.group(3))
           if dm else 0.0)
    sil = []
    for m in re.finditer(r"silence_start: ([\d.]+)", err):
        s = float(m.group(1))
        m2 = re.search(r"silence_end: ([\d.]+)", err[m.end():])
        e = float(m2.group(1)) if m2 else (dur or s)
        sil.append((s, e))
    runs, pos = [], 0.0
    for s, e in sil:
        if s - pos > 0.10:
            runs.append([round(pos, 2), round(s, 2)])
        pos = max(pos, e)
    if dur and dur - pos > 0.10:
        runs.append([round(pos, 2), round(dur, 2)])
    cache[key] = {"dur": round(dur, 2), "runs": runs}
    return cache[key]


def refine_cut_points(runs, t0, t1, vdur=None):
    """基于语音区间吸附切点, 返回 (nt0, nt1)。runs: [[语音起, 语音止], ...]"""
    ends = []                        # (语音结束时刻, 其后停顿长度)
    for i, (s, e) in enumerate(runs):
        nxt = runs[i + 1][0] if i + 1 < len(runs) else (vdur or e + 9.0)
        if e >= t0 - 0.2:
            ends.append((e, max(0.0, nxt - e)))
    nt1 = None
    # 依次尝试: t1 附近的句间长停顿(含字幕滞后回吸) -> 向后最近的长停顿
    #           -> 气口 -> 任意停顿。窗口向回开到 1.8s: 字幕常比语音晚消失,
    #           语音其实已在 t1 前收尾, 回吸到真实句尾比向前吞下一句开头更稳
    for min_gap, lo, hi in ((0.45, t1 - 1.8, t1 + 1.2),
                            (0.45, t1 + 1.2, t1 + 8.0),
                            (0.25, t1 - 1.8, t1 + 8.0),
                            (0.10, t1 - 1.8, t1 + 8.0)):
        for e, g in ends:
            if lo <= e <= hi and g >= min_gap:
                nt1 = round(e + min(0.10, g / 3), 2)
                break
        if nt1 is not None:
            break
    if nt1 is None:                  # 全程无停顿(连续长句), 至少给足收尾空间
        nt1 = round(t1 + 1.2, 2)
    if vdur:
        nt1 = min(nt1, round(vdur - 0.05, 2))
    nt0 = round(t0, 2)
    for i, (s, e) in enumerate(runs):
        if s <= t0 <= e:             # t0 落在语音里
            if s >= t0 - 1.2:        # 开口就在 t0 附近(字幕略滞后) -> 对齐到实际开口
                nt0 = round(max(0.0, s - 0.06), 2)
            # 否则: 长语音区间中部(多句连说), 保持 t0, 不切进句中
            break
        if s > t0:                   # t0 在停顿里 -> 稍提前接住开口
            nt0 = round(max(t0, s - 0.35), 2)
            break
    if nt1 - nt0 < 1.8:              # 吸附结果过短则维持原切点
        return round(t0, 2), round(t1 + 0.3, 2)
    return nt0, nt1


# ---------------- 封面闪帧防护 ----------------
# 带货视频开头常放 1~3 秒静态封面大字卡(OCR 会把封面文字当成第一句钩子),
# 从这里起始的分段会把封面画面带进成片 -> 检测出封面区, 弃用压在上面的分段。
COVER_JSON = os.path.join(BUILD, "cover_cache.json")


def load_cover_cache():
    if os.path.exists(COVER_JSON):
        try:
            with open(COVER_JSON, encoding="utf-8") as f:
                _c = json.load(f)
            if _c.get("ver") == 1:
                return _c.get("covers", {})
        except (OSError, ValueError):
            pass
    return {}


def get_cover_end(video_path, key, cache, tmax=4.0):
    """检测视频开头的封面/海报闪帧, 返回应跳过的时刻 (无则 0)。
    实测素材的封面是导出时带上的 1~4 帧海报(第 0 帧与 0.1s 处画面骤变),
    freezedetect 抓不到 -> 直接比较帧指纹:
      0帧 vs 0.15s 骤变(>20)  -> 片头闪帧, 跳到 0.15s
      0帧≈0.15s≈0.5s 但 vs 1.0s 骤变 -> 约 1s 的静止封面卡, 跳到 0.95s
    正常实拍开头 (含固定机位) 两项都不满足, 不误伤。"""
    if key in cache:
        return cache[key]
    ce = 0.0
    try:
        fh = {}
        h0 = frame_dhash(video_path, 0.0, fh)
        if h0 is not None:
            h015 = frame_dhash(video_path, 0.15, fh)
            if h015 is not None:
                d015 = bin(h0 ^ h015).count("1")
                if d015 > 20:
                    ce = 0.15
                elif d015 <= 8:
                    h05 = frame_dhash(video_path, 0.5, fh)
                    h10 = frame_dhash(video_path, 1.0, fh)
                    if (h05 is not None and h10 is not None
                            and bin(h0 ^ h05).count("1") <= 8
                            and bin(h0 ^ h10).count("1") >= 25):
                        ce = 0.95
    except (OSError, ValueError, RuntimeError):
        ce = 0.0
    cache[key] = ce
    return ce


# ---------------- 硬件加速编码 ----------------
# 有 N 卡时自动用 NVENC 显卡编码 (实测 1080x1920 出片快约 6 倍, 画质不掉档);
# 没有显卡或设为 cpu 时自动回落 libx264, 成片质量一致
ENC_MODE = (os.environ.get("VMC_ENCODER") or "auto").strip().lower()
_VENC_OK = None


def nvenc_available():
    """本机显卡编码(NVENC)是否可用 (兼容旧调用: 走统一体检)"""
    return detect_hw().get("enc") == "nvenc"


# ---------------- 硬件自检: 每台电脑配置不同, 出片参数自动选最优 ----------------
HW_VER = 2
HW_CACHE = os.path.join(ROOT, "data", "hw_profile.json")


def _try_enc(args):
    """试编 1 帧, 判断这个编码器在本机是否真能用"""
    try:
        r = subprocess.run(
            [FFMPEG, "-y", "-hide_banner", "-loglevel", "error",
             "-f", "lavfi", "-i", "color=c=gray:s=320x576:d=1",
             "-frames:v", "1"] + args +
            ["-pix_fmt", "yuv420p", "-f", "null", "-"],
            capture_output=True, timeout=60)
        return r.returncode == 0
    except Exception:
        return False


def _total_ram_gb():
    try:
        if os.name == "nt":
            import ctypes

            class _MS(ctypes.Structure):
                _fields_ = [("dwLength", ctypes.c_ulong),
                            ("dwMemoryLoad", ctypes.c_ulong),
                            ("ullTotalPhys", ctypes.c_ulonglong),
                            ("ullAvailPhys", ctypes.c_ulonglong),
                            ("ullTotalPageFile", ctypes.c_ulonglong),
                            ("ullAvailPageFile", ctypes.c_ulonglong),
                            ("ullTotalVirtual", ctypes.c_ulonglong),
                            ("ullAvailVirtual", ctypes.c_ulonglong),
                            ("ullAvailExtendedVirtual", ctypes.c_ulonglong)]
            m = _MS()
            m.dwLength = ctypes.sizeof(_MS)
            ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m))
            return round(m.ullTotalPhys / 1073741824, 1)
        return round(os.sysconf("SC_PAGE_SIZE")
                     * os.sysconf("SC_PHYS_PAGES") / 1073741824, 1)
    except Exception:
        return 0.0


def _gpu_name():
    """显卡名 (N卡走 nvidia-smi, 其它走 wmic)"""
    try:
        r = subprocess.run(["nvidia-smi", "--query-gpu=name",
                            "--format=csv,noheader"],
                           capture_output=True, timeout=20)
        if r.returncode == 0:
            names = [x.strip() for x in (r.stdout or b"")
                     .decode("utf-8", "ignore").splitlines() if x.strip()]
            if names:
                return names[0]
    except Exception:
        pass
    if os.name == "nt":
        try:
            r = subprocess.run(["wmic", "path", "win32_VideoController",
                                "get", "name"], capture_output=True, timeout=25)
            names = [x.strip() for x in (r.stdout or b"")
                     .decode("utf-8", "ignore").splitlines()
                     if x.strip() and x.strip().lower() != "name"]
            if names:
                return names[0]
        except Exception:
            pass
    return ""


def detect_hw(refresh=False):
    """硬件体检: 显卡/CPU/内存 -> 编码器与并行建议 (结果缓存, 只测一次)
    编码器优先级: nvenc(N卡) > qsv(Intel核显) > amf(A卡) > cpu(无硬件编码)
    实测: OCR 并行只有 1.07x (onnxruntime 内部已吃满多核), 故不做 OCR 并行;
    workers 只作为"最多同时开几个项目窗口"的建议。"""
    if not refresh:
        try:
            with open(HW_CACHE, encoding="utf-8") as f:
                d = json.load(f)
            if isinstance(d, dict) and d.get("ver") == HW_VER:
                return d
        except (OSError, ValueError):
            pass
    cores = os.cpu_count() or 2
    ram = _total_ram_gb()
    gpu = _gpu_name()
    enc = "cpu"
    for tag, args in (("nvenc", ["-c:v", "h264_nvenc", "-preset", "p4"]),
                      ("qsv", ["-c:v", "h264_qsv"]),
                      ("amf", ["-c:v", "h264_amf"])):
        if _try_enc(args):
            enc = tag
            break
    if cores >= 12 and ram >= 16:
        workers = 4
    elif cores >= 8 and ram >= 8:
        workers = 3
    elif cores >= 4 and ram >= 4:
        workers = 2
    else:
        workers = 1
    if enc == "cpu":
        workers = min(workers, 2)     # 纯 CPU 机器别压太满
    prof = {"ver": HW_VER, "gpu": gpu, "enc": enc, "cores": cores,
            "ram_gb": ram, "workers": workers,
            "threads": max(1, min(8, cores // max(1, workers)))}
    try:
        os.makedirs(os.path.dirname(HW_CACHE), exist_ok=True)
        with open(HW_CACHE, "w", encoding="utf-8") as f:
            json.dump(prof, f, ensure_ascii=False, indent=1)
    except OSError:
        pass
    return prof


def hw_note():
    """一行人话描述本机方案 (界面/日志展示)"""
    h = detect_hw()
    names = {"nvenc": "显卡编码(N卡 NVENC)", "qsv": "核显编码(Intel QSV)",
             "amf": "显卡编码(A卡 AMF)", "cpu": "CPU 编码(x264)"}
    gpu = h.get("gpu") or "未识别到独显"
    if len(gpu) > 24:
        gpu = gpu[:24] + "..."
    return "%s · %d核 · %sGB  ->  %s (可同时开 %d 个项目窗口)" % (
        gpu, h.get("cores", 1), h.get("ram_gb", 0),
        names.get(h.get("enc"), "CPU 编码"), h.get("workers", 1))


def enc_tag():
    """当前实际使用的编码器 (日志显示用)"""
    if ENC_MODE == "cpu":
        return "CPU x264"
    return {"nvenc": "显卡 NVENC", "qsv": "核显 QSV",
            "amf": "显卡 AMF", "cpu": "CPU x264"}.get(
                detect_hw().get("enc"), "CPU x264")


def venc(crf=19):
    """视频编码参数: 按本机体检结果自动选最好的 (质量档位一一对应)"""
    if ENC_MODE == "cpu":
        return ["-c:v", "libx264", "-preset", "fast", "-crf", str(crf)]
    h = detect_hw()
    e = h.get("enc", "cpu")
    if e == "nvenc":
        return ["-c:v", "h264_nvenc", "-preset", "p4",
                "-rc", "vbr", "-cq", str(crf + 2)]
    if e == "qsv":
        return ["-c:v", "h264_qsv", "-global_quality", str(crf + 2)]
    if e == "amf":
        return ["-c:v", "h264_amf", "-quality", "balanced",
                "-usage", "transcoding"]
    return ["-c:v", "libx264", "-preset", "fast", "-crf", str(crf),
            "-threads", str(h.get("threads", 1))]


def ensure_dirs():
    for d in (DATA, BUILD, OUTDIR, STICKER_DIR, LIB):
        os.makedirs(d, exist_ok=True)


def load_segments(src_dir):
    if not os.path.exists(SEG_JSON):
        print("data/segments.json 不存在, 先运行: python mixcut_tool.py plan")
        sys.exit(1)
    with open(SEG_JSON, encoding="utf-8") as f:
        segs = json.load(f)
    # 校验源视频存在
    for item in segs:
        p = os.path.join(src_dir, item[0])
        if not os.path.exists(p):
            print(f"源视频不存在: {p}")
            sys.exit(1)
    return segs


def find_font():
    for f in (r"C:\Windows\Fonts\msyhbd.ttc", r"C:\Windows\Fonts\msyh.ttc",
              r"C:\Windows\Fonts\simhei.ttf", "/System/Library/Fonts/PingFang.ttc"):
        if os.path.exists(f):
            return f
    return None


# ================= 子命令: scan =================
def cmd_scan(args):
    need_ffmpeg()
    if not os.path.isdir(args.src):
        print(f"错误: 目录不存在: {args.src}")
        print("提示: 请确认盘符和文件夹名 (注意中文目录名要完全一致)")
        sys.exit(1)
    exts = (".mp4", ".mov", ".avi", ".mkv", ".flv", ".webm", ".m4v")
    found = []
    for dirpath, dirnames, filenames in os.walk(args.src):   # 递归所有子文件夹
        for fn in filenames:
            if fn.lower().endswith(exts):
                rel = os.path.relpath(os.path.join(dirpath, fn), args.src)
                found.append(rel.replace("\\", "/"))
    vids = sorted(found)
    if not vids:
        print(f"目录及其子文件夹中都没有视频: {args.src}")
        sys.exit(1)
    rows = []
    for rel in vids:
        r = sh([FFPROBE, "-v", "quiet", "-print_format", "json",
                "-show_format", "-show_streams", os.path.join(args.src, rel)])
        info = json.loads(r.stdout.decode("utf-8", "ignore"))
        dur = float(info.get("format", {}).get("duration", 0))
        v = next((s for s in info.get("streams", []) if s.get("codec_type") == "video"), {})
        rows.append(dict(name=rel, dur=round(dur, 2),
                         w=v.get("width", 0), h=v.get("height", 0)))
    with open(VIDEOS_JSON, "w", encoding="utf-8") as fp:
        json.dump(rows, fp, ensure_ascii=False, indent=2)
    for r_ in rows:
        print(f"{r_['name']:48s} {r_['dur']:6.1f}s  {r_['w']}x{r_['h']}")
    n_sub = len({os.path.dirname(r_["name"]) for r_ in rows} - {""})
    print(f"\n共 {len(rows)} 条 (递归含子文件夹 {n_sub} 个), 已写入 data/videos.json")


# ================= 字幕 OCR =================
def ocr_video_lines(src_path, dur, fps=1.5):
    """抽帧 + RapidOCR 识别字幕, 返回 [[开始秒, 文案], ...]"""
    import shutil
    import tempfile
    # 用系统临时目录(项目外): 项目内批量删除会被安全钩子拦截
    frames = tempfile.mkdtemp(prefix="mixcut_ocr_")
    try:
        # 字幕通常在画面下半部: 裁掉上 45% 加速识别并减少干扰
        sh([FFMPEG, "-y", "-i", src_path,
            "-vf", f"fps={fps},crop=iw:ih*0.55:0:ih*0.45",
            "-q:v", "3", os.path.join(frames, "f_%05d.jpg")])
        from rapidocr_onnxruntime import RapidOCR
        import difflib
        eng = RapidOCR()
        lines = []                       # [t0, t1, text]
        for idx, fn in enumerate(sorted(os.listdir(frames))):
            res, _ = eng(os.path.join(frames, fn))
            texts = [r[1].strip() for r in (res or [])
                     if float(r[2]) > 0.5 and len(r[1].strip()) >= 2]
            texts = [t for t in texts
                     if not re.fullmatch(r"[A-Za-z ]{3,}", t)]   # 英文水印噪音
            text = " ".join(texts).strip()
            t = round(idx / fps, 2)
            if not text:
                continue
            if lines and difflib.SequenceMatcher(
                    None, text, lines[-1][2]).ratio() > 0.6:
                lines[-1][1] = t                    # 同一句话延续
                if len(text) > len(lines[-1][2]):
                    lines[-1][2] = text             # 保留更完整识别
            else:
                lines.append([t, t, text])
        dur_f = float(dur or 0)
        return [[t0, txt] for t0, t1, txt in lines
                if dur_f <= 0 or t0 < dur_f - 0.3]
    finally:
        shutil.rmtree(frames, ignore_errors=True)


# ================= 子命令: subs =================
def cmd_subs(args):
    if not os.path.exists(VIDEOS_JSON):
        print("先运行: python mixcut_tool.py scan --src <视频目录>")
        sys.exit(1)
    with open(VIDEOS_JSON, encoding="utf-8") as f:
        vids = json.load(f)
    if os.path.exists(SUBS_JSON):
        with open(SUBS_JSON, encoding="utf-8") as f:
            old = json.load(f)
    else:
        old = {}
    need_ocr = [v for v in vids
                if not old.get(os.path.splitext(v["name"])[0], {}).get("lines")]
    if need_ocr:
        try:
            import rapidocr_onnxruntime  # noqa: F401
        except ImportError:
            print(f"提示: {len(need_ocr)} 条视频没有字幕数据, 但未安装 OCR 引擎")
            print("安装: pip install rapidocr-onnxruntime, 或手工填 data/subtitles.json")
        else:
            os.makedirs(BUILD, exist_ok=True)
            n = len(need_ocr)
            est = n * 15
            print(f"{n} 条视频没有字幕数据, 开始 OCR 自动识别 "
                  f"(预计 {est // 60} 分 {est % 60} 秒, 识别中请勿关闭)...", flush=True)
            t_start = time.time()

            def _save():
                with open(SUBS_JSON, "w", encoding="utf-8") as fp:
                    json.dump(old, fp, ensure_ascii=False, indent=2)

            def _report(i, v, lines, extra=""):
                el = time.time() - t_start
                remain = el / i * (n - i) if i else 0
                print(f"  [{i}/{n}] {v['name']} -> {len(lines)} 句 "
                      f"(已用 {el / 60:.0f} 分, 剩余约 {remain / 60:.0f} 分){extra}",
                      flush=True)

            # 串行识别: onnxruntime 内部已多线程, 多进程反而互相抢核
            for i, v in enumerate(need_ocr):
                name = os.path.splitext(v["name"])[0]
                try:
                    lines = ocr_video_lines(
                        os.path.join(args.src, v["name"]), v["dur"])
                except Exception as e:
                    print(f"  [{i + 1}/{n}] {v['name']} 识别失败: {e}", flush=True)
                    lines = []
                old[name] = dict(dur=v["dur"], lines=lines)
                _save()
                _report(i + 1, v, lines)
    data = {}
    for v in vids:
        name = os.path.splitext(v["name"])[0]
        data[name] = old.get(name, dict(dur=v["dur"], lines=[]))
    with open(SUBS_JSON, "w", encoding="utf-8") as fp:
        json.dump(data, fp, ensure_ascii=False, indent=2)
    filled = sum(1 for d in data.values() if d.get("lines"))
    print(f"字幕数据已写入 data/subtitles.json")
    print(f"  已有字幕 {filled}/{len(data)} 条")
    if filled < len(data):
        print("  缺失的字幕可在 data/subtitles.json 手工补填后重跑 subs/plan")


# ================= 子命令: plan (文案分析自动拼装) =================
def classify(text):
    if not text.strip():
        return "空"
    for role, pat in RULES:
        if re.search(pat, text):
            return role
    return "介绍"


def build_sentences(subs):
    sents = []
    for video, d in subs.items():
        items = [(float(t), txt) for t, txt in d.get("lines", [])]
        items.sort()
        dur = float(d.get("dur", items[-1][0] + 2 if items else 0))
        for i, (t, text) in enumerate(items):
            t1 = items[i + 1][0] if i + 1 < len(items) else dur
            sents.append(dict(video=video, t0=t, t1=min(t1, dur),
                              text=text, role=classify(text)))
    return sents


# 段尾这些字/词说明话没说完, 应继续吸收下一句
UNFINISHED = re.compile(r"(而且|但是|然后|并且|最主要|还能|还可以|还能|就是|让|把|跟|和|与|呢|的|了|吧|啊|嘛|是)$")


def merge_same_role(sents):
    """整段合并: 同视频相邻(间隔<0.5s)的句子合并为一组, 最多4句, 保留完整话术。
    组的角色取首句角色; 遇到 CTA/招呼 视为话题边界, 不并入。"""
    sents.sort(key=lambda s: (s["video"], s["t0"]))
    out, used = [], set()
    for i, s in enumerate(sents):
        if id(s) in used or s["role"] in ("空",):
            continue
        seg = dict(s)
        used.add(id(s))
        n = 0
        for j in range(i + 1, len(sents)):
            n2 = sents[j]
            if (n2["video"] != seg["video"] or id(n2) in used or n2["role"] in ("空",)):
                continue
            if (n2["role"] != seg["role"] and n2["role"] in ("CTA", "招呼")
                    and not UNFINISHED.search(seg["text"])):
                break                                # 话题边界(角色不同), 开始新组
            if n2["t0"] - seg["t1"] > 0.5:         # 间隔过大, 不合并
                break
            if n >= (5 if UNFINISHED.search(seg["text"]) else 3):   # 最多4~6句
                break
            seg["t1"] = n2["t1"]
            seg["text"] += " / " + n2["text"]
            used.add(id(n2))
            n += 1
        out.append(seg)
    return out


# ================= 素材库: 开头钩子 / 中间卖点 / 结尾号召 三库匹配 =================
LIB_JSON = os.path.join(DATA, "clip_library.json")


def load_subtitle_pool(src=None):
    """加载字幕 -> 句子 -> 整段合并, 得到候选段池 (含重复扫描条目去重)"""
    if not os.path.exists(SUBS_JSON):
        return [], {}
    with open(SUBS_JSON, encoding="utf-8") as f:
        subs = json.load(f)
    filled = {k: v for k, v in subs.items()
              if isinstance(v, dict) and v.get("lines")}
    if not filled:
        return [], {}
    # 同一物理视频可能因不同根目录扫描出现两份相对路径, 去掉冗余的那份
    keys = list(filled)
    drop = set()
    for k in keys:
        for other in keys:
            if other != k and other.endswith("/" + k):
                if src is None or os.path.exists(os.path.join(src, other)):
                    drop.add(k)
                    break
    filled = {k: v for k, v in filled.items() if k not in drop}
    dur_map = {k: float(v.get("dur", 0)) for k, v in filled.items()}
    pool = merge_same_role(build_sentences(filled))
    # OCR 抖动会把同一句话在不同时间识别成两条 -> 相同段落出现两份,
    # 按 (视频, 起点) 去重, 防止同一段在同一条成片里出现两次
    seen = set()
    dedup = []
    for s in pool:
        k = (s["video"], round(s["t0"], 1))
        if k in seen:
            continue
        seen.add(k)
        dedup.append(s)
    return dedup, dur_map


def build_pools(pool):
    """三库拆分 (v3: 新增过渡池):
    - 文案里带 下单/价格/优惠 等 CTA 痕迹的段(无论首句角色)一律进结尾库,
      杜绝"招呼开头+下单收尾"的合并组被当成开头 -> 结尾放开头
    - 痛点/招呼角色 + 带钩子词(居然/没想到/千万别...)的段进开头库(扩容,
      开头池越大批量越不重样)
    - 首句带 再来看/接下来/注意看 等转场话术的段进过渡库"""
    pools = {"开头": [], "卖点": [], "结尾": [], "过渡": []}
    for s in pool:
        first = s["text"].split(" / ")[0]
        if s["role"] == "CTA" or re.search(CTA_END_PAT, s["text"]):
            pools["结尾"].append(s)
        elif s["role"] in ("痛点", "招呼") or re.search(HOOK_PAT, first):
            pools["开头"].append(s)
        elif re.search(TRANSITION_PAT, first) and 1.5 <= s["t1"] - s["t0"] <= 6:
            pools["过渡"].append(s)
        else:
            pools["卖点"].append(s)
    return pools


def pool_pattern_ok(key, text):
    pat = {"开头": HOOK_PAT, "卖点": SELL_PAT, "结尾": CTA_END_PAT}.get(key)
    return bool(pat and re.search(pat, text))


SLOT_POOL = {"痛点": "开头", "引入": "开头", "CTA": "结尾"}


# 时长模式: 槽位越少片子越短 (auto=完整9槽约65-80s)
DURATION_TEMPLATES = {
    30: ["痛点", "引入", "材质", "功效", "CTA"],
    45: ["痛点", "引入", "外观", "材质", "功效", "安全", "CTA"],
    60: ["痛点", "引入", "外观", "材质", "功效", "安全", "温控", "CTA"],
}


def pick_plan(pools_or_segments, rng=None, history=None, template=None,
              voice="auto", phash=None, banned=None, ai_scores=None):
    """从三库匹配拼装方案 (v2 硬约束版)。
    template: 槽位列表(时长模式), 默认完整 9 槽。
    voice: 音色策略 auto=随机 / same=同条尽量同一主播 / alternate=每段换主播。
    phash: callable(video, t) -> 64bit 帧指纹; 相邻段画面太像(同机位连播)会重罚。
    banned: set[(video, round(t0,1))] AI终审拉黑的问题段, 直接不进候选。
    ai_scores: {(video, round(t0,1)): {"pool":.., "score":1-10}} AI素材库评审,
               高分段加分低分段扣分 (挪库/剔除在 cmd_mix 里做)。
    - 开头库与结尾库互不借用 (杜绝结尾放开头/开头放结尾)
    - 非 CTA 槽位绝不选带 CTA 话术的段
    - 历史方案用过的段: 剩>=3个没用过的候选时硬轮换 (批量开头不撞车)
    - 与本方案已选段文案相似>55% 直接排除 (不同人念同一套话术也不重复)"""
    hist = history or []
    tpl = template or TEMPLATE
    pools = (pools_or_segments if isinstance(pools_or_segments, dict)
             else build_pools(pools_or_segments))
    plan, use_count, picked = [], {}, set()
    hist_used = {}                       # (video, t0) -> 已用次数
    hist_slot_texts = {}                 # slot -> 历史同槽位选段的文案(开头只比首句)
    for hp in hist:
        for p in hp:
            k = (p["video"], round(p["t0"], 1))
            hist_used[k] = hist_used.get(k, 0) + 1
            hist_slot_texts.setdefault(p["slot"], []).append(
                p["text"].split(" / ")[0]
                if p["slot"] in ("痛点", "引入") else p["text"])
    for slot in tpl:
        pk = SLOT_POOL.get(slot, "卖点")
        in_range = lambda s: 2.0 <= s["t1"] - s["t0"] <= 14 and id(s) not in picked
        main = [s for s in pools.get(pk, []) if in_range(s)
                and (not banned
                     or (s["video"], round(s["t0"], 1)) not in banned)]
        if banned and 0 < len(main) < 6:
            # 拉黑后该库剩余太少(批量撑不起轮换) -> 本库忽略拉黑保产量
            main = [s for s in pools.get(pk, []) if in_range(s)]
        if len(main) >= 3:
            cands = main
        else:   # 库内不足才兜底, 且只向卖点库借 (开头/结尾绝不互借)
            borrow_pk = "卖点" if pk in ("开头", "结尾") else None
            borrow = [s for s in pools.get(borrow_pk, []) if in_range(s)
                      and (not banned
                           or (s["video"], round(s["t0"], 1)) not in banned)] \
                if borrow_pk else []
            cands = main + [s for s in borrow
                            if all(id(s) != id(m) for m in main)]
        if not cands:
            continue
        if not plan:                 # 第一段必须自含: 悬空开头(它/这个/而且...)硬排除
            anchored = [s for s in cands
                        if not HANG_START.search(s["text"].split(" / ")[0])]
            if len(anchored) >= 3:
                cands = anchored
        if slot != "CTA":                # CTA 话术绝不当开头/卖点
            no_cta = [s for s in cands
                      if not re.search(CTA_END_PAT, s["text"])]
            if len(no_cta) >= 3:
                cands = no_cta
        # 句子完整性: 半句话结尾(连词/悬着成分)的段优先排除, 候选不足才保留
        good = [s for s in cands
                if not BAD_END_TAIL.search(s["text"].split(" / ")[-1])]
        if len(good) >= 3:
            cands = good
        # 历史硬轮换: 还有>=3个没用过的候选, 就只用没用过的
        unused = [s for s in cands
                  if (s["video"], round(s["t0"], 1)) not in hist_used]
        if len(unused) >= 3:
            cands = unused
        # 同槽位文案去重: 不同人念同一句钩子/同一套结尾, 相似>55%也排除
        # (开头槽只比首句 -- 观众看到的开头就是第一句)
        # 池子打穿(fresh空)时改用 min-max: 挑与历史"最不撞"的, 不放任撞车
        if slot in hist_slot_texts and len(cands) > 3:
            cmp_key = (lambda s: s["text"].split(" / ")[0]) \
                if slot in ("痛点", "引入") else (lambda s: s["text"])
            sims = {id(s): max(
                difflib.SequenceMatcher(None, cmp_key(s), t).ratio()
                for t in hist_slot_texts[slot]) for s in cands}
            fresh = [s for s in cands if sims[id(s)] <= 0.55]
            floor = 1 if slot in ("痛点", "引入") else 3
            if len(fresh) >= floor:
                cands = fresh
            elif fresh or slot in ("痛点", "引入"):
                # 全撞车时保留"最不撞"的前几个 (开头槽即使全撞也挑差异最大的)
                cands = sorted(cands, key=lambda s: sims[id(s)])[:3]
        # 段内硬去重: 与已选段相似>55%的候选直接出局 (底线1: 有不重复的绝不选重复的)
        if plan:
            uniq = [s for s in cands
                    if max(difflib.SequenceMatcher(
                        None, s["text"], p["text"]).ratio()
                        for p in plan) <= 0.55]
            if uniq:
                cands = uniq
            elif slot != "CTA" and plan:
                continue        # 候选全撞车: 非结尾槽宁可跳过也不重复卖点

        def score(s):
            dur = s["t1"] - s["t0"]
            n_lines = s["text"].count(" / ") + 1
            sim = max((difflib.SequenceMatcher(None, s["text"], p["text"]).ratio()
                       for p in plan), default=0)
            # CTA 是转化关键: 复用惩罚放宽, 时长目标偏短也接受; 短模板压时长
            u_pen = 3 if slot == "CTA" else 10
            d_tgt = 4.5 if slot == "CTA" else \
                (5.2 if len(tpl) <= 7 else 6.5)
            # 爆款要素加分: 开头要有钩子, 中段要有卖点数字, 结尾要有行动号召
            bonus = 3.0 if pool_pattern_ok(pk, s["text"]) else 0.0
            h = hist_used.get((s["video"], round(s["t0"], 1)), 0)
            # 音色策略: same=同主播加分 / alternate=换主播加分
            v_bonus = 0.0
            if plan:
                same_spk = speaker_of(s["video"]) == \
                    speaker_of(plan[-1]["video"])
                if voice == "same" and same_spk:
                    v_bonus = 6.0
                elif voice == "alternate" and same_spk:
                    v_bonus = -6.0
            # 画面相似惩罚: 与前一段画面太像(同机位连播观感差) -6
            if plan and phash:
                p_last = plan[-1]
                h1 = phash(p_last["video"],
                           (p_last["t0"] + p_last["t1"]) / 2)
                h2 = phash(s["video"], (s["t0"] + s["t1"]) / 2)
                if h1 is not None and h2 is not None:
                    if bin(h1 ^ h2).count("1") < 12:
                        v_bonus -= 6.0
            jitter = rng.uniform(-2.5, 2.5) if rng is not None else 0.0
            # AI 素材库评审: 高分段加分 / 低分段扣分 (5分=中性)
            ai_q = 0.0
            if ai_scores:
                _a = ai_scores.get((s["video"], round(s["t0"], 1)))
                if _a:
                    ai_q = (float(_a.get("score", 5)) - 5) * 1.2
            return (-use_count.get(s["video"], 0) * u_pen  # 视频用得越多越靠后
                    - abs(d_tgt - dur)                     # 时长接近目标(完整话术)
                    + min(n_lines, 4) * 1.5                # 多句合并(信息完整)加分
                    + bonus                                # 爆款要素加分
                    - sim * 8                              # 与本方案已选段重复度惩罚
                    - h * 7                                # 与历史方案重复惩罚
                    - (4.0 if BAD_END_TAIL.search(         # 半句话结尾重罚
                        s["text"].split(" / ")[-1]) else 0)
                    - (2.5 if HANG_START.search(           # 悬空开头降权
                        s["text"].split(" / ")[0]) else 0)
                    + v_bonus                              # 音色策略
                    + ai_q                                  # AI素材库质量分
                    + jitter)                              # 随机扰动 -> 批量条条不同
        cands.sort(key=score, reverse=True)
        pick = cands[0]
        if slot == "引入" and plan and plan[-1]["video"] == pick["video"] and len(cands) > 1:
            pick = cands[1]   # 开场和引入避免同视频
        picked.add(id(pick))
        use_count[pick["video"]] = use_count.get(pick["video"], 0) + 1
        plan.append(dict(slot=slot, **pick))
    return plan


def insert_transitions(plan, pools, rng):
    """在话题切换处插入过渡句口播 (素材里现成的"再来看/接下来/注意看"段)。
    插入点: 引入段之后 + 中段一处。素材不足则跳过, 绝不硬塞。"""
    cands = [s for s in pools.get("过渡", [])
             if 1.5 <= s["t1"] - s["t0"] <= 6
             and not BAD_END_TAIL.search(s["text"].split(" / ")[-1])]
    if not cands:
        print("[过渡句] 素材里没有现成的转场口播(再来看/接下来/注意看...), 跳过; "
              "多录几句即可启用")
        return plan
    used = set()
    out = []
    mid = len(plan) // 2
    for i, seg in enumerate(plan):
        out.append(seg)
        want = (seg["slot"] == "引入") or (i == mid and seg["slot"] != "CTA")
        if not want or i == len(plan) - 1:
            continue
        ok = [c for c in cands
              if id(c) not in used
              and all(difflib.SequenceMatcher(None, c["text"], p["text"]).ratio() < 0.6
                      for p in plan)]
        if ok:
            pick = rng.choice(ok)
            used.add(id(pick))
            out.append(dict(slot="过渡", video=pick["video"], t0=pick["t0"],
                            t1=pick["t1"], text=pick["text"],
                            role=pick.get("role", "介绍")))
    if len(out) > len(plan):
        print(f"[过渡句] 已在话题切换处插入 {len(out) - len(plan)} 句转场口播")
    return out


def cmd_library(args=None):
    """把全部素材按 开头钩子/中间卖点/结尾号召 拆分, 存入 data/clip_library.json"""
    pool, _ = load_subtitle_pool()
    if not pool:
        print("data/subtitles.json 不存在或没有字幕数据, 先运行 subs 命令")
        sys.exit(1)
    pools = build_pools(pool)
    out = {}
    for name, key in (("开头钩子", "开头"), ("中间卖点", "卖点"), ("结尾号召", "结尾")):
        out[name] = [dict(video=s["video"], t0=round(s["t0"], 2), t1=round(s["t1"], 2),
                          text=s["text"], role=s["role"],
                          精选=pool_pattern_ok(key, s["text"])) for s in pools[key]]
    lib = {"lib_ver": 2,
           "subtitles_fingerprint":
           hashlib.md5(open(SUBS_JSON, "rb").read()).hexdigest(), "库": out}
    with open(LIB_JSON, "w", encoding="utf-8") as f:
        json.dump(lib, f, ensure_ascii=False, indent=1)
    print("素材库已写入 data/clip_library.json (可手工删改条目, 下次批量混剪生效)")
    for name in out:
        n = len(out[name])
        j = sum(1 for e in out[name] if e["精选"])
        print(f"  {name}: {n} 条 (其中爆款精选 {j} 条)")


# ================= 链接提取 (视频素材获取 + 文案提取) =================
GRAB_UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
           "(KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36")
GRAB_UA_MOBILE = ("Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) "
                  "AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 "
                  "Mobile/15E148 Safari/604.1")
GRAB_URL_RE = re.compile(r"https?://[^\s，,。;；'\"”’<>【】\]\)】]+")
GRAB_DL_JSON = os.path.join(ROOT, ".grabbed.json")
EXTRA_PY = os.path.join(ROOT, "extra_py")


def _ensure_pkg(mod_name, pip_name):
    """缺依赖时自动安装到 extra_py (仅首次, 需联网 -- 提取视频本来就要联网)"""
    try:
        __import__(mod_name)
        return True
    except ImportError:
        pass
    if os.path.isdir(EXTRA_PY) and EXTRA_PY not in sys.path:
        sys.path.insert(0, EXTRA_PY)
        try:
            __import__(mod_name)
            return True
        except ImportError:
            pass
    print(f"[组件] 首次使用提取功能, 自动安装 {pip_name} (约1分钟, 仅此一次)...")
    for mirror in ("https://pypi.tuna.tsinghua.edu.cn/simple", None):
        cmd = [sys.executable, "-m", "pip", "install", "-q",
               "--target", EXTRA_PY, pip_name]
        if mirror:
            cmd += ["-i", mirror]
        r = subprocess.run(cmd, capture_output=True)
        if r.returncode == 0:
            if EXTRA_PY not in sys.path:
                sys.path.insert(0, EXTRA_PY)
            try:
                __import__(mod_name)
                return True
            except ImportError:
                continue
    print(f"[组件] {pip_name} 安装失败, 请检查网络后重试")
    return False


def grab_extract_urls(text):
    """从任意文本(分享文字/笔记/文档)里抽取所有视频链接"""
    out = []
    for m in GRAB_URL_RE.finditer(text):
        u = m.group(0).rstrip(".,;")
        u = u[:-1] if u.endswith("/") and u.count("/") > 3 else u
        if u not in out:
            out.append(u)
    return out


def grab_platform_of(url):
    u = url.lower()
    if "douyin.com" in u or "iesdouyin" in u:
        return "douyin"
    if "kuaishou.com" in u or "chenzhongtech" in u:
        return "kuaishou"
    if "bilibili.com" in u or "b23.tv" in u:
        return "bilibili"
    if "xiaohongshu.com" in u or "xhslink" in u:
        return "xhs"
    if "ixigua.com" in u:
        return "xigua"
    if "weishi.qq.com" in u:
        return "weishi"
    if "youtube.com" in u or "youtu.be" in u:
        return "youtube"
    return "other"


def _grab_requests():
    if not _ensure_pkg("requests", "requests"):
        raise RuntimeError("网络组件不可用, 请检查网络后重试")
    import requests
    return requests


def grab_douyin_resolve(url, cookie=""):
    """抖音无水印解析: 短链302 -> item_id -> iesdouyin 接口 -> playwm 换 play"""
    requests = _grab_requests()
    s = requests.Session()
    s.headers.update({"User-Agent": GRAB_UA_MOBILE})
    if cookie:
        s.headers["Cookie"] = cookie
    real = url
    try:
        r = s.get(url, allow_redirects=False, timeout=15)
        if 300 <= r.status_code < 400 and r.headers.get("Location"):
            real = r.headers["Location"]
    except OSError:
        pass
    m = (re.search(r"/video/(\d+)", real) or re.search(r"/note/(\d+)", real)
         or re.search(r"item_ids=(\d+)", real)
         or re.search(r"modal_id=(\d+)", real))
    if not m:
        if "/share/user/" in real or "sec_uid=" in real:
            raise RuntimeError("这是作者【主页】链接, 不是单条视频 — "
                               "请打开 TA 的某条视频点分享再复制")
        # 兜底: 交给 DouyinSolver 解析 (支持图集等更多形态)
        if not _ensure_pkg("douyin_downloader", "DouyinSolver"):
            raise RuntimeError("无法从短链提取视频ID, 且解析组件不可用")
        from douyin_downloader import DouyinDownloader
        info = DouyinDownloader(session=s).parse(url)
        return {"platform": "douyin", "id": info.aweme_id,
                "title": (info.title or ("douyin_" + info.aweme_id))[:80],
                "author": info.author or "",
                "duration": (info.duration or 0) / 1000.0,
                "cover": info.cover or "", "video_url": info.play_url or "",
                "images": list(info.images or []), "extra": {}}
    vid = m.group(1)
    api = ("https://www.iesdouyin.com/web/api/v2/aweme/iteminfo/"
           "?item_ids=" + vid)
    r = s.get(api, timeout=15,
              headers={"User-Agent": GRAB_UA_MOBILE,
                       "Referer": "https://www.iesdouyin.com/"})
    data = r.json()
    items = data.get("item_list") or []
    if not items:
        raise RuntimeError("抖音接口未返回数据 (视频可能已删/私密/需Cookie)")
    it = items[0]
    title = (it.get("desc") or ("douyin_" + vid))[:80]
    author = (it.get("author") or {}).get("nickname", "")
    duration = int(it.get("duration", 0)) / 1000.0
    cover = (((it.get("video") or {}).get("cover") or {}).get("url_list")
             or [""])[0]
    play = (((it.get("video") or {}).get("play_addr") or {}).get("url_list")
            or [""])[0]
    if not play:
        raise RuntimeError("未取到视频地址")
    play = play.replace("/playwm/", "/play/")       # 关键: 无水印源
    images = [((im.get("url_list") or [""])[0]) for im in it.get("images") or []]
    return {"platform": "douyin", "id": vid, "title": title, "author": author,
            "duration": duration, "cover": cover, "video_url": play,
            "images": [u for u in images if u], "extra": {}}


def _ytdlp_silent():
    class _L:
        def debug(self, msg):
            pass

        def warning(self, msg):
            pass

        def error(self, msg):
            pass
    return _L()


def grab_ytdlp_resolve(url, cookie="", browser_cookies=False):
    if not _ensure_pkg("yt_dlp", "yt-dlp"):
        raise RuntimeError("通用引擎组件不可用")
    import yt_dlp
    base = {"quiet": True, "no_warnings": True, "noplaylist": True,
            "format": "bv*+ba/b", "logger": _ytdlp_silent()}
    if cookie:
        base["http_headers"] = {"Cookie": cookie}

    def _run(opts):
        with yt_dlp.YoutubeDL(opts) as ydl:
            return ydl.extract_info(url, download=False)

    if browser_cookies:
        # 从本机浏览器读 cookie (Chrome/Edge/Firefox 依次试;
        # 用户用浏览器打开过 douyin.com 即可, 不需要登录)
        last = None
        for b in ("chrome", "edge", "firefox"):
            try:
                info = _run(dict(base, cookiesfrombrowser=(b,)))
                return _fmt_ytdlp(info, url)
            except Exception as e:
                last = e
        raise last
    info = _run(base)
    return _fmt_ytdlp(info, url)


def _fmt_ytdlp(info, url):
    return {"platform": grab_platform_of(url), "id": info.get("id", ""),
            "title": (info.get("title") or "video")[:80],
            "author": info.get("uploader") or info.get("channel") or "",
            "duration": float(info.get("duration") or 0),
            "cover": info.get("thumbnail") or "",
            "video_url": info.get("webpage_url") or url,
            "images": [], "extra": {}}


_GRAB_BROWSERS = [
    r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
    r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
    r"C:\Program Files\Google\Chrome\Application\chrome.exe",
    r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
]


def _dy_profile_dir():
    """抖音无头浏览器用的持久化 profile 目录。
    关键: 复用同一个 profile, 浏览器会累积 ttwid/msToken 等 cookie,
    后续渲染就像"回头客", 大幅降低被抖音风控(弹验证码)的概率。"""
    import tempfile
    bases = [os.environ.get("LOCALAPPDATA"), os.path.join(ROOT, "data"),
             tempfile.gettempdir()]
    for b in bases:
        if not b:
            continue
        d = os.path.join(b, "VideoMixCut", "dy_profile")
        try:
            os.makedirs(d, exist_ok=True)
            return d
        except OSError:
            continue
    return tempfile.mkdtemp(prefix="vmc_dy_")


def _dy_free_port():
    """让系统分一个空闲端口, 避免 9345 被上次没退干净的浏览器占着导致起不来"""
    import socket as _sock
    s = _sock.socket(_sock.AF_INET, _sock.SOCK_STREAM)
    try:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]
    finally:
        s.close()


def _dy_warm(profile):
    """首次用持久 profile 时先访问一次抖音首页, 拿到 ttwid 等 cookie"""
    exe = next((p for p in _GRAB_BROWSERS if os.path.exists(p)), None)
    if not exe:
        return
    mark = os.path.join(profile, ".warmed")
    if os.path.exists(mark):
        return
    try:
        subprocess.run(
            [exe, "--headless=new", "--disable-gpu", "--no-first-run",
             "--user-data-dir=" + profile, "--virtual-time-budget=8000",
             "--dump-dom", "https://www.douyin.com/"],
            capture_output=True, timeout=60)
    except Exception:
        pass
    try:
        with open(mark, "w") as f:
            f.write("1")
    except OSError:
        pass


def _dy_parse_dom(dom, vid):
    """从渲染出的 DOM 里抠无水印直链 / 标题 / 作者 / 视频ID"""
    src = None
    for m in re.finditer(r"<video[^>]*>(.*?)</video>", dom, re.S):
        s = re.search(r'src="([^"]+)"', m.group(0))
        if s and "douyinvod" in s.group(1):
            src = s.group(1)
            break
    if not src:
        for m in re.finditer(r'(https?://[^\s"<>\\]+douyinvod[^\s"<>\\]+)', dom):
            src = m.group(1)
            break
    if not src:
        return None
    if not vid:
        m = (re.search(r'"aweme_id"\s*:\s*"?(\d+)', dom)
             or re.search(r"/video/(\d+)", dom))
        if m:
            vid = m.group(1)
    vid = vid or "unknown"
    title = vid
    m = re.search(r"<title[^>]*>(.*?)</title>", dom, re.S)
    if m:
        title = m.group(1).strip().split(" - 抖音")[0][:80] or vid
    author = ""
    m = re.search(r'([\w\u4e00-\u9fa5·]{1,24})于\d{8}发布', dom)
    if m:
        author = m.group(1)
    return {"platform": "douyin", "id": vid, "title": title,
            "author": author, "duration": 0.0, "cover": "",
            "video_url": src, "images": [],
            "extra": {"webpage": "https://www.douyin.com/video/" + vid}}


# ==================== 抖音解析 v2.6.6: CDP 直取播放地址 ====================
# 为什么换方案(2026-09 实测):
#   1) 抖音分享页自 2026-08 起, 对无 cookie 请求不再渲染 play_addr(只返壳页)
#      -> 老的 --dump-dom 渲染方案必然拿不到地址
#   2) yt-dlp 的 douyin 提取器走的接口已废(403 Uifid Not Found), 喂任何
#      cookie 都不行 -> 它自己也注释了 "TODO: Run verification challenge"
#   3) 官方 detail 接口需要 a_bogus 签名 + UIFID, 只有真实浏览器才凑得齐
# 现方案: 用无头浏览器打开视频页, 让页面 JS 自己完成风控挑战并请求数据;
#         我们通过 DevTools 协议(CDP)把【页面自己发出的 detail 响应】截下来,
#         从里面直接取官方无水印地址(含音视频, 清晰度也最高)。
#         不依赖第三方库: websocket 用标准库 socket 手写帧。

_DY_CDP_PORT = 9345


class _DyCDP(object):
    """极简 Chrome DevTools Protocol 客户端(纯标准库实现 websocket)"""

    def __init__(self):
        self.sock = None
        self._id = 0
        self.reqs = []        # 捕获到的请求 URL
        self.details = []     # 捕获到的 aweme/detail 响应 requestId

    # ---------------- websocket 底层 ----------------
    @staticmethod
    def _recvn(sock, n):
        buf = b""
        while len(buf) < n:
            chunk = sock.recv(n - len(buf))
            if not chunk:
                raise OSError("CDP 连接已断开")
            buf += chunk
        return buf

    def connect(self, ws_url):
        import base64
        import socket as _sock
        from urllib.parse import urlparse
        u = urlparse(ws_url)
        self.sock = _sock.create_connection((u.hostname, u.port), timeout=30)
        key = base64.b64encode(os.urandom(16)).decode()
        req = ("GET %s HTTP/1.1\r\nHost: %s:%d\r\nUpgrade: websocket\r\n"
               "Connection: Upgrade\r\nSec-WebSocket-Key: %s\r\n"
               "Sec-WebSocket-Version: 13\r\n\r\n"
               % (u.path, u.hostname, u.port, key))
        self.sock.sendall(req.encode())
        head = b""
        while b"\r\n\r\n" not in head:
            head += self.sock.recv(4096)
        if b" 101 " not in head.split(b"\r\n")[0]:
            raise OSError("浏览器调试通道握手失败")
        self.sock.settimeout(1.0)

    def _send(self, obj):
        payload = json.dumps(obj).encode("utf-8")
        mask = os.urandom(4)
        n = len(payload)
        frame = bytearray([0x81])
        if n < 126:
            frame.append(0x80 | n)
        elif n < 65536:
            frame.append(0x80 | 126)
            frame += struct.pack(">H", n)
        else:
            frame.append(0x80 | 127)
            frame += struct.pack(">Q", n)
        frame += mask
        frame += bytes(b ^ mask[i % 4] for i, b in enumerate(payload))
        self.sock.sendall(bytes(frame))

    def _recv_msg(self):
        parts = []
        while True:
            head = self._recvn(self.sock, 2)
            fin = head[0] & 0x80
            op = head[0] & 0x0F
            ln = head[1] & 0x7F
            if ln == 126:
                ln = struct.unpack(">H", self._recvn(self.sock, 2))[0]
            elif ln == 127:
                ln = struct.unpack(">Q", self._recvn(self.sock, 8))[0]
            data = self._recvn(self.sock, ln) if ln else b""
            if op == 0x8:
                raise OSError("CDP 连接被关闭")
            if op == 0x9:
                continue
            parts.append(data)
            if fin:
                break
        return json.loads(b"".join(parts).decode("utf-8", "ignore"))

    # ---------------- 事件收集 ----------------
    def _note(self, msg):
        method = msg.get("method")
        if method == "Network.requestWillBeSent":
            url = ((msg.get("params") or {}).get("request") or {}).get("url")
            if url:
                self.reqs.append(url)
        elif method == "Network.responseReceived":
            p = msg.get("params") or {}
            url = ((p.get("response") or {}).get("url")) or ""
            if "aweme/detail" in url:
                rid = p.get("requestId")
                if rid and rid not in self.details:
                    self.details.append(rid)

    # ---------------- 命令 ----------------
    def call(self, method, params=None, timeout=12):
        self._id += 1
        mid = self._id
        self._send({"id": mid, "method": method, "params": params or {}})
        t0 = time.time()
        while time.time() - t0 < timeout:
            try:
                msg = self._recv_msg()
            except (OSError, ValueError):
                continue
            self._note(msg)
            if msg.get("id") == mid:
                return msg.get("result") or {}
        return {}

    def drain(self, seconds):
        t0 = time.time()
        while time.time() - t0 < seconds:
            try:
                msg = self._recv_msg()
            except (OSError, ValueError):
                continue
            self._note(msg)

    def js(self, expr, timeout=8):
        r = self.call("Runtime.evaluate",
                      {"expression": expr, "returnByValue": True},
                      timeout=timeout)
        return (r.get("result") or {}).get("value")

    def body(self, request_id):
        import base64 as _b64
        r = self.call("Network.getResponseBody", {"requestId": request_id},
                      timeout=15)
        text = r.get("body") or ""
        if r.get("base64Encoded"):
            try:
                text = _b64.b64decode(text).decode("utf-8", "ignore")
            except (ValueError, TypeError):
                return ""
        return text

    def close(self):
        try:
            if self.sock:
                self.sock.close()
        except OSError:
            pass


def _dy_http_json(port, path, timeout=3):
    import urllib.request
    with urllib.request.urlopen("http://127.0.0.1:%d%s" % (port, path),
                                timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8", "ignore"))


def _dy_pick_url(aweme):
    """从 detail JSON 里挑【无水印 + 最高清晰度 + 含音频】的播放地址"""
    video = aweme.get("video") or {}
    best = ""
    best_px = -1
    for br in (video.get("bit_rate") or []):
        pa = (br.get("play_addr") or {})
        urls = [u for u in (pa.get("url_list") or []) if u]
        if not urls:
            continue
        px = int(br.get("width") or 0) * int(br.get("height") or 0)
        if px >= best_px:
            best_px = px
            best = urls[0]
    if not best:
        # 没有 bit_rate 列表就用主 play_addr (官方无水印源)
        for key in ("play_addr", "play_addr_h264"):
            urls = ((video.get(key) or {}).get("url_list") or [])
            urls = [u for u in urls if u]
            if urls:
                best = urls[0]
                break
    if not best:
        urls = ((video.get("play_addr_265") or {}).get("url_list") or [])
        best = urls[0] if urls else ""
    return best


# ============ 浏览器残留自愈 (2026-09-29 实测踩坑) ============
# 坑: 上次崩溃/被杀留下的无头浏览器不会自己退出, 一直占着 profile 目录;
#     这时新起的浏览器会"移交"给旧实例然后自己立刻退出(退出码 21), 调试端口
#     永远不就绪 -> 整条提取全挂(用户看到的就是"渲染失败/一条都不成功")。
#     而且它的 gpu/renderer/utility 子进程还各占几百 MB 内存, 越攒越多。
# 对策: ①起不来时, 按 profile 路径识别并清掉这些残留(绝不动用户自己的浏览器);
#       ②清理后仍起不来, 换一个全新独立 profile 兜底(彻底避开争用);
#       ③浏览器退出时杀【整棵进程树】, 从根上杜绝再残留。
_DY_STALE_DONE = [False]


class _DyLaunchError(RuntimeError):
    """浏览器起不来(残留占用/端口不就绪) —— 可以换 profile 重试"""


def _dy_fallback_profile():
    """兜底 profile: 每次进程一个全新独立目录, 不和任何残留实例争"""
    import tempfile
    d = os.path.join(tempfile.gettempdir(), "vmc_dy_run_%d" % os.getpid())
    try:
        os.makedirs(d, exist_ok=True)
    except OSError:
        pass
    return d


def _dy_kill_proc(proc):
    """杀整棵浏览器进程树: 只 terminate 主进程会残留 gpu/renderer 子进程"""
    try:
        subprocess.run(["taskkill", "/F", "/T", "/PID", str(proc.pid)],
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                       timeout=20)
    except Exception:                                        # noqa: BLE001
        pass


def _dy_kill_stale():
    """清掉残留的"我们的"无头浏览器(只认 profile 路径, 不动用户自己的浏览器)"""
    if _DY_STALE_DONE[0]:
        return
    _DY_STALE_DONE[0] = True
    for name in ("msedge.exe", "chrome.exe"):
        ps = ("Get-CimInstance Win32_Process -Filter \"Name='%s'\" | "
              "Where-Object {$_.CommandLine -like '*VideoMixCut*' -or "
              "$_.CommandLine -like '*vmc_dy_*'} | "
              "ForEach-Object { taskkill /F /T /PID $_.ProcessId }" % name)
        try:
            subprocess.run(["powershell", "-NoProfile", "-Command", ps],
                           stdout=subprocess.DEVNULL,
                           stderr=subprocess.DEVNULL, timeout=30)
        except Exception:                                    # noqa: BLE001
            pass


def _dy_launch_browser(exe, profile, port):
    """启动无头浏览器并等调试端口就绪; 起不来抛 _DyLaunchError 让上层换 profile"""
    cmd = [exe, "--headless=new", "--disable-gpu", "--no-first-run",
           "--no-default-browser-check", "--disable-sync", "--mute-audio",
           "--window-size=1920,1080",
           "--autoplay-policy=no-user-gesture-required",
           "--user-data-dir=" + profile,
           "--user-agent=" + GRAB_UA,
           "--remote-debugging-port=%d" % port,
           "--remote-allow-origins=*", "about:blank"]
    try:
        proc = subprocess.Popen(cmd, stdout=subprocess.DEVNULL,
                                stderr=subprocess.DEVNULL)
    except OSError as e:
        raise _DyLaunchError("启动浏览器失败: %s" % e)
    t0 = time.time()
    while time.time() - t0 < 20:
        if proc.poll() is not None:
            raise _DyLaunchError("浏览器启动即退出(码 %s, profile 被占用)"
                                 % proc.returncode)
        try:
            _dy_http_json(port, "/json/version")
            return proc
        except Exception:                                    # noqa: BLE001
            time.sleep(0.4)
    _dy_kill_proc(proc)
    raise _DyLaunchError("浏览器调试端口未就绪")


def _dy_cdp_extract(exe, profile, url, cookie=""):
    """用指定 profile 跑一次完整 CDP 提取(失败抛异常, 由上层决定换不换 profile)"""
    for lock in ("SingletonLock", "SingletonCookie", "SingletonSocket"):
        try:
            os.remove(os.path.join(profile, lock))
        except OSError:
            pass

    port = _dy_free_port()
    vid = ""
    try:
        vid = _douyin_id(url, cookie)
    except Exception:                                        # noqa: BLE001
        vid = ""            # 短链被拦拿不到ID -> 让浏览器自己跟跳转
    target = ("https://www.douyin.com/video/" + vid) if vid else url

    proc = _dy_launch_browser(exe, profile, port)
    cdp = None
    try:
        pages = [t for t in _dy_http_json(port, "/json")
                 if t.get("type") == "page"]
        if not pages:
            raise RuntimeError("浏览器没有可用页面")

        cdp = _DyCDP()
        cdp.connect(pages[0]["webSocketDebuggerUrl"])
        cdp.call("Network.enable")
        cdp.call("Page.enable")
        cdp.call("Runtime.enable")
        cdp.call("Emulation.setDeviceMetricsOverride",
                 {"width": 1920, "height": 1080, "deviceScaleFactor": 1,
                  "mobile": False})
        cdp.call("Page.navigate", {"url": target}, timeout=15)

        video_src = ""
        title = ""
        t0 = time.time()
        while time.time() - t0 < 28:
            cdp.drain(0.7)
            if cdp.details:
                break                       # detail 响应到手, 不用再等
            raw = cdp.js(
                "(function(){var v=document.querySelector('video');"
                "return JSON.stringify({t:document.title,"
                "s:(v&&(v.src||v.currentSrc))||\"\"});})()")
            if raw:
                try:
                    d = json.loads(raw)
                except ValueError:
                    d = {}
                title = d.get("t") or title
                video_src = d.get("s") or video_src

        # ---- 首选: 截获到的 detail 响应(官方无水印源, 含音频) ----
        aweme = None
        for rid in cdp.details:
            text = cdp.body(rid)
            if not text:
                continue
            try:
                data = json.loads(text)
            except ValueError:
                continue
            if data.get("aweme_detail"):
                aweme = data["aweme_detail"]
                break
        if aweme:
            vurl = _dy_pick_url(aweme)
            if vurl:
                a = aweme.get("author") or {}
                v = aweme.get("video") or {}
                covers = ((v.get("cover") or {}).get("url_list") or [])
                return {
                    "platform": "douyin",
                    "id": str(aweme.get("aweme_id") or vid or "unknown"),
                    "title": (aweme.get("desc") or title or "video")[:80],
                    "author": a.get("nickname") or "",
                    "duration": float((v.get("duration") or 0)) / 1000.0,
                    "cover": covers[0] if covers else "",
                    "video_url": vurl,
                    "images": [],
                    "extra": {"webpage": "https://www.douyin.com/video/"
                                         + str(aweme.get("aweme_id") or vid)},
                }

        # ---- 兜底: 页面 <video> 的地址(若含音频轨可直接用) ----
        if video_src.startswith("http"):
            if "mime_type=video_mp4" in video_src or "media-video" not in video_src:
                return {"platform": "douyin",
                        "id": vid or "unknown",
                        "title": (title or vid or "video")[:80],
                        "author": "", "duration": 0.0, "cover": "",
                        "video_url": video_src, "images": [],
                        "extra": {"webpage": "https://www.douyin.com/video/"
                                             + (vid or "")}}
            raise RuntimeError("只拿到分轨视频地址(缺音频) — 稍后单独重跑这条")

        hint = cdp.js("document.body?document.body.innerText.slice(0,150):''") or ""
        if "验证码" in hint or "captcha" in hint.lower():
            raise RuntimeError("抖音风控(验证码) — 稍后单独重跑这条")
        raise RuntimeError("页面里没拿到视频地址 (视频可能已删/仅登录可见)")
    finally:
        if cdp:
            cdp.close()
        _dy_kill_proc(proc)



def grab_douyin_headless(url, cookie=""):
    """无头浏览器 + CDP 解析抖音: 打开视频页, 截获页面自己发的 detail 响应,
    取官方无水印播放地址(含音频, 最高清晰度, 标题作者时长封面)。

    三级自愈(2026-09 实测总结):
      1) 先用持久 profile(带 cookie, 最快);
      2) 浏览器起不来 -> 多半是上次崩溃残留的无头浏览器占着 profile,
         按 profile 路径清掉它们, 再用同一个 profile 重试一次;
      3) 还是起不来 -> 换全新独立 profile, 彻底避开争用。
    """
    exe = next((p for p in _GRAB_BROWSERS if os.path.exists(p)), None)
    if not exe:
        raise RuntimeError("未找到 Edge/Chrome 浏览器")
    try:
        return _dy_cdp_extract(exe, _dy_profile_dir(), url, cookie)
    except _DyLaunchError:
        pass                       # 浏览器没起来 -> 走下面的自愈
    _dy_kill_stale()
    try:
        return _dy_cdp_extract(exe, _dy_profile_dir(), url, cookie)
    except _DyLaunchError:
        pass
    try:
        return _dy_cdp_extract(exe, _dy_fallback_profile(), url, cookie)
    except Exception as e:                                   # noqa: BLE001
        raise RuntimeError("%s" % e)


def grab_resolve(url, engine="auto", cookie=""):
    plat = grab_platform_of(url)
    if engine == "auto":
        engine = "douyin" if plat == "douyin" else "ytdlp"
    if engine == "douyin":
        err1 = None
        # 主通道: 无头浏览器 + CDP (2026-09 起唯一稳定可用的路子)
        try:
            print("  [抖音] 浏览器解析中 (约15秒)...")
            return grab_douyin_headless(url, cookie)
        except Exception as e:                               # noqa: BLE001
            err1 = e
            print("  [抖音] 浏览器解析失败(%s)"
                  % str(e).split("\n")[0][:70])
        # 兜底1: 老接口
        try:
            return grab_douyin_resolve(url, cookie)
        except Exception as e:                               # noqa: BLE001
            err1 = e
        # 兜底2: 通用引擎(带/不带浏览器Cookie)
        for bc in (True, False):
            try:
                return grab_ytdlp_resolve(url, cookie, browser_cookies=bc)
            except Exception as e:                           # noqa: BLE001
                err1 = e
        raise RuntimeError(
            "抖音解析失败: %s | 若是风控/验证码, 稍后单独重跑这一条"
            % str(err1).split("\n")[0][:90])
    return grab_ytdlp_resolve(url, cookie)


def _douyin_id(url, cookie=""):
    """从分享链接拿视频ID (短链302或直链)"""
    requests = _grab_requests()
    s = requests.Session()
    s.headers.update({"User-Agent": GRAB_UA_MOBILE})
    if cookie:
        s.headers["Cookie"] = cookie
    real = url
    try:
        r = s.get(url, allow_redirects=False, timeout=15)
        if 300 <= r.status_code < 400 and r.headers.get("Location"):
            real = r.headers["Location"]
    except OSError:
        pass
    m = (re.search(r"/video/(\d+)", real) or re.search(r"/note/(\d+)", real)
         or re.search(r"item_ids=(\d+)", real)
         or re.search(r"modal_id=(\d+)", real))
    if not m:
        if re.search(r"^https?://(?:www\.)?douyin\.com/?$",
                     real.strip().split("?")[0]):
            raise RuntimeError(
                "抖音风控(短链被拦, 跳到首页) — 访问太频繁, 等1-2分钟再试")
        raise RuntimeError("无法提取视频ID (链接可能已失效/不是视频)")
    return m.group(1)


def grab_ytdlp_download(url, out_path, cookie="", browser_cookies=False):
    import yt_dlp

    def _hook(d):
        if d["status"] == "downloading":
            pct = (d.get("_percent_str") or "").strip()
            sys.stdout.write("\r  下载 %s   " % pct)
            sys.stdout.flush()
        elif d["status"] == "finished":
            print("\r  下载完成, 合并封装中...        ")

    base = {"quiet": True, "no_warnings": True, "noplaylist": True,
            "outtmpl": out_path, "format": "bv*+ba/b",
            "merge_output_format": "mp4", "noprogress": True,
            "progress_hooks": [_hook], "overwrites": True, "retries": 3,
            "ffmpeg_location": BIN, "logger": _ytdlp_silent()}
    if cookie:
        base["http_headers"] = {"Cookie": cookie}

    def _run(opts):
        with yt_dlp.YoutubeDL(opts) as ydl:
            ydl.download([url])

    if browser_cookies:
        last = None
        for b in ("chrome", "edge", "firefox"):
            try:
                _run(dict(base, cookiesfrombrowser=(b,)))
                return out_path
            except Exception as e:
                last = e
        raise last
    _run(base)
    return out_path


def grab_download(item, out_dir, name_tpl="{index}_{title}", cookie=""):
    """下载单个视频 (含封面图), 返回文件路径"""
    requests = _grab_requests()
    os.makedirs(out_dir, exist_ok=True)
    title = re.sub(r'[\\/:*?"<>|\r\n]+', "_", item["title"]).strip(" ._")[:60]
    author = re.sub(r'[\\/:*?"<>|\r\n]+', "_",
                    item.get("author", "")).strip(" ._")[:30]
    date = time.strftime("%Y%m%d")
    ctx = dict(title=title or "video", author=author or "未知",
               id=item["id"], date=date, index="%02d" % (item.get("_i", 1)))
    fn = name_tpl.format(**ctx)
    if not fn.lower().endswith(".mp4"):
        fn += ".mp4"
    out_path = os.path.join(out_dir, fn)
    n = 2
    while os.path.exists(out_path):
        out_path = os.path.join(out_dir, "%s(%d).mp4" % (fn[:-4], n))
        n += 1
    if item["platform"] == "douyin" and item.get("video_url") \
            and "douyin.com" not in item["video_url"]:
        try:
            s = requests.Session()
            s.headers.update({"User-Agent": GRAB_UA_MOBILE,
                              "Referer": "https://www.douyin.com/"})
            with s.get(item["video_url"], stream=True, timeout=60) as r:
                r.raise_for_status()
                total = int(r.headers.get("content-length", 0))
                done = 0
                with open(out_path, "wb") as f:
                    for chunk in r.iter_content(256 * 1024):
                        f.write(chunk)
                        done += len(chunk)
                        if total:
                            sys.stdout.write("\r  下载 %d%%"
                                             % (done * 100 // total))
                            sys.stdout.flush()
            print()
        except Exception as e:
            print("  [直连下载] 失败(%s), 换通用引擎下载..." %
                  str(e).split("\n")[0][:70])
            try:
                grab_ytdlp_download(
                    item.get("extra", {}).get("webpage") or item["video_url"],
                    out_path, cookie)
            except Exception:
                grab_ytdlp_download(
                    item.get("extra", {}).get("webpage") or item["video_url"],
                    out_path, cookie, browser_cookies=True)
    else:
        try:
            grab_ytdlp_download(
                item.get("extra", {}).get("webpage") or item["video_url"],
                out_path, cookie)
        except Exception:
            grab_ytdlp_download(
                item.get("extra", {}).get("webpage") or item["video_url"],
                out_path, cookie, browser_cookies=True)
    # 封面图: 平台给了封面就用, 没给(抖音无头解析常没有)就从视频里抽一帧兜底
    cv = os.path.splitext(out_path)[0] + "_封面.jpg"
    got = False
    if item.get("cover"):
        try:
            s = requests.Session()
            s.headers["User-Agent"] = GRAB_UA
            with s.get(item["cover"], timeout=20) as r:
                if r.ok and r.content:
                    with open(cv, "wb") as f:
                        f.write(r.content)
                    got = os.path.getsize(cv) > 1024
        except OSError:
            pass
    if not got and os.path.exists(out_path):
        try:
            subprocess.run([FFMPEG, "-y", "-hide_banner", "-loglevel", "error",
                            "-ss", "1", "-i", out_path, "-frames:v", "1",
                            "-q:v", "3", cv], capture_output=True, timeout=90)
        except (OSError, subprocess.SubprocessError):
            pass
    return out_path


def grab_load_done():
    try:
        with open(GRAB_DL_JSON, encoding="utf-8") as f:
            return set(json.load(f))
    except (OSError, ValueError):
        return set()


def grab_save_done(d):
    with open(GRAB_DL_JSON, "w", encoding="utf-8") as f:
        json.dump(sorted(d), f, ensure_ascii=False, indent=1)


def grab_transcript(video_path):
    """文案提取: 抽帧 OCR 视频里的口播字幕, 返回纯文本"""
    r = subprocess.run([FFMPEG, "-hide_banner", "-i", video_path],
                       capture_output=True)
    m_ = re.search(r"Duration: (\d+):(\d+):(\d+(?:\.\d+)?)",
                   (r.stderr or b"").decode("utf-8", "ignore"))
    if not m_:
        return ""
    dur = int(m_.group(1)) * 3600 + int(m_.group(2)) * 60 + float(m_.group(3))
    lines = ocr_video_lines(video_path, dur, fps=1.5)
    text = "".join(t for _, t in lines)
    return text.replace(" / ", "")


def cmd_grab(args):
    """链接提取: 无水印视频下载 (+可选文案提取), 单个链接或 txt 批量"""
    need_ffmpeg()
    src = args.url_or_txt
    if os.path.exists(src) and src.lower().endswith((".txt", ".md", ".csv")):
        with open(src, encoding="utf-8", errors="ignore") as f:
            urls = grab_extract_urls(f.read())
        print("从文本提取到 %d 个链接" % len(urls))
    else:
        urls = grab_extract_urls(src)
    if not urls:
        print("没有找到可提取的链接")
        sys.exit(1)
    out_dir = args.out or os.path.join(ROOT, "output")
    txt_dir = os.path.join(out_dir, "文案")
    if args.text:
        os.makedirs(txt_dir, exist_ok=True)
    done = grab_load_done()
    cookie = args.cookie or ""
    ok = fail = skip = 0
    rows = []          # 下载清单 (批量时用得上: 哪条下了/哪条跳过了)
    for i, url in enumerate(urls):
        if url in done and not args.redo:
            print("[%d/%d] 已提取过, 跳过" % (i + 1, len(urls)))
            skip += 1
            rows.append({"状态": "已跳过(之前提取过)", "文件": "",
                         "标题": "", "作者": "", "平台": "", "时长秒": "",
                         "链接": url,
                         "时间": time.strftime("%Y-%m-%d %H:%M")})
            continue
        print("[%d/%d] 解析: %s" % (i + 1, len(urls), url))
        item = None
        for a in range(args.retry + 1):
            try:
                item = grab_resolve(url, args.engine, cookie)
                break
            except Exception as e:
                msg = str(e).split("\n")[0][:120]
                fk = any(k in msg for k in ("风控", "验证码", "频繁"))
                if a < args.retry:
                    wait = (10, 25, 50)[min(a, 2)] if fk else 2.0
                    print("  解析失败(%s)%s %ds 后重试..."
                          % (msg, " [风控退避]" if fk else "", wait))
                    time.sleep(wait)
                else:
                    print("  解析失败(%s)%s"
                          % (msg, " (疑似抖音风控, 稍后单独重跑这条)"
                             if fk else ""))
        if not item:
            fail += 1
            continue
        item["_i"] = i + 1
        try:
            path = grab_download(item, out_dir, args.name or "{index}_{title}",
                                 cookie)
            dur = probe_duration(path)
            print("  ✓ %s%s" % (os.path.basename(path),
                                 " (%.1fs)" % dur if dur else ""))
            done.add(url)
            grab_save_done(done)
            ok += 1
            rows.append({"状态": "成功",
                         "文件": os.path.basename(path),
                         "标题": item.get("title", ""),
                         "作者": item.get("author", ""),
                         "平台": item.get("platform", ""),
                         "时长秒": round(dur, 1) if dur else "",
                         "链接": url,
                         "时间": time.strftime("%Y-%m-%d %H:%M")})
            if args.text:
                print("  [文案] 识别口播字幕中 (约半分钟)...")
                text = grab_transcript(path)
                if text:
                    tf = os.path.join(
                        txt_dir,
                        os.path.splitext(os.path.basename(path))[0] + ".txt")
                    with open(tf, "w", encoding="utf-8") as f:
                        f.write(text)
                    print("  [文案] 已保存: %s" % tf)
                    print("  [文案] " + text[:60] + ("..." if len(text) > 60
                                                     else ""))
                else:
                    print("  [文案] 未识别到字幕 (视频可能无硬字幕)")
        except Exception as e:
            print("  ✗ 下载失败: %s" % e)
            fail += 1
            rows.append({"状态": "失败", "文件": "",
                         "标题": item.get("title", "") if item else "",
                         "作者": "", "平台": "", "时长秒": "",
                         "链接": url,
                         "时间": time.strftime("%Y-%m-%d %H:%M")})
        time.sleep(random.uniform(2.0, 4.5))   # 降频, 降低抖音风控概率
    # 下载清单: 批量提取完一眼看清哪条成了哪条跳过了 (Excel 直接打开)
    if rows:
        try:
            csv_path = os.path.join(out_dir, "下载清单.csv")
            with open(csv_path, "w", encoding="utf-8-sig", newline="") as f:
                w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
                w.writeheader()
                w.writerows(rows)
            print("下载清单: %s" % csv_path)
        except OSError as e:
            print("  [提示] 清单写入失败: %s" % e)
    print("\n提取完成: 成功 %d, 跳过 %d, 失败 %d -> %s"
          % (ok, skip, fail, out_dir))
    if args.text:
        print("文案保存在: %s (可直接复制去改写/当混剪文案参考)" % txt_dir)


def probe_duration(path):
    try:
        r = subprocess.run(
            [FFPROBE, "-v", "error", "-show_entries", "format=duration",
             "-of", "json", path], capture_output=True)
        return float(json.loads(r.stdout.decode("utf-8"))["format"]["duration"])
    except (ValueError, KeyError, OSError):
        return 0.0


def plan_to_segs(plan, dur_map):
    """把 pick_plan 的方案转成分段表 [(文件名, t0, t1, 标签)], 与 segments.json 同格式"""
    out = []
    for p in plan:
        t1 = min(p["t1"] + 0.3, dur_map.get(p["video"], p["t1"]))  # 0.3s 尾部缓冲
        out.append((f"{p['video']}.mp4", round(p["t0"], 2), round(t1, 2),
                    f"{p['slot']}-{p['text']}"))
    return out


def cmd_plan(args):
    pool, dur_map = load_subtitle_pool()
    if not pool:
        print("data/subtitles.json 不存在或还没有字幕数据, 先运行 subs 命令生成模板并填入字幕")
        sys.exit(1)
    plan = pick_plan(pool)   # 传入候选段列表, 内部自动拆成三库匹配
    if not plan:
        print("未能拼装出方案, 请检查字幕角色分类规则 RULES 是否匹配你的品类话术")
        sys.exit(1)
    print(f"候选段 {len(pool)} 条 -> 方案 {len(plan)} 段\n")
    total = 0
    for i, p in enumerate(plan):
        d = p["t1"] - p["t0"]
        total += d
        sec = ("开头" if p["slot"] in ("痛点", "引入")
               else ("结尾" if p["slot"] == "CTA" else "卖点"))
        print(f"seg{i} [{sec}|{p['slot']}] {p['video']} {p['t0']:.1f}-{p['t1']:.1f}s ({d:.1f}s)")
        print(f"      文案: {p['text']}")
    print(f"\n总时长 ≈ {total:.1f}s, 使用视频数 {len({p['video'] for p in plan})}")
    out = []
    for i, p in enumerate(plan):
        t1 = min(p["t1"] + 0.3, dur_map.get(p["video"], p["t1"]))  # 0.3s 尾部缓冲, 话音自然收尾
        out.append((f"{p['video']}.mp4", round(p["t0"], 2), round(t1, 2),
                    f"{p['slot']}-{p['text']}"))
    with open(SEG_JSON, "w", encoding="utf-8") as fp:
        json.dump(out, fp, ensure_ascii=False, indent=2)
    print("已写入 data/segments.json")


# ================= 子命令: audio =================
def cmd_audio(args):
    need_ffmpeg()
    ensure_dirs()
    segs = load_segments(args.src)
    aud = os.path.join(BUILD, "seg_audio")
    os.makedirs(aud, exist_ok=True)
    for i, (src, t0, t1, tag) in enumerate(segs):
        wav = os.path.join(aud, f"seg{i}.wav")
        sh([FFMPEG, "-y", "-ss", str(t0), "-to", str(t1), "-i", os.path.join(args.src, src),
            "-vn", "-ar", "44100", "-ac", "2", wav])
        print(f"seg{i} {src} {t0}-{t1}s audio ok")
    for k in range(len(segs), len(segs) + 20):   # 旧分段改名备份
        old = os.path.join(aud, f"seg{k}.wav")
        if os.path.exists(old):
            os.replace(old, old + ".bak")
    print("audio extract done")


# ================= 子命令: sep (demucs 人声分离) =================
def cmd_sep(args):
    ensure_dirs()
    aud = os.path.join(BUILD, "seg_audio")
    voc = os.path.join(BUILD, "seg_vocals")
    os.makedirs(voc, exist_ok=True)
    wavs = sorted(glob.glob(os.path.join(aud, "seg*.wav")))
    wavs = [w for w in wavs if not w.endswith(".bak")]
    if not wavs:
        print("没有分段音频, 先运行 audio 命令")
        sys.exit(1)
    model_out = os.path.join(voc, "htdemucs")
    if os.path.exists(model_out):
        os.rename(model_out, model_out + f".bak{int(time.time())}")
    print(f"demucs 人声分离中 ({len(wavs)} 段, CPU 模式)...")
    r = sh([sys.executable, "-m", "demucs", "--two-stems=vocals", "-n", "htdemucs",
            "--out", voc, "-d", "cpu"] + wavs, check=False, tail=1500)
    ok = [w for w in wavs
          if os.path.exists(os.path.join(voc, "htdemucs",
                                         os.path.splitext(os.path.basename(w))[0], "vocals.wav"))]
    print(f"分离完成 {len(ok)}/{len(wavs)}")
    if len(ok) < len(wavs):
        sys.exit(2)


# ================= 子命令: mix =================
def resolve_bgm(sel):
    if sel == "none":
        return None, "none"
    tracks = sorted(f for f in os.listdir(LIB)
                    if f.endswith(".mp3") or f.endswith(".wav")) if os.path.isdir(LIB) else []
    if sel in (None, "synth"):
        ensure_bgm_library()
        default = os.path.join(LIB, "upbeat.wav")
        if os.path.exists(default):
            return default, "upbeat"
        if not os.path.exists(BGM_SYNTH):
            synth_bgm()
        return BGM_SYNTH, "synth-bgm"
    if sel == "list":
        print("可用曲库 (内置多风格免版权 + 你放入的 mp3/wav):")
        for t in tracks:
            print("  ", t.rsplit(".", 1)[0])
        print("  (synth = 程序合成免版权BGM; 也可传任意音频路径)")
        sys.exit(0)
    if sel == "random":
        ensure_bgm_library()
        if tracks:
            pick = random.choice(tracks)
            return os.path.join(LIB, pick), pick.rsplit(".", 1)[0]
        if not os.path.exists(BGM_SYNTH):
            synth_bgm()
        return BGM_SYNTH, "synth-bgm"
    if sel.endswith(".mp3") and os.path.exists(sel):
        return sel, os.path.splitext(os.path.basename(sel))[0]
    cand = os.path.join(LIB, sel if sel.endswith(".mp3") else sel + ".mp3")
    if os.path.exists(cand):
        return cand, os.path.basename(cand)[:-4]
    hits = [t for t in tracks if sel.replace("track_", "") in t.replace("track_", "")]
    if len(hits) == 1:
        return os.path.join(LIB, hits[0]), hits[0][:-4]
    if os.path.exists(sel):
        return sel, os.path.splitext(os.path.basename(sel))[0]
    print(f"BGM 未找到: {sel} (曲库现有: {', '.join(t[:-4] for t in tracks)})")
    sys.exit(1)


def synth_bgm():
    """合成免版权 BGM (C大调 100BPM 琶音+pad), 纯程序生成零版权风险"""
    sr, bpm = 44100, 100
    beat = 60.0 / bpm
    bar = beat * 4
    dur = 40.0
    chords = [[261.63, 329.63, 392.00], [196.00, 246.94, 392.00],
              [220.00, 261.63, 329.63], [174.61, 220.00, 349.23]]
    arp = [0, 1, 2, 1]
    n_total = int(sr * dur)
    buf = [0.0] * n_total

    def env_pluck(t, d=0.5):
        return math.exp(-4.5 * t / d) * (1 - math.exp(-200 * t)) if 0 <= t <= d else 0.0

    def tone(freq, t):
        return (math.sin(2 * math.pi * freq * t) * 0.62
                + math.sin(2 * math.pi * freq * 2 * t) * 0.22
                + math.sin(2 * math.pi * freq * 3 * t) * 0.08)

    random.seed(7)
    step = beat / 2
    for pass_i in range(2):           # 0=琶音 1=pad
        t_cur, bar_i = 0.0, 0
        while t_cur < dur:
            chord = chords[bar_i % 4]
            if pass_i == 0:
                for k in range(8):
                    tt = t_cur + k * step
                    if tt >= dur:
                        break
                    f = chord[arp[k % 4]] * (2 if (k % 8) in (3, 7) else 1)
                    i0 = int(tt * sr)
                    for j in range(int(step * sr * 1.8)):
                        i = i0 + j
                        if i >= n_total:
                            break
                        buf[i] += tone(f, j / sr) * env_pluck(j / sr) * 0.16
            else:
                i0 = int(t_cur * sr)
                for j in range(int(bar * sr)):
                    i = i0 + j
                    if i >= n_total:
                        break
                    t = j / sr
                    a = min(t / 0.6, 1.0) * min((bar - t) / 0.6, 1.0)
                    buf[i] += sum(math.sin(2 * math.pi * f * t / 2) for f in chord) * a * 0.045
            t_cur += bar
            bar_i += 1
    frames = bytearray()
    delay = int(0.012 * sr)
    for i in range(n_total):
        l = max(-1.0, min(1.0, buf[i] * 1.1))
        r_ = max(-1.0, min(1.0, (buf[i - delay] if i >= delay else buf[i]) * 1.1))
        frames += struct.pack("<hh", int(l * 32767 * 0.85), int(r_ * 32767 * 0.85))
    with wave.open(BGM_SYNTH, "wb") as w:
        w.setnchannels(2)
        w.setsampwidth(2)
        w.setframerate(sr)
        w.writeframes(bytes(frames))
    print("合成 BGM 完成:", BGM_SYNTH)


# ---- 多风格免版权 BGM (程序合成, 零版权风险; 批量随机轮换解决"单调") ----
BGM_MOODS = [
    # name, bpm, 根音频率, 音阶(半音偏移)
    ("upbeat", 128, 261.63, [0, 4, 7, 12, 7, 4]),    # 欢快动感
    ("relax",   82, 220.00, [0, 3, 7, 10, 7, 3]),    # 舒缓放松
    ("tech",   112, 293.66, [0, 2, 5, 7, 12, 7]),    # 科技律动
    ("cute",   120, 329.63, [0, 4, 7, 9, 7, 4]),     # 可爱轻快
    ("inspire",100, 246.94, [0, 4, 7, 11, 7, 4]),    # 励志昂扬
    ("energy", 140, 196.00, [0, 5, 7, 12, 7, 5]),    # 燃向高能
]


def synth_mood_wav(name, bpm, root, scale, dur=32.0):
    """生成一段可循环的免版权 BGM (wav) 存入 bgm_library/<name>.wav"""
    sr = 44100
    beat = 60.0 / bpm
    bar = beat * 4
    n_total = int(sr * dur)
    buf = [0.0] * n_total
    rng = random.Random((hash(name) & 0xFFFFFFFF) ^ bpm)
    delay = int(0.012 * sr)

    def env(t, d=0.5):
        return math.exp(-4.5 * t / d) * (1 - math.exp(-200 * t)) if 0 <= t <= d else 0.0

    def tone(f, t):
        return (math.sin(2 * math.pi * f * t) * 0.6
                + math.sin(2 * math.pi * f * 2 * t) * 0.2
                + math.sin(2 * math.pi * f * 3 * t) * 0.08)

    ti = 0.0
    while ti < dur:
        cr = root * (2 ** (rng.choice([0, 0, 0, 5, -5]) / 12.0))
        step = beat / 2
        for k in range(8):                 # 琶音
            tt = ti + k * step
            if tt >= dur:
                break
            deg = scale[k % len(scale)]
            f = cr * (2 ** (deg / 12.0))
            i0 = int(tt * sr)
            for j in range(int(step * sr * 1.6)):
                i = i0 + j
                if i >= n_total:
                    break
                buf[i] += tone(f, j / sr) * env(j / sr) * 0.14
        i0 = int(ti * sr)                  # 衬底 pad
        for j in range(int(bar * sr)):
            i = i0 + j
            if i >= n_total:
                break
            t = j / sr
            a = min(t / 0.6, 1.0) * min((bar - t) / 0.6, 1.0)
            buf[i] += sum(math.sin(2 * math.pi * cr * (2 ** (d / 12.0)) * t / 2)
                         for d in scale[:3]) * a * 0.04
        ti += bar
    frames = bytearray()
    for i in range(n_total):
        l = max(-1.0, min(1.0, buf[i] * 1.1))
        r_ = max(-1.0, min(1.0, (buf[i - delay] if i >= delay else buf[i]) * 1.1))
        frames += struct.pack("<hh", int(l * 32767 * 0.85), int(r_ * 32767 * 0.85))
    out = os.path.join(LIB, name + ".wav")
    with wave.open(out, "wb") as w:
        w.setnchannels(2)
        w.setsampwidth(2)
        w.setframerate(sr)
        w.writeframes(bytes(frames))
    return out


def ensure_bgm_library():
    """保证内置曲库有多风格 BGM; 缺失时程序合成 (零版权, 一次生成永久可用)"""
    try:
        os.makedirs(LIB, exist_ok=True)
    except OSError:
        pass
    for name, bpm, root, scale in BGM_MOODS:
        p = os.path.join(LIB, name + ".wav")
        if not os.path.exists(p):
            try:
                synth_mood_wav(name, bpm, root, scale)
                print("  已合成 BGM:", name)
            except Exception as e:
                print("  BGM 合成失败 %s: %s" % (name, e))


# ---- 随机可爱卡通贴纸 (程序绘制透明 PNG, 零版权) ----
def _cute_sun(d, W=170):
    cx = cy = W // 2
    R = 46
    for a in range(0, 360, 30):
        ar = math.radians(a)
        d.line([cx + math.cos(ar) * R, cy + math.sin(ar) * R,
                cx + math.cos(ar) * (R + 24), cy + math.sin(ar) * (R + 24)],
               fill=(255, 193, 71, 255), width=9, joint="curve")
    d.ellipse([cx - R, cy - R, cx + R, cy + R], fill=(255, 202, 92, 255),
              outline=(240, 160, 40, 255), width=4)
    d.ellipse([cx - 18, cy - 10, cx - 7, cy + 1], fill=(90, 60, 20, 255))
    d.ellipse([cx + 7, cy - 10, cx + 18, cy + 1], fill=(90, 60, 20, 255))
    d.arc([cx - 18, cy + 6, cx + 18, cy + 26], 20, 160, fill=(90, 60, 20, 255), width=4)


def _cute_star(d, W=170):
    cx = cy = W // 2
    R = 58
    pts = []
    for i in range(10):
        r = R if i % 2 == 0 else R * 0.46
        a = math.radians(-90 + i * 36)
        pts.append((cx + math.cos(a) * r, cy + math.sin(a) * r))
    d.polygon(pts, fill=(255, 214, 90, 255), outline=(230, 160, 40, 255))
    d.ellipse([cx - 15, cy - 7, cx - 6, cy + 2], fill=(120, 80, 20, 255))
    d.ellipse([cx + 6, cy - 7, cx + 15, cy + 2], fill=(120, 80, 20, 255))
    d.arc([cx - 12, cy + 6, cx + 12, cy + 22], 20, 160, fill=(120, 80, 20, 255), width=3)


def _cute_heart(d, W=170):
    cx, cy = W // 2, W // 2 + 6
    d.polygon([(cx, cy + 44), (cx - 56, cy - 22), (cx - 34, cy - 50),
               (cx, cy - 26), (cx + 34, cy - 50), (cx + 56, cy - 22)],
              fill=(255, 99, 132, 255))
    d.ellipse([cx - 46, cy - 46, cx - 6, cy - 6], fill=(255, 99, 132, 255))
    d.ellipse([cx + 6, cy - 46, cx + 46, cy - 6], fill=(255, 99, 132, 255))
    d.ellipse([cx - 40, cy - 40, cx - 12, cy - 12], fill=(255, 150, 175, 200))


def _cute_sparkle(d, W=170):
    cx = cy = W // 2
    R = 60
    pts = []
    for i in range(8):
        r = R if i % 2 == 0 else R * 0.34
        a = math.radians(-90 + i * 45)
        pts.append((cx + math.cos(a) * r, cy + math.sin(a) * r))
    d.polygon(pts, fill=(120, 210, 255, 255), outline=(80, 170, 230, 255))
    d.ellipse([cx - 10, cy - 10, cx + 10, cy + 10], fill=(255, 255, 255, 220))


def _cute_gift(d, W=170):
    cx, cy = W // 2, W // 2
    d.rectangle([cx - 46, cy - 10, cx + 46, cy + 44], fill=(86, 105, 255, 255))
    d.rectangle([cx - 46, cy - 34, cx + 46, cy - 6], fill=(86, 105, 255, 255))
    d.rectangle([cx - 8, cy - 34, cx + 8, cy + 44], fill=(255, 214, 90, 255))
    d.ellipse([cx - 18, cy - 44, cx + 18, cy - 12], fill=(255, 214, 90, 255))


def _cute_fire(d, W=170):
    cx, cy = W // 2, W // 2
    d.polygon([(cx, cy - 52), (cx - 34, cy + 30), (cx - 14, cy + 12),
               (cx, cy + 44), (cx + 14, cy + 12), (cx + 34, cy + 30)],
              fill=(255, 140, 50, 255))
    d.polygon([(cx, cy - 26), (cx - 18, cy + 30), (cx, cy + 40), (cx + 18, cy + 30)],
              fill=(255, 210, 90, 255))


CUTE_STICKER_DRAW = (("太阳", _cute_sun), ("星星", _cute_star), ("爱心", _cute_heart),
                     ("闪光", _cute_sparkle), ("礼物", _cute_gift), ("火苗", _cute_fire))


def ensure_cute_stickers():
    """生成(缺失时)并返回随机可爱卡通贴纸 PNG 路径列表"""
    from PIL import Image, ImageDraw
    os.makedirs(STICKER_DIR, exist_ok=True)
    out = []
    for name, fn in CUTE_STICKER_DRAW:
        p = os.path.join(STICKER_DIR, "cute_%s.png" % name)
        if not os.path.exists(p):
            img = Image.new("RGBA", (170, 170), (0, 0, 0, 0))
            fn(ImageDraw.Draw(img))
            img.save(p)
        out.append(p)
    return out


def make_badge_sticker(text, color):
    """生成一张带文字的彩色徽章贴纸 PNG (transparent)"""
    from PIL import Image, ImageDraw, ImageFont
    font = find_font() or "arial.ttf"
    w, h = 340, 104
    img = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    d.rounded_rectangle((6, 14, w - 2, h - 2), radius=28, fill=(0, 0, 0, 60))
    d.rounded_rectangle((2, 4, w - 8, h - 10), radius=28, fill=color + (232,))
    d.rounded_rectangle((2, 4, w - 8, h - 10), radius=28,
                        outline=(255, 255, 255, 215), width=4)
    f1 = ImageFont.truetype(font, 50)
    d.text(((w - 6) // 2, (h - 12) // 2), text, font=f1,
           fill=(255, 255, 255, 255), anchor="mm")
    return img


# AI 推荐贴纸: 从固定卖点标签里让 LLM 按文案挑一条最贴切的
STICKER_TEXTS = ["限时特惠", "工厂直发", "正品保障", "爆款热卖", "亏本冲量",
                 "好物推荐", "新品上市", "假一赔十", "包邮到家", "秒杀中"]


def ai_pick_sticker_text(script_text, llm_cfg):
    if not (llm_cfg and llm_cfg.get("api_key")):
        return random.choice(STICKER_TEXTS)
    prompt = ("你是带货短视频的贴纸文案师。下面是一条视频的口播文案, "
              "请提炼一个最贴切的【4-6字卖点/行动号召】标签, 必须从给定列表里选一条, 不要自创:\n"
              "列表: " + " / ".join(STICKER_TEXTS) +
              "\n文案: " + (script_text or "")[:400] +
              "\n只输出那一条标签, 不要任何解释。")
    try:
        t = llm_chat(llm_cfg, [{"role": "user", "content": prompt}],
                     timeout=60).strip()
        if t in STICKER_TEXTS:
            return t
        for x in STICKER_TEXTS:
            if x in t:
                return x
    except Exception:
        pass
    return random.choice(STICKER_TEXTS)


def fetch_online_assets(sources_json=None):
    """联网拉取可商用素材(目前主要是 BGM)到本地曲库; 失败项自动跳过, 不阻塞。
    sources_json: 形如 {"bgm":[url...], "stickers":[url...]} 的清单文件。
    仅下载到 bgm_library / stickers, 供后续随机选用。"""
    import json as _json
    import urllib.request
    p = sources_json or os.path.join(ROOT, "assets_sources.json")
    if not os.path.exists(p):
        print("未找到素材源清单 assets_sources.json, 跳过联网获取")
        return 0
    try:
        spec = _json.load(open(p, encoding="utf-8"))
    except Exception as e:
        print("素材源清单解析失败: %s" % e)
        return 0
    got = 0
    try:
        os.makedirs(LIB, exist_ok=True)
        os.makedirs(STICKER_DIR, exist_ok=True)
    except OSError:
        pass
    for url in spec.get("bgm", []):
        try:
            fn = url.rsplit("/", 1)[-1].split("?")[0] or ("online_%d.mp3" % got)
            if not fn.lower().endswith((".mp3", ".wav", ".m4a")):
                fn += ".mp3"
            dst = os.path.join(LIB, fn)
            if os.path.exists(dst):
                got += 1
                continue
            print("  下载 BGM:", fn)
            urllib.request.urlretrieve(url, dst)
            got += 1
        except Exception as e:
            print("  下载失败(已跳过): %s -> %s" % (url, e))
    for url in spec.get("stickers", []):
        try:
            fn = url.rsplit("/", 1)[-1].split("?")[0] or ("stk_%d.png" % got)
            if not fn.lower().endswith((".png", ".webp", ".jpg")):
                fn += ".png"
            dst = os.path.join(STICKER_DIR, fn)
            if os.path.exists(dst):
                got += 1
                continue
            print("  下载贴纸:", fn)
            urllib.request.urlretrieve(url, dst)
            got += 1
        except Exception as e:
            print("  下载失败(已跳过): %s -> %s" % (url, e))
    print("联网获取完成: 累计 %d 个素材已就绪" % got)
    return got


def make_watermark(text):
    from PIL import Image, ImageDraw, ImageFont
    font_path = find_font() or "arial.ttf"
    f = ImageFont.truetype(font_path, 44)
    box_w = int(f.getlength(text)) + 64
    img = Image.new("RGBA", (box_w, 92), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    d.rounded_rectangle((0, 0, box_w - 1, 91), radius=45, fill=(0, 0, 0, 90))
    d.text((box_w // 2, 44), text, font=f, fill=(255, 255, 255, 165), anchor="mm")
    p = os.path.join(STICKER_DIR, f"wm_{text}.png")
    img.save(p)
    return p


# ================= 文案自检 =================
INCOMPLETE_END = ("的", "呢", "这", "然后", "而且", "还有", "就是",
                  "非常", "特别", "可以", "会", "在", "和", "跟", "与", "把", "对", "用",
                  "但是", "并且", "最主要", "还能", "还可以", "让", "是")


def media_check(video_path):
    """成片画面/音频 BUG 自检: 黑屏/卡帧/长静音/爆音/音量过低, 返回问题数"""
    if not os.path.exists(video_path):
        print("(未找到成片文件, 跳过画面/音频自检)")
        return 0
    print(f"\n---- 画面/音频自检: {os.path.basename(video_path)} ----")
    issues = 0
    # 画面: 黑屏 + 卡帧 (freezedetect 对静态镜头可能误报, 仅提示)
    r = subprocess.run(
        [FFMPEG, "-i", video_path, "-vf",
         "blackdetect=d=0.5:pix_th=0.10,freezedetect=d=2.0", "-an",
         "-f", "null", "-"], capture_output=True)
    err = (r.stderr or b"").decode("utf-8", "ignore")
    for line in err.splitlines():
        m_ = re.search(r"black_start:([\d.]+) black_end:([\d.]+)", line)
        if m_ and float(m_.group(2)) - float(m_.group(1)) >= 0.4:
            print(f"[黑屏] {float(m_.group(1)):.1f}-{float(m_.group(2)):.1f}s, "
                  f"建议人工确认")
            issues += 1
    n_freeze = err.count("freeze_start")
    if n_freeze:
        print(f"[卡帧?] 检测到 {n_freeze} 处画面静止 (固定镜头属正常, 建议人工确认)")
        issues += n_freeze
    # 音频: 长静音 (人声丢失) + 音量异常
    r = subprocess.run(
        [FFMPEG, "-i", video_path,
         "-af", "silencedetect=noise=-35dB:d=1.5,volumedetect",
         "-vn", "-f", "null", "-"], capture_output=True)
    err = (r.stderr or b"").decode("utf-8", "ignore")
    sil_start = None
    for line in err.splitlines():
        m_ = re.search(r"silence_start: ([\d.]+)", line)
        if m_:
            sil_start = float(m_.group(1))
        m_ = re.search(r"silence_duration: ([\d.]+)", line)
        if m_ and sil_start is not None:
            d = float(m_.group(1))
            if d >= 1.5:
                print(f"[长静音] {sil_start:.1f}s 起持续 {d:.1f}s "
                      f"(人声可能丢失/衔接空白)")
                issues += 1
            sil_start = None
    mv = re.search(r"mean_volume: (-?[\d.]+) dB", err)
    xv = re.search(r"max_volume: (-?[\d.]+) dB", err)
    if mv and float(mv.group(1)) < -28:
        print(f"[音量过低] 平均 {mv.group(1)} dB (正常约 -18 ~ -24), 人声可能太小")
        issues += 1
    if xv and float(xv.group(1)) > -0.3:
        print(f"[疑似爆音] 峰值 {xv.group(1)} dB, 建议降低 BGM/人声增益")
        issues += 1
    if issues == 0:
        tail = (f" (平均 {mv.group(1)} dB, 峰值 {xv.group(1)} dB)"
                if mv and xv else "")
        print(f"画面/音频正常{tail}")
    return issues


def make_cover(video_path, hook_text, out_jpg, sticker_png=None):
    """自动封面: 抽成片25%处画面 + 顶部钩子大字(描边) + 可选品牌贴纸"""
    r = subprocess.run([FFPROBE, "-v", "error", "-show_entries",
                        "format=duration", "-of", "csv=p=0", video_path],
                       capture_output=True)
    try:
        dur = float((r.stdout or b"").decode().strip())
    except ValueError:
        dur = 0.0
    tmp = video_path + ".cover_tmp.jpg"
    sh([FFMPEG, "-y", "-ss", f"{max(0.5, dur * 0.25):.2f}", "-i", video_path,
        "-frames:v", "1", "-q:v", "2", tmp], check=False)
    if not os.path.exists(tmp):
        return False
    from PIL import Image, ImageDraw, ImageFont
    img = Image.open(tmp).convert("RGB")
    w, h = img.size
    d = ImageDraw.Draw(img, "RGBA")
    text = (hook_text or "").replace(" / ", " ").strip()[:14]
    if text:
        f_big = ImageFont.truetype(find_font(), 68)
        lines = [text[i:i + 7] for i in range(0, len(text), 7)] or [""]
        y = int(h * 0.10)
        for line in lines:
            d.text((w // 2, y), line, font=f_big, fill=(255, 255, 255, 255),
                   stroke_width=7, stroke_fill=(0, 0, 0, 220), anchor="mm")
            y += 88
    if sticker_png and os.path.exists(sticker_png):
        st = Image.open(sticker_png).convert("RGBA")
        img.paste(st, (w - st.size[0] - 30, h - st.size[1] - 360), st)
    img.save(out_jpg, quality=90)
    try:
        os.remove(tmp)
    except OSError:
        pass
    return True


def ocr_readback_check(video_path, plan_segs):
    """出片后抽帧 OCR 回读成片字幕, 与方案文案比对。
    能发现"源视频字幕和人声错位"这类只看文案表发现不了的问题。"""
    r = subprocess.run([FFMPEG, "-hide_banner", "-i", video_path],
                       capture_output=True)
    m_ = re.search(r"Duration: (\d+):(\d+):(\d+(?:\.\d+)?)",
                   (r.stderr or b"").decode("utf-8", "ignore"))
    if not m_:
        print("[回读比对] 无法读取成片时长, 跳过")
        return
    dur = int(m_.group(1)) * 3600 + int(m_.group(2)) * 60 + float(m_.group(3))
    print("[回读比对] 抽帧识别成片字幕中 (约半分钟)...")
    lines = ocr_video_lines(video_path, dur, fps=1.5)
    if not lines:
        print("[回读比对] 成片未识别到字幕, 跳过比对 (源视频可能无硬字幕)")
        return
    joined = "".join(t for _, t in lines).replace(" ", "")
    miss = []
    for i, (src, t0, t1, tag) in enumerate(plan_segs):
        text = tag.split("-", 1)[1] if "-" in tag else tag
        first = text.split(" / ")[0]
        key = re.sub(r"[\s,。!?,?]", "", first)[:8]
        if len(key) < 4:
            continue
        best = 0.0
        for j in range(max(1, len(joined) - len(key) + 1)):
            rr = difflib.SequenceMatcher(
                None, key, joined[j:j + len(key)]).ratio()
            if rr > best:
                best = rr
        if best < 0.6:
            miss.append((i + 1, first[:16]))
    if miss:
        print(f"[回读比对] {len(miss)} 段文案未在成片字幕中找到: "
              + "; ".join(f"段{no}「{t}」" for no, t in miss[:4])
              + " (源字幕与人声可能错位, 建议人工确认)")
    else:
        print("[回读比对] 通过: 成片字幕与方案文案一致")


def load_llm_cfg():
    """config.json 里的 llm 段: {api_base, api_key, model}"""
    try:
        with open(os.path.join(ROOT, "config.json"), encoding="utf-8") as f:
            return (json.load(f).get("llm") or {})
    except (OSError, ValueError):
        return {}


def llm_chat(llm_cfg, messages, timeout=60):
    """OpenAI 兼容 /chat/completions (纯标准库)"""
    import urllib.request
    base = (llm_cfg.get("api_base") or "").rstrip("/")
    if not base.lower().startswith(("http://", "https://")):
        raise ValueError("接口地址要填网址(如 https://api.deepseek.com/v1), "
                         "你填的是「%s」" % base)
    req = urllib.request.Request(
        base + "/chat/completions",
        data=json.dumps({"model": llm_cfg.get("model"),
                         "messages": messages,
                         "temperature": 0.3}).encode("utf-8"),
        headers={"Content-Type": "application/json",
                 "Authorization": "Bearer " + llm_cfg.get("api_key", "")})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        data = json.loads(r.read().decode("utf-8"))
    return data["choices"][0]["message"]["content"]


def _json_loose(txt):
    """容错解析大模型返回的 JSON (绝不抛异常, 最坏返回 {})。

    glm-4-flash 常把裸换行/制表符塞进 JSON 字符串里, 严格模式 json.loads
    会直接报 'Expecting , delimiter: ...' -> 整批审片/选段失败。
    处理: 1) 剥 ```json 围栏 + 截最外层 {}; 2) strict=False 允许控制字符;
    3) 仍失败按字段正则兜底抠 score/issues/bad_segments/plans/items。
    """
    if not txt:
        return {}
    t = re.sub(r"^```(?:json)?|```$", "", str(txt).strip(),
               flags=re.M).strip()
    m = re.search(r"\{.*\}", t, re.S)
    body = m.group(0) if m else t
    try:
        data = json.loads(body, strict=False)
        if isinstance(data, dict):
            return data
    except ValueError:
        pass
    out = {}
    ms = re.search(r'"score"\s*:\s*(-?\d+(?:\.\d+)?)', body)
    if ms:
        out["score"] = float(ms.group(1))
    mi = re.search(r'"issues"\s*:\s*\[(.*?)\]', body, re.S)
    if mi:
        out["issues"] = [json.loads(x) for x in
                         re.findall(r'"(?:[^"\\]|\\.)*"', mi.group(1))]
    mbs = re.search(r'"bad_segments"\s*:\s*\[(.*?)\]\s*[,}]', body, re.S) \
        or re.search(r'"bad_segments"\s*:\s*\[(.*)', body, re.S)
    if mbs:
        objs = []
        for o in re.findall(r"\{[^{}]*\}", mbs.group(1), re.S):
            try:
                objs.append(json.loads(o, strict=False))
            except ValueError:
                mn = re.search(r'"no"\s*:\s*"?(\d+)', o)
                mq = re.search(r'"quote"\s*:\s*"([^"]*)"', o)
                if mn:
                    objs.append({"no": int(mn.group(1)),
                                 "quote": mq.group(1) if mq else ""})
        if not objs:
            objs = [{"no": int(x), "quote": ""}
                    for x in re.findall(r"\d+", mbs.group(1))]
        out["bad_segments"] = objs
    md = re.search(r'"dims"\s*:\s*(\{[^{}]*\})', body)
    if md:
        try:
            out["dims"] = json.loads(md.group(1), strict=False)
        except ValueError:
            pass
    for key in ("plans", "items"):
        mk = re.search(r'"%s"\s*:\s*(\[.*\])' % key, body, re.S)
        if mk:
            try:
                out[key] = json.loads(mk.group(1), strict=False)
            except ValueError:
                pass
    return out


# ===== 短视频"合理程度 & 文案逻辑"多维度评估体系 =====
# 综合业界框架提炼(用于 AI 审片/选段/终审的多维打分与优化):
#  - DR公式 Hook→Problem→Solution→Value→SocialProof→CTA
#  - AIDA / PAS(Problem-Agitate-Solution) / BAB / FBP(Feature-Benefit-Proof)
#  - 蝉妈妈5步模型: 认知冲突→身份锚定→痛点三连问→证据链→行动号召
#  - 短视频量化Rubric(脚本结构/文案语言/专业价值/转化力)
#  - AIGC九维评估(表达自然/结构美感/情感共鸣/逻辑严谨/实用性...)
REVIEW_DIMENSIONS = [
    ("hook",    "钩子强度",   "前3秒能否留住人: 反差/悬念/结果前置/身份锁定, 先破预期再讲功能"),
    ("pain",    "痛点共鸣",   "是否戳中目标人群具体场景, 用'你'而非'我们', 有代入感"),
    ("evidence","卖点证据链", "卖点是否有支撑: 具体数字/参数/对比/使用场景/前后对比, 数字>形容词"),
    ("trust",   "信任背书",   "是否有可信锚点: 销量数据/检测报告/真人实测/权威背书"),
    ("cta",     "结尾行动力", "是否给出明确具体的下单指令+紧迫感(限时/限量/专属价)"),
    ("cohere",  "叙事连贯",   "钩子→痛点→证据→CTA 是否顺, 有无跳跃/断层/前后矛盾"),
    ("fluent",  "口语自然",   "是否口语化像真人讲, 无书面语堆砌/机械重复"),
    ("pacing",  "信息密度节奏","单卖点是否讲透(一个卖点+一个画面), 节奏不拖沓无信息过载"),
]
DIM_KEYS = [k for k, _, _ in REVIEW_DIMENSIONS]
DIM_NAMES = {k: n for k, n, _ in REVIEW_DIMENSIONS}
DIM_DESCS = {k: d for k, _, d in REVIEW_DIMENSIONS}
CRIT_DIMS = ("hook", "cohere", "cta")   # 任一过低即判为弱片


def ai_review_plans(plan_objs, llm_cfg, out_file=None):
    """AI 整片文案审片: 每条方案的分段文案交 LLM 评
    叙事连贯/卖点顺序/可信度, 返回问题清单并写报告文件。
    未配置/接口失败 -> 返回 (False, 提示)"""
    if not (llm_cfg.get("api_base") and llm_cfg.get("api_key")
            and llm_cfg.get("model")):
        return False, ("config.json 未配置 llm (api_base/api_key/model), "
                       "AI审片跳过")
    report, bad, cards = [], [], []
    dim_line = "、".join(f"{n}({k})" for k, n, _ in REVIEW_DIMENSIONS)
    print(f"[AI审片] 正在用 {len(REVIEW_DIMENSIONS)} 个维度评审 "
          f"{len(plan_objs)} 条方案 (模型 {llm_cfg.get('model')})...")
    print(f"        维度: {dim_line}")
    for i, p in enumerate(plan_objs):
        lines = "\n".join(f"{j+1}. [{s.get('slot','')}] {s['text'].replace(' / ', ' ')}"
                          for j, s in enumerate(p))
        prompt = (
            "你是带货短视频审片师, 用多维度给一条混剪带货视频的口播文案打分"
            "(文案按播放顺序, 来自字幕OCR, 同音错别字/型号/品牌名这类识别误差"
            "请忽略, 不要当成问题)。\n"
            "请按以下 8 个维度各打 0-100 分(分数要有区分度, 不要都给高分):\n"
            + "\n".join(f"- {k}: {n} —— {d}" for k, n, d in REVIEW_DIMENSIONS)
            + "\n评审原则: 钩子要反差/悬念/结果前置; 卖点必须有具体数字或对比支撑"
            "(数字>形容词); 必须有可信锚点(销量/实测/权威); 结尾要落具体下单指令+紧迫感;"
            "整体钩子→痛点→证据→CTA 要顺、不跳跃不矛盾; 口语化像真人讲。\n"
            "issues 每条控制在 30 字内、不能含换行符; 没有明显问题就给空数组。\n"
            "只输出单行 JSON, 不要 markdown 代码块, 不要解释:\n"
            "{\"score\": 0-100整数(8维平均分), \"dims\": {\"hook\":0-100, "
            "\"pain\":0-100, \"evidence\":0-100, \"trust\":0-100, \"cta\":0-100, "
            "\"cohere\":0-100, \"fluent\":0-100, \"pacing\":0-100}, "
            "\"issues\": [\"问题1\",\"问题2\"]}\n"
            "文案:\n" + lines)
        try:
            content = llm_chat(llm_cfg, [{"role": "user", "content": prompt}])
            data = _json_loose(content)
            try:
                score = int(float(data.get("score", 80)))
            except (TypeError, ValueError):
                score = 80
            dims = data.get("dims") or {}
            if isinstance(dims, dict):
                dims = {k: max(0, min(100, int(float(v))))
                        for k, v in dims.items() if str(k) in DIM_KEYS}
            else:
                dims = {}
            issues = [str(x) for x in data.get("issues", [])][:4]
        except (OSError, ValueError, KeyError, IndexError) as e:
            report.append(f"第{i+1}条: 审片失败 ({e})")
            continue
        # 维度评分卡(只高亮弱于60的维度, 一眼看出短板)
        weak = {k: v for k, v in dims.items() if v < 60}
        card = " | ".join(f"{DIM_NAMES.get(k, k)}:{v}" for k, v in dims.items()) \
            if dims else "(无维度评分)"
        cards.append(f"第{i+1}条 总分{score}  维度[{card}]")
        report.append(f"第{i+1}条: {score}分" +
                      ("; ".join(issues) if issues else " 无明显问题") +
                      ("" if not weak else "  短板:" +
                       ",".join(f"{DIM_NAMES.get(k, k)}{v}" for k, v in weak.items())))
        # 判弱: 总分<70, 或关键维度(钩子/连贯/CTA)任一<55
        weak_flag = score < 70 or any(dims.get(k, 99) < 55 for k in CRIT_DIMS)
        if weak_flag:
            bad.append((i, score, issues))
    if out_file:
        try:
            with open(out_file, "w", encoding="utf-8") as f:
                f.write("===== AI 多维度审片评分卡 (合理程度 & 文案逻辑) =====\n")
                f.write("\n".join(cards) + "\n\n")
                f.write("===== 逐条问题 =====\n")
                f.write("\n".join(report) + "\n")
        except OSError:
            pass
    for line in report:
        print("  " + line)
    return True, bad


# ---------------- AI 选段: LLM 从预筛候选里组合方案 ----------------
def _pool_topk(pools, pk, k, rng):
    """库内按基础质量排序取 top-k 作为 LLM 候选 (控制 prompt 体积)"""
    segs = [s for s in pools.get(pk, []) if 2.0 <= s["t1"] - s["t0"] <= 14]
    good = [s for s in segs
            if not BAD_END_TAIL.search(s["text"].split(" / ")[-1])
            and not HANG_START.search(s["text"].split(" / ")[0])]
    if len(good) >= max(3, k // 2):
        segs = good
    segs = sorted(segs, key=lambda s: -(s["t1"] - s["t0"]))
    if len(segs) > k:
        segs = rng.sample(segs, k)
    return segs


def ai_pick_plans(pools, count, template, llm_cfg, rng, banned=None):
    """AI 选段: 每槽位规则预筛 top-k 候选 -> LLM 组合 count 套方案。
    返回 plan_objs 列表 (与 pick_plan 返回同构); 失败/校验不过 -> None。
    banned: set[(video, round(t0,1))] 拉黑分段, 不进候选。"""
    if not (llm_cfg.get("api_base") and llm_cfg.get("api_key")
            and llm_cfg.get("model")):
        return None
    banned = banned or set()

    def ok(s):
        return (s["video"], round(s["t0"], 1)) not in banned

    # 候选数随套数放大: 开头/结尾至少等于套数(保证每套都能拿到不重样的开头),
    # 卖点给更宽以支撑证据链 + 跨方案不重复
    kmap = {"开头": max(count + 2, 12),
            "卖点": max(int(count * 1.6), 16),
            "结尾": max(count + 2, 8), "过渡": 4}
    cands = {}
    for pk in ("开头", "卖点", "结尾"):
        cands[pk] = [s for s in _pool_topk(pools, pk, kmap[pk], rng) if ok(s)]
        if not cands[pk]:
            return None
    ids = {}                      # 编号 -> (库, 段)
    blocks = []
    for pk in ("开头", "卖点", "结尾"):
        lines = []
        for j, s in enumerate(cands[pk]):
            cid = "%s%d" % (pk[0], j + 1)      # 开1 卖1 结1
            ids[cid] = (pk, s)
            lines.append("%s | %.1fs | %s" % (cid, s["t1"] - s["t0"],
                                              s["text"].replace(" / ", " ")))
        blocks.append("【%s候选】\n%s" % (pk, "\n".join(lines)))
    slot_desc = []
    for slot in template:
        pk = SLOT_POOL.get(slot, "卖点")
        slot_desc.append("%s(从%s候选里选)" % (slot, pk))
    n_slot = len(template)
    limits = {"开头": len(cands["开头"]), "卖点": len(cands["卖点"]),
              "结尾": len(cands["结尾"])}
    prefix_seq = []
    ex_ids = []
    for k, slot in enumerate(template):
        pk = SLOT_POOL.get(slot, "卖点")
        base = {"开头": "开", "卖点": "卖", "结尾": "结"}[pk]
        prefix_seq.append(base)
        ex_ids.append("%s%d" % (base, min(limits[pk], k + 1)))
    prefix_str = ",".join(prefix_seq)
    prompt = (
        "你是资深带货短视频剪辑师。从素材库里为 %d 条混剪视频各选一套分段, "
        "共 %d 个槽位:\n%s\n\n"
        "候选素材 (编号 | 时长 | 文案):\n%s\n\n"
        "硬性规则:\n"
        "1. 每套恰好 %d 个编号, 编号前缀逐位必须是: %s\n"
        "   (第1~%d个槽位用「开」开头编号, 中间用「卖」, 最后一个用「结」)\n"
        "2. 【最优先】每套的「开」编号必须与其他套都不同 —— %d 套视频开头绝不重样\n"
        "3. 同一套内「卖」编号不要重复; 不同套之间的卖点也尽量少重复\n"
        "4. 单套结构必须完整且符合叙事弧线: 钩子(开场反差/悬念/结果前置留住人) "
        "-> 痛点(戳中具体场景, 用'你') -> 证据(具体数字/参数/对比/使用场景) "
        "-> 信任(销量数据/真人实测/权威背书) -> 结尾行动号召(价格/优惠/下单)。\n"
        "5. 优先选句子完整、信息量足、有具体数字的文案; "
        "空洞口号(如只有'质量很好')不要选。\n"
        "6. 优先选能在 8 维度拿高分的片段(最终会按这些维度打分): "
        "开头反差/悬念(钩子强度高)、卖点带具体数字或前后对比(证据链强)、"
        "带销量/实测/权威(信任背书强)、结尾落具体下单指令+紧迫感(行动力强); "
        "整体钩子->痛点->证据->CTA 要顺、不跳跃不矛盾。\n\n"
        "只输出 JSON(不要markdown代码块, 不要解释), 严格按这个格式:\n"
        '{"plans": [%s]}'
        % (count, n_slot, " -> ".join(slot_desc), "\n\n".join(blocks),
           n_slot, prefix_str,
           sum(1 for x in prefix_seq if x == "开"),
           count,
           json.dumps([ex_ids], ensure_ascii=False)))
    def _norm_id(x):
        """编号归一: '开2'/'开头2'/'开 2'/'卖12' -> 合法编号; 非法返回 None"""
        if not isinstance(x, str):
            x = str(x)
        x = (x.replace(" ", "").replace("开头", "开").replace("钩子", "开")
             .replace("卖点", "卖").replace("结尾", "结").replace("号召", "结"))
        mm = re.match(r"^([开卖结])(\d+)$", x)
        if not mm:
            return None
        base, no = mm.group(1), int(mm.group(2))
        pk = {"开": "开头", "卖": "卖点", "结": "结尾"}[base]
        if not 1 <= no <= len(cands[pk]):
            return None
        return "%s%d" % (base, no)

    raw = None
    for attempt in range(2):              # LLM 输出抖动大, 失败自动重试一次
        try:
            content = llm_chat(llm_cfg,
                               [{"role": "user", "content": prompt}],
                               timeout=180)
            content = re.sub(r"^```(?:json)?|```$", "", content.strip(),
                             flags=re.M).strip()
            m_ = re.search(r"\{.*\}", content, re.S)
            data = json.loads(m_.group(0)) if m_ else {}
            got = data.get("plans") or []
            if isinstance(got, list) and got:
                raw = got
                break
        except (OSError, ValueError, KeyError, IndexError) as e:
            print(f"[AI选段] 第{attempt + 1}次调用失败({e})")
    if not raw:
        print("[AI选段] 未得到有效返回, 回退规则选段")
        return None
    # 校验 + 组装 (含跨方案去重: 开头全批唯一, 卖点/结尾尽量不撞车)
    out = []
    used_all = set()          # 已被前面方案占用的编号
    for i, seq in enumerate(raw[:count]):
        # 容错: 模型偶尔多包一层嵌套 [[...]] -> 自动展平
        while isinstance(seq, list) and len(seq) == 1 and isinstance(seq[0], list):
            seq = seq[0]
        if not isinstance(seq, list) or len(seq) != len(template):
            print(f"[AI选段] 第{i+1}条槽位数不对, 该条回退规则选段")
            out.append(None)
            continue
        plan, used_ids = [], set()
        valid = True
        for slot, cid in zip(template, seq):
            nid = _norm_id(cid)
            if nid is None or nid not in ids:
                valid = False
                break
            pk, s = ids[nid]
            need_pk = SLOT_POOL.get(slot, "卖点")
            if pk != need_pk or nid in used_ids:
                valid = False
                break
            used_ids.add(nid)
            plan.append(dict(slot=slot, **s))
        if valid:
            op = next((x for x in used_ids if x.startswith("开")), None)
            if op in used_all:
                # 跨方案开头重复 -> 用户明确抱怨过, 直接回退规则选段
                print(f"[AI选段] 第{i+1}条开头与其他方案重复, 回退规则选段")
                valid = False
            elif len(used_all & used_ids) >= 2:
                # 卖点/结尾与已有方案大面积撞车, 也回退以保证多样性
                print(f"[AI选段] 第{i+1}条与其他方案素材高度重合, 回退规则选段")
                valid = False
        out.append(plan if valid else None)
        if valid:
            used_all |= used_ids
        if not valid:
            print(f"[AI选段] 第{i+1}条校验不过({str(seq)[:60]}), "
                  "该条回退规则选段")
    return out if any(p for p in out) else None


# ---------------- AI 拉黑闭环: 终审发现的问题段下次避开 ----------------
AI_BAN_JSON = os.path.join(BUILD, "ai_ban.json")
AI_LIB_JSON = os.path.join(BUILD, "ai_lib.json")


def load_ai_lib():
    """AI 优化素材库结果: {(video, round(t0,1)): {"pool":..., "score":...}}
    fingerprint 与当前 subtitles.json 一致才有效 (字幕变了自动作废)"""
    try:
        with open(AI_LIB_JSON, encoding="utf-8") as f:
            d = json.load(f)
        if d.get("fingerprint") != hashlib.md5(
                open(SUBS_JSON, "rb").read()).hexdigest():
            return {}
        out = {}
        for k, v in d.get("items", {}).items():
            video, t0 = k.rsplit("|", 1)
            out[(video, round(float(t0), 1))] = v
        return out
    except (OSError, ValueError, TypeError):
        return {}


def ai_optimize_library():
    """AI 优化素材库: 分批把候选段交 LLM 评审「应属哪个库+质量分」,
    结果写 build/ai_lib.json, 之后每次出片自动生效 (挪库/剔低质/打分加权)"""
    llm_cfg = load_llm_cfg()
    if not (llm_cfg.get("api_base") and llm_cfg.get("api_key")
            and llm_cfg.get("model")):
        print("[AI素材库] 未配置 AI 密钥 (帮助→AI 审片设置), 跳过")
        return 1
    pool, _ = load_subtitle_pool()
    if not pool:
        print("[AI素材库] 没有素材数据, 先运行字幕识别")
        return 1
    print(f"[AI素材库] 让 AI 评审 {len(pool)} 个分段的库归属与质量 "
          f"(模型 {llm_cfg.get('model')}, 分批进行)...")
    items = {}
    BATCH = 25
    for bi in range(0, len(pool), BATCH):
        batch = pool[bi:bi + BATCH]
        lines = []
        for j, s in enumerate(batch):
            lines.append("%d | 当前[%s] | %s" % (
                j + 1, s.get("role") or "卖点",
                s["text"].replace(" / ", " ")))
        prompt = (
            "你是带货短视频素材管理师。下面是混剪素材库里的分段文案"
            "(每行: 编号 | 当前提炼的角色 | 文案)。\n"
            "请评审每个分段: 1)它最适合放进哪个素材库——"
            "「开头」(钩子/痛点/招呼, 能当视频第一句) / 「卖点」(中段讲解) / "
            "「结尾」(价格/下单/优惠等行动号召); 2)质量分 1-10"
            "(句子完整、信息量足、无废话=高分; 半句话/脏字/空洞=低分); "
            "3)它在叙事里主要承担的功能 role —— "
            "「钩子」(抓眼球) / 「痛点」(戳场景) / 「证据」(数字对比) / "
            "「信任」(销量实测权威) / 「CTA」(下单号召) / 「其他」。\n"
            "只输出 JSON: {\"items\":[{\"no\":1,\"pool\":\"开头\","
            "\"score\":8,\"role\":\"钩子\"}, ...]}  覆盖全部编号。\n分段:\n"
            + "\n".join(lines))
        try:
            content = llm_chat(llm_cfg, [{"role": "user", "content": prompt}],
                               timeout=180)
            data = _json_loose(content)
            got = {int(x.get("no", 0)): x for x in data.get("items", [])
                   if isinstance(x, dict)}
        except (OSError, ValueError, TypeError, KeyError) as e:
            print(f"  第{bi // BATCH + 1}批评审失败({e}), 该批跳过")
            continue
        for j, s in enumerate(batch):
            x = got.get(j + 1)
            if x and x.get("pool") in ("开头", "卖点", "结尾"):
                try:
                    sc = max(1, min(10, int(x.get("score", 5))))
                except (ValueError, TypeError):
                    sc = 5
                items["%s|%s" % (s["video"], s["t0"])] = {
                    "pool": x["pool"], "score": sc,
                    "role": x.get("role") or "其他"}
        print("  已评审 %d/%d 段" % (min(bi + BATCH, len(pool)), len(pool)))
    if not items:
        print("[AI素材库] 未得到有效评审结果")
        return 1
    try:
        os.makedirs(BUILD, exist_ok=True)
        with open(AI_LIB_JSON, "w", encoding="utf-8") as f:
            json.dump({"fingerprint": hashlib.md5(
                open(SUBS_JSON, "rb").read()).hexdigest(),
                "items": items}, f, ensure_ascii=False, indent=1)
    except OSError as e:
        print(f"[AI素材库] 结果写入失败: {e}")
        return 1
    scores = [v["score"] for v in items.values()]
    low = sum(1 for x in scores if x <= 2)
    print(f"[AI素材库] 完成: 评审 {len(items)}/{len(pool)} 段, "
          f"平均 {sum(scores)/len(scores):.1f} 分, 低质(<=2分) {low} 段")
    print("[AI素材库] 结果已缓存, 之后每次出片自动生效: "
          "归错库的自动挪正 + 低质段不再选用 + 高分段优先")
    return 0


def load_ai_ban():
    try:
        with open(AI_BAN_JSON, encoding="utf-8") as f:
            d = json.load(f)
        return {(x[0], round(float(x[1]), 1)) for x in d.get("ban", [])}
    except (OSError, ValueError, TypeError):
        return set()


# 拉黑风暴防护: 成片 OCR 误差可能把素材池抽空导致后面方案只能重复。
BAN_HARD_CAP = 60          # 总上限: 超出按入库顺序(FIFO)自动解禁最老的一段
BAN_MAX_PER_REVIEW = 1     # 单次成片终审最多拉黑 1 段, 防止一次 OCR 抖动坑掉好素材


def add_ai_ban(segs):
    """segs: [(video, t0), ...] 追加拉黑并落盘。

    三重保险堵住"拉黑风暴"恶性循环:
      1) 单次最多 BAN_MAX_PER_REVIEW 段(默认 1);
      2) 总上限 BAN_HARD_CAP, 超出按入库顺序(FIFO)自动解禁最老的一段;
      3) 只有 ai_review_transcript 确认"确实命中原文引文"的硬伤段才会进来,
         OCR 同音错字/成片叠加物一律不会到这里。
    落盘格式为 [[video, t0, seq], ...] (seq 单调递增, 用于 FIFO 排序)。"""
    if not segs:
        return 0
    segs = segs[:BAN_MAX_PER_REVIEW]
    try:
        with open(AI_BAN_JSON, encoding="utf-8") as f:
            d = json.load(f)
        ban = [list(x) for x in d.get("ban", [])]
    except (OSError, ValueError, TypeError):
        ban = []
    seq = (ban[-1][2] + 1) if ban and len(ban[-1]) > 2 else len(ban)
    existing = {(x[0], round(float(x[1]), 1)) for x in ban}
    added = 0
    for v, t in segs:
        k = (v, round(float(t), 1))
        if k not in existing:
            ban.append([v, t, seq]); seq += 1
            existing.add(k); added += 1
    if len(ban) > BAN_HARD_CAP:           # FIFO: 保留最新, 丢弃最老
        ban.sort(key=lambda x: x[2] if len(x) > 2 else 0)
        ban = ban[len(ban) - BAN_HARD_CAP:]
    if added:
        try:
            os.makedirs(BUILD, exist_ok=True)
            with open(AI_BAN_JSON, "w", encoding="utf-8") as f:
                json.dump({"ban": ban}, f, ensure_ascii=False)
        except OSError:
            pass
    return added


def ai_review_transcript(video_path, plan_segs, llm_cfg, orig_segs=None):
    """AI 成片终审: OCR 提取成片实际字幕 -> LLM 找半句/矛盾/脏字硬伤段。

    拉黑闭环(下次生成避开)做了三重保险, 杜绝成片 OCR 误差把素材池抽空的
    恶性循环:
      1) 仅当整片评分 < 80 才考虑拉黑;
      2) 每段成片 OCR 与方案原文做相似度比对, 同音错字/型号/品牌名这类
         识别误差(相似度仍很高)一律豁免, 绝不拉黑;
      3) 即便 LLM 标了硬伤, 也必须能在方案原文里命中"原文引文"才拉黑
         (成片独有的贴纸/水印文字不算段本身的错)。
    单次最多 1 段 (add_ai_ban 内还有硬上限 + 最老自动解禁)。返回拉黑段数。"""
    if not (llm_cfg.get("api_base") and llm_cfg.get("api_key")
            and llm_cfg.get("model")):
        return 0
    r = subprocess.run([FFMPEG, "-hide_banner", "-i", video_path],
                       capture_output=True)
    m_ = re.search(r"Duration: (\d+):(\d+):(\d+(?:\.\d+)?)",
                   (r.stderr or b"").decode("utf-8", "ignore"))
    if not m_:
        return 0
    dur = int(m_.group(1)) * 3600 + int(m_.group(2)) * 60 + float(m_.group(3))
    print("[AI终审] 提取成片字幕全文中...")
    lines = ocr_video_lines(video_path, dur, fps=1.5)
    if not lines:
        print("[AI终审] 成片未识别到字幕, 跳过")
        return 0
    # 按方案段的时间轴分组 (成片时段序 = 方案段序, 过渡段也在 plans 里)
    seg_texts = []
    t_cursor = 0.0
    for i, (src, t0, t1, tag) in enumerate(plan_segs):
        d = t1 - t0
        seg_texts.append((i + 1, t_cursor, t_cursor + d,
                          tag.split("-", 1)[1] if "-" in tag else tag))
        t_cursor += d
    body = "\n".join(f"{i}. [{a:.1f}-{b:.1f}s] {t.replace(' / ', ' ')}"
                     for i, a, b, t in seg_texts)
    prompt = (
        "你是带货短视频终审员。下面是一条混剪成片按播放顺序的分段文案"
        "(OCR自成片字幕, 可能有识别误差)。请检查:\n"
        "1. 每段是否是完整的话(有没有明显被切半句/话没说完)\n"
        "2. 有无多余字、错字、与内容无关的文字混入(如贴纸文字/背景水印)\n"
        "3. 叙事逻辑是否连贯, 前后有无矛盾(如数字冲突)\n"
        "4. 结尾是否落在行动号召上\n"
        "5. 再按 8 个维度给成片整体合理程度打分(各 0-100): "
        "hook钩子强度、pain痛点共鸣、evidence卖点证据链、trust信任背书、"
        "cta结尾行动力、cohere叙事连贯、fluent口语自然、pacing信息密度节奏\n"
        "只输出 JSON: {\"score\":0到100整数, \"issues\":[\"问题(带段号)\"], "
        "\"dims\":{\"hook\":0-100,\"pain\":0-100,\"evidence\":0-100,"
        "\"trust\":0-100,\"cta\":0-100,\"cohere\":0-100,\"fluent\":0-100,"
        "\"pacing\":0-100}, "
        "\"bad_segments\":[{\"no\":段号, \"quote\":\"该段里确实存在的原文片段\"}]}\n"
        "bad_segments 只列有半句/矛盾/脏字硬伤的段, 且必须带 quote"
        "(原文里真有的字, 不是你改写后的); 同音错别字/型号/品牌名这类 OCR 误差"
        "不要当成硬伤。轻微瑕疵不要列。文案:\n" + body)
    try:
        content = llm_chat(llm_cfg, [{"role": "user", "content": prompt}],
                           timeout=180)
        data = _json_loose(content)
        try:
            score = int(float(data.get("score", 80)))
        except (TypeError, ValueError):
            score = 80
            issues = [str(x) for x in data.get("issues", [])][:6]
            dims = data.get("dims") or {}
            if isinstance(dims, dict):
                dims = {k: max(0, min(100, int(float(v))))
                        for k, v in dims.items() if str(k) in DIM_KEYS}
            else:
                dims = {}
    except (OSError, ValueError, KeyError, IndexError) as e:
        print(f"[AI终审] 调用失败({e}), 跳过")
        return 0
    weakd = {k: v for k, v in dims.items() if v < 60}
    dimstr = ("  维度短板:" + ",".join(f"{DIM_NAMES.get(k, k)}{v}"
             for k, v in weakd.items())) if weakd else ""
    print(f"[AI终审] {score}分;" + ("; ".join(issues) if issues else "无明显问题") + dimstr)

    # ---- 拉黑三重保险 ----
    ban_pairs = []
    if score < 80:
        raw_bad = data.get("bad_segments", []) or []
        parsed = []
        for x in raw_bad:
            if isinstance(x, dict):
                no, quote = x.get("no"), str(x.get("quote", "") or "")
            else:
                no, quote = x, ""
            try:
                no = int(no)
            except (TypeError, ValueError):
                continue
            if 1 <= no <= len(plan_segs):
                parsed.append((no, quote))
        if parsed:
            def _norm(s):
                return re.sub(r"[\s/,。!?,?、；：”“‘’\"'（）()\-—]",
                              "", (s or ""))

            for no, quote in parsed:
                src, t0, t1, tag = plan_segs[no - 1]
                src_text = tag.split("-", 1)[1] if "-" in tag else tag
                a, b = seg_texts[no - 1][1], seg_texts[no - 1][2]
                seg_ocr = " ".join(t for tt, t in lines
                                   if a - 0.1 <= tt <= b + 0.1)
                sim = difflib.SequenceMatcher(
                    None, _norm(seg_ocr), _norm(src_text)).ratio()
                if sim >= 0.8:
                    # 保险2: 成片与原文确实长得很像 -> 仅是识别误差, 豁免
                    print(f"[AI终审] 段{no}成片与原文相似度 {sim:.0%}, "
                          f"视为 OCR 误差, 不拉黑")
                    continue
                if quote and _norm(quote) not in _norm(src_text):
                    # 保险3: 引文未在方案原文命中 -> 成片叠加物, 不拉黑
                    print(f"[AI终审] 段{no}引文未在原文命中, "
                          f"视为成片叠加物, 不拉黑")
                    continue
                if orig_segs and 1 <= no <= len(orig_segs):
                    o = orig_segs[no - 1]
                    ban_pairs.append((o["video"], o["t0"]))
                else:
                    ban_pairs.append(
                        (src[:-4] if src.lower().endswith(".mp4") else src, t0))
                print(f"[AI终审] 段{no}「{src_text[:18]}」确有硬伤"
                      f"(相似度{sim:.0%}), 已拉黑")
    added = add_ai_ban(ban_pairs) if ban_pairs else 0
    try:
        with open(os.path.join(BUILD, "ai_report.txt"), "a", encoding="utf-8") as f:
            f.write("\n[成片终审] %s (%d分)\n  维度: %s\n  %s\n" % (
                os.path.basename(video_path), score,
                " ".join(f"{DIM_NAMES.get(k, k)}{v}" for k, v in dims.items())
                if dims else "未评分",
                "\n  ".join(issues) if issues else "无明显问题"))
    except OSError:
        pass
    return added


def selfcheck_segments():
    """对 segments.json 做重复/相似/截断/过短自检, 返回问题数"""
    if not os.path.exists(SEG_JSON):
        print("data/segments.json 不存在, 先运行 plan")
        return 0
    with open(SEG_JSON, encoding="utf-8") as f:
        segs = json.load(f)
    issues = 0
    texts = []
    for i, (src, t0, t1, tag) in enumerate(segs):
        text = tag.split("-", 1)[1] if "-" in tag else tag
        texts.append((i, text, t1 - t0))

    print("\n========== 文案自检 ==========")
    # 1. 完全重复
    seen = {}
    for i, text, _ in texts:
        key = re.sub(r"[\s/,。!?,?]", "", text)
        if key in seen:
            print(f"[重复] seg{seen[key]} 与 seg{i} 文案完全相同: {text}")
            issues += 1
        seen[key] = i
    # 2. 高相似 (重复字段)
    for a in range(len(texts)):
        for b in range(a + 1, len(texts)):
            ra = difflib.SequenceMatcher(None, texts[a][1], texts[b][1]).ratio()
            if 0.55 < ra < 1.0:
                print(f"[相似] seg{a} 与 seg{b} 文案相似度 {ra:.0%}: "
                      f"「{texts[a][1]}」vs「{texts[b][1]}」")
                issues += 1
    # 3. 疑似截断 (话没说完)
    for i, text, _ in texts:
        tail = text.split(" / ")[-1].strip()
        if any(tail.endswith(w) for w in INCOMPLETE_END):
            print(f"[截断?] seg{i} 结尾是「{tail}」, 疑似话没说完")
            issues += 1
    # 4. 过短段
    for i, text, d in texts:
        if d < 2.5:
            print(f"[过短] seg{i} 仅 {d:.1f}s: {text}")
            issues += 1
    if issues == 0:
        print("通过: 无重复文案 / 无疑似截断 / 无过短分段")
    else:
        print(f"共 {issues} 处提示, 建议调整字幕或重新 plan")
    print("==============================")
    return issues


def run_full_check(video_path=None):
    """完整自检: 文案(重复/截断) + 画面(黑屏/卡帧) + 音频(静音/爆音/音量)"""
    if not isinstance(video_path, str) or not video_path:
        video_path = None      # CLI 直调时传入的是 args Namespace
    issues = selfcheck_segments()
    if video_path is None:
        cands = glob.glob(os.path.join(OUTDIR, "*.mp4"))
        if cands:
            video_path = max(cands, key=os.path.getmtime)
    if video_path:
        issues += media_check(video_path)
    return issues


def cmd_mix(args):
    need_ffmpeg()
    ensure_dirs()
    count = max(1, int(getattr(args, "count", 1) or 1))
    mmode = getattr(args, "mirror", "auto") or "auto"   # 画面镜像模式
    rng = random.Random()
    mixdir = os.path.join(BUILD, "seg_video")
    voc = os.path.join(BUILD, "seg_vocals")
    aud = os.path.join(BUILD, "seg_audio")
    os.makedirs(mixdir, exist_ok=True)
    covers = {}                       # src -> 封面结束时刻 (0=无封面)
    cover_cache = load_cover_cache()

    # ---- 每条独立的分段方案: 单条用 segments.json, 批量每条随机生成一套新方案 ----
    plans = []
    if count == 1:
        plans.append(load_segments(args.src))
    else:
        pool, dur_map = load_subtitle_pool(args.src)
        if not pool:
            print("data/subtitles.json 不存在或没有字幕数据, 批量随机方案需要字幕 (先运行 subs)")
            sys.exit(1)
        # 优先加载素材库文件 (与当前字幕指纹一致时, 保留手工删改); 否则重建并写出
        pools = None
        if os.path.exists(LIB_JSON):
            try:
                with open(LIB_JSON, encoding="utf-8") as f:
                    lib = json.load(f)
                if lib.get("lib_ver") == 2 and lib.get("subtitles_fingerprint") == hashlib.md5(
                        open(SUBS_JSON, "rb").read()).hexdigest():
                    pools = {"开头": [], "卖点": [], "结尾": []}
                    keymap = {"开头钩子": "开头", "中间卖点": "卖点", "结尾号召": "结尾"}
                    for name, key in keymap.items():
                        for e in lib.get("库", {}).get(name, []):
                            pools[key].append(dict(video=e["video"], t0=e["t0"],
                                                   t1=e["t1"], text=e["text"],
                                                   role=e.get("role", "")))
                    print(f"已加载素材库 data/clip_library.json "
                          f"(开头{len(pools['开头'])}/卖点{len(pools['卖点'])}"
                          f"/结尾{len(pools['结尾'])})")
            except (OSError, ValueError, KeyError):
                pools = None
        if pools is None:
            pools = build_pools(pool)
            cmd_library(None)
            print(f"素材库: 开头钩子 {len(pools['开头'])} 条 / "
                  f"中间卖点 {len(pools['卖点'])} 条 / 结尾号召 {len(pools['结尾'])} 条")
        # 封面闪帧防护: 源视频开头的静态封面卡片区, OCR 会把封面大字当成
        # 第一句钩子, 选中它成片开头就会闪出源视频封面 -> 弃用压在上面的分段
        need_scan = sorted({e["video"] for lib in pools.values() for e in lib
                            if e["t0"] < 4.5})
        if need_scan:
            print(f"封面检测: 扫描 {len(need_scan)} 个视频的开头静态封面...")
            for v in need_scan:
                vf = v if v.lower().endswith(".mp4") else v + ".mp4"
                p = os.path.join(args.src, vf)
                if os.path.exists(p):
                    covers[vf] = get_cover_end(
                        p, hashlib.md5(vf.encode("utf-8")).hexdigest()[:12],
                        cover_cache)
            try:
                with open(COVER_JSON, "w", encoding="utf-8") as f:
                    json.dump({"ver": 1, "covers": cover_cache}, f,
                              ensure_ascii=False)
            except OSError:
                pass
            n_cov = sum(1 for x in covers.values() if x)
            print(f"  检出封面 {n_cov}/{len(covers)} 个")
        n_drop = 0
        for pk in list(pools):
            keep = []
            for e in pools[pk]:
                vf = e["video"] if e["video"].lower().endswith(".mp4") \
                    else e["video"] + ".mp4"
                ce = covers.get(vf, 0)
                if ce and e["t0"] < ce - 0.05:
                    n_drop += 1
                    continue
                keep.append(e)
            pools[pk] = keep
        if n_drop:
            print(f"  已弃用 {n_drop} 个压在封面上的分段 (防止成片闪出源封面)")
        # AI 素材库自动评审(task #10): 开了 AI 选段但还没优化过素材库时,
        # 自动跑一次 LLM 素材库评审(挪库+剔低质+打分), 之后 load_ai_lib 直接受益,
        # 不必每次手动点"AI 素材库优化"。结果按字幕指纹缓存, 字幕不变不重跑。
        # 这一步同时根治了"品类规则(RULES)硬编码错配"的问题——
        # 评审由 LLM 按语义把分段分到 开头/卖点/结尾, 与具体品类话术无关。
        if (getattr(args, "ai_plan", "off") == "on"
                and not os.path.exists(AI_LIB_JSON)):
            _llm0 = load_llm_cfg()
            if _llm0.get("api_base") and _llm0.get("api_key"):
                print("[AI素材库] 未检测到优化结果, 自动跑一次素材库评审...")
                try:
                    ai_optimize_library()
                except Exception as e:
                    print(f"[AI素材库] 自动评审失败, 跳过: {e}")
            else:
                print("[AI素材库] 未配置 AI 密钥, 跳过自动评审 (用规则分类)")
        # AI 素材库优化结果生效: 归错库的挪正 + 低质段剔除 + 打分加权
        ai_scores = load_ai_lib()
        if ai_scores:
            moved, dropped = 0, 0
            for pk in ("开头", "卖点", "结尾"):
                keep = []
                for e in pools[pk]:
                    v = ai_scores.get((e["video"], round(e["t0"], 1)))
                    if v:
                        if v.get("pool") in ("开头", "卖点", "结尾") \
                                and v["pool"] != pk:
                            pools[v["pool"]].append(e)     # 挪到 AI 认为对的库
                            moved += 1
                            continue
                        if int(v.get("score", 10)) <= 2:
                            dropped += 1
                            continue
                    keep.append(e)
                pools[pk] = keep
            if moved or dropped:
                print(f"AI素材库生效: 挪库 {moved} 段, 剔除低质 {dropped} 段, "
                      "高分段优先 (重跑 ailib 可更新评审)")
        # 快速模式: 只用人声已分离缓存的视频, 不触发 demucs (快速预览/测试用)
        if getattr(args, "only_cached", False):
            def _has_voc(video):
                vsrc = f"{video}.mp4"
                vp = os.path.join(BUILD, "voc_full",
                                  hashlib.md5(vsrc.encode("utf-8")).hexdigest()[:12],
                                  "vocals.wav")
                return os.path.exists(vp)
            n0 = sum(len(v) for v in pools.values())
            for k in list(pools):
                pools[k] = [s for s in pools[k] if _has_voc(s["video"])]
            n1 = sum(len(v) for v in pools.values())
            print(f"快速模式: 只用人声已分离的视频, 素材 {n0} -> {n1} 条")
            if n1 == 0:
                print("没有任何已分离人声的视频, 请去掉快速模式正常跑一次 (自动分离)")
                sys.exit(1)
        history = []
        plans = []
        voice_mode = getattr(args, "voice", "auto") or "auto"
        tpl = DURATION_TEMPLATES.get(int(getattr(args, "duration", 0) or 0),
                                     TEMPLATE)
        if tpl is not TEMPLATE:
            print(f"时长模式: {getattr(args, 'duration')}秒 ({len(tpl)} 槽位, "
                  f"预计 40-{args.duration + 10}秒)")
        phash_cache = {}
        ai_banned = load_ai_ban()
        if ai_banned:
            print(f"AI拉黑: {len(ai_banned)} 个问题分段本次自动避开 "
                  "(build/ai_ban.json)")

        def phash_of(video, t):
            return frame_dhash(os.path.join(args.src, f"{video}.mp4"),
                               t, phash_cache)

        # AI 选段(可选): LLM 从预筛候选里组合方案, 失败逐条回退规则选段
        ai_plans = None
        if getattr(args, "ai_plan", "off") == "on":
            llm_cfg = load_llm_cfg()
            if not (llm_cfg.get("api_base") and llm_cfg.get("api_key")):
                print("[AI选段] 未配置 AI 密钥, 本次用规则选段 "
                      "(帮助→AI 审片设置 三步配好)")
            else:
                print(f"[AI选段] 让 AI 从候选里组合 {count} 套方案 "
                      f"(模型 {llm_cfg.get('model')})...")
                ai_plans = ai_pick_plans(pools, count, tpl, llm_cfg, rng,
                                         banned=ai_banned)
                if ai_plans is None:
                    print("[AI选段] 未得到有效方案, 全部回退规则选段")
                else:
                    print(f"[AI选段] AI 给出 {sum(1 for p in ai_plans if p)}"
                          f"/{count} 套有效方案")
        for n_i in range(count):
            plan = None
            if ai_plans and n_i < len(ai_plans) and ai_plans[n_i]:
                plan = ai_plans[n_i]
            else:
                plan = pick_plan(pools, rng, history, template=tpl,
                                 voice=voice_mode, phash=phash_of,
                                 banned=ai_banned, ai_scores=ai_scores)
            if not plan:
                print("未能拼装出方案, 请检查字幕角色分类规则 RULES 是否匹配你的品类话术")
                sys.exit(1)
            if getattr(args, "flow", "off") == "on":
                plan = insert_transitions(plan, pools, rng)
            history.append(plan)
            plans.append(plan_to_segs(plan, dur_map))
        # 方案质量自检: 开头不重样 / 无CTA开头 / 段内无重复 / 数字一致
        # (发现问题重新生成, 最多3轮)
        INTRO_FILLER = ("大家好", "今天给大家", "今天推荐", "哈喽", "hello",
                        "hi ", "各位", "给大家推荐", "我来给大家")
        for attempt in range(3):
            plan_objs = history
            openings = [p[0]["text"].split(" / ")[0] for p in plan_objs if p]
            n_open = len(set(openings))
            # 跨方案开头重复检测: 相同开头文案的方案回退重生成(用户抱怨"有小重复")
            open_dupes = set()
            seen_o = {}
            for i, op in enumerate(openings):
                if op in seen_o:
                    open_dupes.add(i); open_dupes.add(seen_o[op])
                else:
                    seen_o[op] = i
            cta_first = [i for i, p in enumerate(plan_objs)
                         if p and re.search(CTA_END_PAT, p[0]["text"])]
            dup_in_plan = []
            for i, p in enumerate(plan_objs):
                for a in range(len(p)):
                    for b in range(a + 1, len(p)):
                        r = difflib.SequenceMatcher(None, p[a]["text"],
                                                    p[b]["text"]).ratio()
                        if r > 0.55:
                            dup_in_plan.append((i, p[a]["text"][:16],
                                                p[b]["text"][:16], r))
            # 数字一致性: 同一条片里 "3合一" 撞 "5合一" 这类硬伤直接重生成
            num_conflicts = []
            for i, p in enumerate(plan_objs):
                claims = {}
                for seg in p:
                    for unit, val in extract_num_claims(seg["text"]).items():
                        if unit in claims and claims[unit] != val:
                            num_conflicts.append(
                                (i, claims[unit] + unit, val + unit))
                        claims[unit] = val
            print(f"方案自检(第{attempt + 1}轮): 开头 {n_open}/{count} 种不重样, "
                  f"开头重复 {len(open_dupes)} 条, "
                  f"CTA开头 {len(cta_first)} 条, 段内重复 {len(dup_in_plan)} 处, "
                  f"数字冲突 {len(num_conflicts)} 处")
            if open_dupes:
                print(f"  [重生成] {len(open_dupes)} 条开头文案重复")
            bad_idx = set(cta_first)
            bad_idx.update(i for i, _, _, _ in dup_in_plan)
            bad_idx.update(i for i, _, _ in num_conflicts)
            bad_idx.update(open_dupes)
            # 维度启发式(用分析优化: 直接攻击"开头分析不好/卖点证据弱")
            for i, p in enumerate(plan_objs):
                if not p:
                    continue
                op = p[0]["text"].split(" / ")[0]
                if any(w in op for w in INTRO_FILLER):
                    bad_idx.add(i)            # 开头像铺垫/自我介绍 -> 钩子弱
                    print(f"  [重生成] 第{i+1}条 开头像铺垫/自我介绍(钩子弱)")
                sell = [s for s in p if s.get("slot") == "卖点"]
                full = " ".join(s["text"] for s in p)
                if len(sell) >= 2 and not re.search(r"\d", full):
                    bad_idx.add(i)            # 多个卖点却零数字 -> 证据链薄弱
                    print(f"  [重生成] 第{i+1}条 卖点无具体数字(证据链薄弱)")
            if not bad_idx:
                break
            if cta_first:
                print("  [重生成] 有开头是下单话术的方案...")
            for i, t1, t2, r in dup_in_plan[:4]:
                print(f"  [重生成] 第{i + 1}条 段内相似{r:.0%}: 「{t1}」vs「{t2}」")
            for i, a, b in num_conflicts[:4]:
                print(f"  [重生成] 第{i + 1}条 数字自相矛盾: 「{a}」vs「{b}」")
            # 只重生成有问题的条 (AI 选段的有效条保留)
            for i in sorted(bad_idx):
                hist_wo = [hp for j, hp in enumerate(history) if j != i]
                plan = pick_plan(pools, rng, hist_wo, template=tpl,
                                 voice=voice_mode, phash=phash_of,
                                 banned=ai_banned, ai_scores=ai_scores)
                if not plan:
                    continue
                if getattr(args, "flow", "off") == "on":
                    plan = insert_transitions(plan, pools, rng)
                history[i] = plan
                plans[i] = plan_to_segs(plan, dur_map)
        # 源文件索引: 按 basename 兜底匹配, 兼容根目录不一致的相对路径
        index = {}
        for dirpath, _, files in os.walk(args.src):
            for fn in files:
                if fn.lower().endswith(".mp4"):
                    index.setdefault(fn, os.path.join(dirpath, fn))
        for segs in plans:
            for i, (src, t0, t1, tag) in enumerate(segs):
                p = os.path.join(args.src, src)
                if not os.path.exists(p):
                    p2 = index.get(os.path.basename(src))
                    if not p2:
                        print(f"源视频不存在: {p}")
                        sys.exit(1)
                    segs[i] = (os.path.relpath(p2, args.src).replace("\\", "/"),
                               t0, t1, tag)
        # 多样性报告: 两两方案之间分段的重合率
        keysets = [{(s[0], round(s[1], 1)) for s in segs} for segs in plans]
        sims = []
        for a in range(len(keysets)):
            for b in range(a + 1, len(keysets)):
                u = keysets[a] | keysets[b]
                if u:
                    sims.append(len(keysets[a] & keysets[b]) / len(u))
        avg = f", 两两方案分段平均重合率 {sum(sims) / len(sims):.0%}" if sims else ""
        print(f"已生成 {count} 套互不相同的随机方案 (候选段 {len(pool)}{avg})")

    # ---- 分段缓存按「内容」寻址: 同 (视频,起止) 的段全批共用音频/人声/视频 ----
    def seg_key(src, t0, t1):
        return hashlib.md5(f"{src}|{t0:.2f}|{t1:.2f}".encode("utf-8")).hexdigest()[:12]

    # ---- 全片人声分离: 每个源视频只跑一次 demucs, 分段人声直接切片 ----
    os.makedirs(voc, exist_ok=True)
    srcs = {}
    for segs in plans:
        for src, _, _, _ in segs:
            srcs.setdefault(src, os.path.join(args.src, src))
    full_voc = {src: os.path.join(BUILD, "voc_full",
                                  hashlib.md5(src.encode("utf-8")).hexdigest()[:12],
                                  "vocals.wav")
                for src in srcs}
    todo = [(src, p) for src, p in full_voc.items() if not os.path.exists(p)]
    if todo:
        print(f"demucs 全片人声分离中 ({len(todo)}/{len(full_voc)} 个视频, "
              f"CPU 模式, 结果永久缓存, 之后批量不再重复分离)...")
        stage = os.path.join(BUILD, "voc_full", "stage")
        os.makedirs(stage, exist_ok=True)
        # 1) 全部转成 wav (ffmpeg 直接从源目录读取, demucs 只吃本地 wav)
        staged = []
        for src, _ in todo:
            key = hashlib.md5(src.encode("utf-8")).hexdigest()[:12]
            wav = os.path.join(stage, key + ".wav")
            if not (os.path.exists(wav) and os.path.getsize(wav) > 10000):
                print(f"  提取音频: {src}")
                sh([FFMPEG, "-y", "-i", srcs[src], "-vn", "-ar", "44100", "-ac", "2",
                    "-c:a", "pcm_s16le", wav])
            staged.append(wav)
        # 2) 一次批量喂给 demucs (模型只加载一次), 单个失败再单独重试隔离
        sh([sys.executable, "-m", "demucs", "--two-stems=vocals", "-n", "htdemucs",
            "--shifts", "0", "--out", os.path.join(BUILD, "voc_full"),
            "-d", "cpu"] + staged, check=False, tail=200)
        still = []
        for src, p in todo:
            key = hashlib.md5(src.encode("utf-8")).hexdigest()[:12]
            outp = os.path.join(BUILD, "voc_full", "htdemucs", key, "vocals.wav")
            if not os.path.exists(outp):
                still.append((src, p, key))
        for src, p, key in still:
            print(f"  重试: {src}")
            sh([sys.executable, "-m", "demucs", "--two-stems=vocals", "-n", "htdemucs",
                "--shifts", "0", "--out", os.path.join(BUILD, "voc_full"),
                "-d", "cpu", os.path.join(stage, key + ".wav")],
               check=False, tail=200)
        # 3) 结果归位到内容寻址缓存 (临时 wav 留在 stage 目录, 不做删除)
        fail = []
        for src, p in todo:
            key = hashlib.md5(src.encode("utf-8")).hexdigest()[:12]
            outp = os.path.join(BUILD, "voc_full", "htdemucs", key, "vocals.wav")
            vp = full_voc[src]
            if os.path.exists(outp):
                os.makedirs(os.path.dirname(vp), exist_ok=True)
                shutil.move(outp, vp)
            else:
                fail.append(src)
        # htdemucs 临时目录不做删除 (含 no_vocals 等, 留存无害)
        if fail:
            print(f"人声分离失败: {fail}")
            sys.exit(2)
    print(f"full vocals ready ({len(full_voc)} 个源视频)")

    # ---- 切点吸附: 用干净人声的语音区间把切点对齐自然停顿, 一句话说完才切 ----
    cut_file = os.path.join(BUILD, "cut_cache.json")
    cut_ver = 7                       # 算法版本: 升级后旧缓存自动作废重算
    cut_cache = {}
    if os.path.exists(cut_file):
        try:
            with open(cut_file, encoding="utf-8") as f:
                _c = json.load(f)
            if _c.get("ver") == cut_ver:
                cut_cache = _c.get("cuts", {})
        except (OSError, ValueError):
            cut_cache = {}
    vad_cache = load_vad_cache()
    cut_dirty = False
    q_n = q_ok = warn_n = 0
    # 每个源视频最早的分段起点: 只有它 <5.5s 才可能碰到处在片头的封面区
    min_t0 = {}
    for segs in plans:
        for src, t0, _, _ in segs:
            if t0 < min_t0.get(src, 9e9):
                min_t0[src] = t0
    # 原始字幕行索引: 用于"延长出点不吞掉下一句 CTA" (开头段绝不吸进下单话术)
    raw_lines = {}
    if os.path.exists(SUBS_JSON):
        try:
            with open(SUBS_JSON, encoding="utf-8") as f:
                _subs = json.load(f)
            for k, v in _subs.items():
                if isinstance(v, dict) and v.get("lines"):
                    raw_lines[k] = sorted((float(t), txt)
                                          for t, txt in v["lines"])
        except (OSError, ValueError):
            raw_lines = {}
    for segs in plans:
        for i, (src, t0, t1, tag) in enumerate(segs):
            ck = seg_key(src, t0, t1)
            if ck in cut_cache:
                nt0, nt1 = cut_cache[ck][:2]
                vb = bool(cut_cache[ck][2]) if len(cut_cache[ck]) > 2 else False
                vad_used = get_vad(full_voc[src], vad_cache, band=vb)
            else:
                vad_used = get_vad(full_voc[src], vad_cache)
                nt0, nt1 = refine_cut_points(vad_used["runs"], t0, t1,
                                             vad_used.get("dur"))
                vb = False
                if any(s < nt1 < e for s, e in vad_used["runs"]):
                    # 残留 BGM 盖过阈值 -> 滤到人声频带(250-3400Hz)再找一次停顿
                    vad_b = get_vad(full_voc[src], vad_cache, band=True)
                    if vad_b["runs"]:
                        nb = refine_cut_points(vad_b["runs"], t0, t1,
                                               vad_b.get("dur"))
                        if not any(s < nb[1] < e for s, e in vad_b["runs"]):
                            nt0, nt1, vb = nb[0], nb[1], True
                            vad_used = vad_b
                            print(f"  切点吸附(人声频带): {src} "
                                  f"{t0:.1f}-{t1:.1f}s -> {nt0:.1f}-{nt1:.1f}s")
                cut_cache[ck] = [nt0, nt1, vb]
                cut_dirty = True
                if abs(nt1 - t1) > 0.31 or abs(nt0 - t0) > 0.01:
                    print(f"  切点吸附: {src} {t0:.1f}-{t1:.1f}s -> {nt0:.1f}-{nt1:.1f}s")
            # 延长封顶: 下一句是 CTA 而本段不是 -> 出点停在 CTA 开口之前
            slot = tag.split("-", 1)[0] if "-" in tag else ""
            vid = src[:-4] if src.lower().endswith(".mp4") else src
            lines = raw_lines.get(vid)
            if lines and slot != "CTA" and nt1 > t1 + 0.35:
                nxt_cta = next((tt for tt, txt in lines
                                if tt >= t1 - 0.05 and classify(txt) == "CTA"), None)
                if nxt_cta is not None:
                    cap = round(max(t1 + 0.3, nxt_cta - 0.06), 2)
                    if nt1 > cap:
                        nt1 = cap
                        cut_cache[ck] = [nt0, nt1, vb]
                        segs[i] = (src, nt0, nt1, tag)
                        print(f"  [CTA保护] {src} 出点收敛至 {nt1:.1f}s "
                              f"(下一句是下单话术, 不吸入开头/卖点段)")
            # 封面钳制: 回吸入点落在片头封面区内 -> 推到封面之后
            if min_t0.get(src, 9e9) < 5.5:
                if src not in covers:
                    sp = srcs[src]
                    covers[src] = get_cover_end(
                        sp, hashlib.md5(src.encode("utf-8")).hexdigest()[:12],
                        cover_cache) if os.path.exists(sp) else 0.0
                    try:
                        with open(COVER_JSON, "w", encoding="utf-8") as f:
                            json.dump({"ver": 1, "covers": cover_cache}, f,
                                      ensure_ascii=False)
                    except OSError:
                        pass
                ce = covers[src]
                if ce and nt0 < ce - 0.02:
                    nt0 = round(ce + 0.03, 2)
                    if nt1 - nt0 < 1.5:
                        nt1 = round(nt0 + 1.8, 2)
                    cut_cache[ck] = [nt0, nt1, vb]
                    cut_dirty = True
                    print(f"  [封面钳制] {src} 入点推至 {nt0:.1f}s (避开片头封面)")
            # 帧网格对齐: 切点吸附到 1/30s, 段时长 == 帧数 × 帧长,
            # 视频帧数与音频时长严格相等 (否则每段最多 33ms 的取整误差
            # 会在多段拼接后累积成音画漂移 -> 口型对不上)
            snt0, snt1 = snap_frame(nt0), snap_frame(nt1)
            if snt1 - snt0 < 1.8:
                snt1 = snap_frame(snt0 + 1.8)
            if (snt0, snt1) != (nt0, nt1):
                nt0, nt1 = snt0, snt1
                cut_cache[ck] = [nt0, nt1, vb]
            q_n += 1
            if not any(s < nt1 < e for s, e in vad_used["runs"]):
                q_ok += 1             # 出点落在停顿里 = 语音已收尾
            elif warn_n < 8:
                warn_n += 1
                print(f"  [警告] {src} 出点 {nt1:.1f}s 仍在语音中(源视频可能说到结尾, 建议人工确认)")
            if (nt0, nt1) != (round(t0, 2), round(t1, 2)):
                segs[i] = (src, nt0, nt1, tag)
    with open(cut_file, "w", encoding="utf-8") as f:
        json.dump({"ver": cut_ver, "cuts": cut_cache}, f, ensure_ascii=False)
    with open(VAD_JSON, "w", encoding="utf-8") as f:
        json.dump({"ver": VAD_VER, "videos": vad_cache}, f, ensure_ascii=False)
    print(f"切点质量: {q_ok}/{q_n} 段出点落在停顿处"
          + ("" if q_ok == q_n else " (见上方警告)"))
    # 方案留档: 便于核对每条成片用了哪些分段与切点
    try:
        with open(os.path.join(BUILD, "last_plans.json"), "w", encoding="utf-8") as f:
            json.dump([[dict(src=s, t0=a, t1=b, text=c) for s, a, b, c in segs]
                       for segs in plans], f, ensure_ascii=False, indent=1)
    except OSError:
        pass

    # 旧格式缓存 (seg0.wav / v1_00.mp4 / 指纹文件) 不做删除: 新缓存按内容寻址,
    # 与旧文件互不冲突, 留在磁盘上无害; 需要释放空间可手动清空 build/ 目录

    # ---- 分段人声 = 全片人声按切点切片 (内容寻址, 只切缺失的) ----
    jobs = {}   # key -> (src, t0, t1), 跨方案去重后的全部分段
    for segs in plans:
        for src, t0, t1, _ in segs:
            jobs.setdefault(seg_key(src, t0, t1), (src, t0, t1))
    for key, (src, t0, t1) in sorted(jobs.items()):
        wav = os.path.join(voc, f"{key}.wav")
        if os.path.exists(wav) and os.path.getsize(wav) > 10000:
            continue
        sh([FFMPEG, "-y", "-ss", f"{t0:.2f}", "-to", f"{t1:.2f}", "-i", full_voc[src],
            "-ar", "44100", "-ac", "2", "-c:a", "pcm_s16le", wav])
    print(f"vocals ready ({len(jobs)} 个分段, 取自全片人声)")

    # ---- 分段视频按 (变体, 段内容) 缓存, 拼接出本条的画面轨 ----
    def build_video(variant, segs):
        V = VARIANTS.get(variant, VARIANTS[1])
        seg_files = []
        for i, (src, t0, t1, tag) in enumerate(segs):
            key = seg_key(src, t0, t1)
            # 缓存名带镜像模式: auto 沿用旧缓存, on/off 强制模式各存一份
            suf = "" if mmode == "auto" else f"_{mmode}"
            out = os.path.join(mixdir, f"p5{suf}_v{variant}_{key}.mp4")
            if not os.path.exists(out):
                # 镜像默认关闭(源视频带内嵌字幕, 翻转会反字), 仅显式 --mirror on 开启
                eff_flip = (mmode == "on")
                fl = "hflip," if eff_flip else ""
                if V.get("pip"):
                    # 画中画: 背景取自身放大裁切(虚化或压暗), 主画面缩小叠加
                    P = V["pip"]
                    bgfx = ("gblur=sigma=18," if P.get("bg") == "blur"
                            else "gblur=sigma=8,eq=brightness=-0.22:saturation=0.55,")
                    fc = (f"[0:v]split=2[bg][fg];"
                          f"[bg]scale=1080:1920:force_original_aspect_ratio=increase,"
                          f"crop=1080:1920,{bgfx}{V['eq']},{V['hue']}[bgb];"
                          f"[fg]scale={P['w']}:-2:flags=lanczos,{fl}{V['eq']},{V['hue']}[fgs];"
                          f"[bgb][fgs]overlay=x=(W-w)/2+{P['dx']}:y=(H-h)/2+{P['dy']},"
                          f"fps={FPS},setsar=1[out]")
                    sh([FFMPEG, "-y", "-ss", str(t0), "-to", str(t1), "-i",
                        os.path.join(args.src, src),
                        "-filter_complex", fc, "-map", "[out]", "-an",
                        *venc(19), "-pix_fmt", "yuv420p", out])
                else:
                    vf = (f"{fl}scale={V['scale']}:-2:flags=lanczos,"
                          f"crop=1080:1920:(iw-1080)/2+{V['dx']}:(ih-1920)/2+{V['dy']},"
                          f"{V['eq']},{V['hue']},fps={FPS},setsar=1")
                    sh([FFMPEG, "-y", "-ss", str(t0), "-to", str(t1), "-i",
                        os.path.join(args.src, src),
                        "-vf", vf, "-an", *venc(19), "-pix_fmt", "yuv420p", out])
            seg_files.append(out)
        ins_v = []
        for p in seg_files:
            ins_v += ["-i", p]
        plan_fp = hashlib.md5("|".join(
            f"{variant}:{seg_key(s[0], s[1], s[2])}" for s in segs
        ).encode("utf-8")).hexdigest()[:10]
        # 轻转场: 0.15s 交叉溶解(可选); offset 需要每段真实时长, 用 ffprobe 实测
        xfade_on = (getattr(args, "transition", "none") == "xfade"
                    and len(seg_files) >= 2)
        concat_v = os.path.join(
            mixdir, f"concat_{plan_fp}{'_xf' if xfade_on else ''}.mp4")
        if not os.path.exists(concat_v):
            fc_v = None
            if xfade_on:
                def probe_dur(p):
                    r = subprocess.run(
                        [FFPROBE, "-v", "error", "-show_entries",
                         "format=duration", "-of", "csv=p=0", p],
                        capture_output=True)
                    try:
                        return float((r.stdout or b"").decode().strip())
                    except ValueError:
                        return 0.0
                ds = [probe_dur(p) for p in seg_files]
                if all(d > 0.3 for d in ds):
                    fade = XFADE_D
                    chains, cur, cum = [], "0:v", 0.0
                    for k in range(1, len(seg_files)):
                        cum += ds[k - 1]
                        off = max(0.0, cum - k * fade)
                        lbl = f"x{k}"
                        chains.append(
                            f"[{cur}][{k}:v]xfade=transition=fade:"
                            f"duration={fade}:offset={off:.3f}[{lbl}]")
                        cur = lbl
                    fc_v = ";".join(chains)[:-len(f"[{cur}]")] + "[v]"
                else:
                    xfade_on = False     # 时长探测失败, 回退硬切
            if fc_v is None:
                fc_v = "".join(f"[{k}:v]" for k in range(len(seg_files))) \
                    + f"concat=n={len(seg_files)}:v=1:a=0[v]"
            sh([FFMPEG, "-y", *ins_v, "-filter_complex", fc_v, "-map", "[v]",
                *venc(18), "-pix_fmt", "yuv420p", concat_v])
        # 回传 xfade 是否真的生效: 音频拼接必须用同样的转场时长交叉淡化,
        # 否则视频时间轴比音频短 (n-1)*fade -> 越往后口型越对不上
        return concat_v, xfade_on, XFADE_D

    print("[编码] %s%s" % (enc_tag(),
                          "  (显卡加速已启用)" if enc_tag() != "CPU x264" else ""))
    out_dir = args.out if getattr(args, "out", None) else OUTDIR
    os.makedirs(out_dir, exist_ok=True)
    base_name = args.name or "混剪_成片"
    done = []
    cycle = []   # 批量时 6 套画面参数洗牌轮换

    for n, segs in enumerate(plans):
        total_sec = sum(t1 - t0 for _, t0, t1, _ in segs)
        if count == 1:
            variant = args.variant
        else:
            if not cycle:
                cycle = list(VARIANTS)
                rng.shuffle(cycle)
            variant = cycle[n % len(cycle)]
        print(f"\n========== 第 {n + 1}/{count} 条 (方案{n + 1}, 画面参数{variant}) ==========")
        concat_v, xf_on, xf_d = build_video(variant, segs)

        # ---- 人声拼接 + 逐段响度归一 + 拼接点微淡化 (按本条方案的段落顺序) ----
        keys = [seg_key(src, t0, t1) for src, t0, t1, _ in segs]
        durs = [t1 - t0 for _, t0, t1, _ in segs]
        # 逐段音量测量(缓存): 不同主播录音环境不同, 段间忽大忽小
        vol_file = os.path.join(voc, "seg_volumes.json")
        seg_vols = {}
        if os.path.exists(vol_file):
            try:
                with open(vol_file, encoding="utf-8") as f:
                    seg_vols = json.load(f)
            except (OSError, ValueError):
                seg_vols = {}
        vol_dirty = False
        gains = []
        for key in keys:
            if key in seg_vols:
                mv = seg_vols[key]
            else:
                r = subprocess.run(
                    [FFMPEG, "-hide_banner", "-i", os.path.join(voc, f"{key}.wav"),
                     "-af", "volumedetect", "-vn", "-f", "null", "-"],
                    capture_output=True)
                m_ = re.search(r"mean_volume: (-?[\d.]+) dB",
                               (r.stderr or b"").decode("utf-8", "ignore"))
                mv = float(m_.group(1)) if m_ else -18.0
                seg_vols[key] = mv
                vol_dirty = True
            gains.append(max(-9.0, min(9.0, -18.0 - mv)))
        if vol_dirty:
            with open(vol_file, "w", encoding="utf-8") as f:
                json.dump(seg_vols, f)
        ins_a = []
        for key in keys:
            ins_a += ["-i", os.path.join(voc, f"{key}.wav")]
        # 每段: 增益归一 + 首尾40ms淡化(消掉切点截断的呼吸"噗"声)
        # xfade 模式: 段间用 acrossfade 交叉淡化, 段首尾不再各自淡化
        # (只在整条的头/尾各留一次), 避免与转场叠加出音量凹陷
        nseg = len(keys)
        chains_a = []
        for k, (g, d) in enumerate(zip(gains, durs)):
            parts = [f"[{k}:a]volume={g:+.1f}dB"]
            if (not xf_on) or k == 0:
                parts.append("afade=t=in:st=0:d=0.04")
            if (not xf_on) or k == nseg - 1:
                fo = max(0.0, round(d - 0.04, 2))
                parts.append(f"afade=t=out:st={fo:.2f}:d=0.04")
            chains_a.append(",".join(parts) + f"[n{k}]")
        if xf_on and nseg >= 2:
            # 音视频时间轴严格对齐: 视频每处转场缩短 xf_d, 音频同样交叉淡化。
            # 修 v2.6.9 的音画漂移 (视频 51.1s vs 音频 52.3s -> 口型对不上)
            chain_xf = []
            cur = "n0"
            for k in range(1, nseg):
                lbl = f"xf{k}"
                chain_xf.append(f"[{cur}][n{k}]acrossfade=d={xf_d:.3f}:"
                                f"c1=tri:c2=tri[{lbl}]")
                cur = lbl
            fc_a = ";".join(chains_a) + ";" + ";".join(chain_xf)
            map_a = f"[{cur}]"
        else:
            fc_a = ";".join(chains_a) + ";" \
                + "".join(f"[n{k}]" for k in range(nseg)) \
                + f"concat=n={nseg}:v=0:a=1[a]"
            map_a = "[a]"
        voc_all = os.path.join(voc, f"vocals_all_{n:02d}.wav")
        sh([FFMPEG, "-y", *ins_a, "-filter_complex", fc_a, "-map", map_a,
            "-ar", "44100", "-ac", "2", "-c:a", "pcm_s16le", voc_all])
        voc_eq = os.path.join(voc, f"vocals_eq_{n:02d}.wav")
        sh([FFMPEG, "-y", "-i", voc_all,
            "-af", "highpass=f=80,acompressor=ratio=3:threshold=-20dB:makeup=2,"
                   "loudnorm=I=-15:TP=-1.5",
            "-ar", "44100", "-ac", "2", "-c:a", "pcm_s16le", voc_eq])

        # ---- BGM + 混音 (bgm=none 时只保留人声; random 每条换曲) ----
        bgm_src, bgm_tag = resolve_bgm(args.bgm)
        if bgm_src is None:
            mixed = voc_eq
            print("bgm: none (只保留人声)")
        else:
            bgm_ready = os.path.join(BUILD, f"bgm_ready_{bgm_tag}.wav")
            sh([FFMPEG, "-y", "-stream_loop", "-1", "-i", bgm_src,
                "-t", f"{total_sec:.2f}",
                "-af", f"volume=0.55,afade=t=out:st={max(0, total_sec - 2.5):.2f}:d=2.5",
                "-ar", "44100", "-ac", "2", "-c:a", "pcm_s16le", bgm_ready])
            print("bgm ready:", bgm_tag)
            mixed = os.path.join(voc, f"audio_mix_{bgm_tag}.wav")
            sh([FFMPEG, "-y", "-i", voc_eq, "-i", bgm_ready,
                "-filter_complex",
                "[0:a][1:a]amix=inputs=2:duration=first:weights=1 0.45[a]",
                "-map", "[a]", "-ar", "44100", "-ac", "2", "-c:a", "pcm_s16le",
                mixed])
        print("audio mix ok")

        # ---- B-roll 空镜遮盖切换点 + 贴纸叠加 + 字幕条 + 最终输出 ----
        dur_in = f"{total_sec:.2f}"
        ins = [concat_v]
        chains = []
        v_now = "0:v"

        def add_overlay(png, x, y, enable=None):
            nonlocal v_now
            idx = len(ins)
            ins.append(png)
            lbl = f"ov{idx}"
            cond = f":enable='{enable}'" if enable else ""
            chains.append(f"[{v_now}][{idx}:v]overlay=x={x}:y={y}{cond}[{lbl}]")
            v_now = lbl

        # B-roll 空镜: 在换人切换点用产品空镜盖住画面0.7s (人声延续, J-cut)
        broll_mode = getattr(args, "broll", "auto")
        if broll_mode in ("auto", "on"):
            broll_dir = os.path.join(BUILD, "broll")
            clips = sorted(glob.glob(os.path.join(broll_dir, "*.mp4"))) \
                if os.path.isdir(broll_dir) else []
            if clips:
                broll_cut = os.path.join(BUILD, "broll_cut")
                os.makedirs(broll_cut, exist_ok=True)
                sw = 0.0
                cuts_done = 0
                for si in range(len(segs) - 1):
                    sw += segs[si][2] - segs[si][1]
                    bid = f"b{n}_{si}"
                    bseg = os.path.join(broll_cut, bid + ".mp4")
                    if not os.path.exists(bseg):
                        src_clip = clips[(si + n) % len(clips)]
                        rr = subprocess.run(
                            [FFPROBE, "-v", "error", "-show_entries",
                             "format=duration", "-of", "csv=p=0", src_clip],
                            capture_output=True)
                        try:
                            cd = float((rr.stdout or b"").decode().strip())
                        except ValueError:
                            cd = 0.0
                        start = max(0.0, min(cd - 0.8, rng.uniform(0, max(0.1, cd - 0.8))))
                        sh([FFMPEG, "-y", "-ss", f"{start:.2f}", "-t", "0.7",
                            "-i", src_clip,
                            "-vf", "scale=1080:1920:force_original_aspect_ratio="
                            "increase,crop=1080:1920,fps=30,setsar=1",
                            "-an", *venc(19), "-pix_fmt", "yuv420p", bseg])
                    add_overlay(bseg, "0", "0",
                                f"between(t,{max(0, sw - 0.35):.2f},{sw + 0.35:.2f})")
                    cuts_done += 1
                if cuts_done:
                    print(f"[空镜] {cuts_done} 个切换点已用 B-roll 空镜遮盖 "
                          f"(素材 {len(clips)} 条, 在 build/broll/ 可增补)")
            elif broll_mode == "on":
                print("[空镜] build/broll/ 里没有空镜素材, 跳过; "
                      "把产品特写/安装过程等纯画面短视频放进去即可启用")

        mode = args.sticker
        bubble_t = max(3.0, total_sec * 0.45)   # 气泡贴纸出现时间随片长自适应
        if mode == "zhongqiu":
            tag = os.path.join(STICKER_DIR, "tag_zhongqiu.png")
            bub = os.path.join(STICKER_DIR, "bubble_hengwen.png")
            fish = os.path.join(STICKER_DIR, "fish.png")
            missing = [p for p in (tag, bub, fish) if not os.path.exists(p)]
            if missing:
                print("贴纸缺失, 正在生成...")
                make_stickers()
            add_overlay(tag, "W-w-30", "30")
            add_overlay(bub, "30", "H-h-260", f"between(t,{bubble_t:.1f},{dur_in})")
            add_overlay(fish, "W-w-60", "340", "between(t,0.4,2.9)")
        elif mode == "watermark":
            add_overlay(make_watermark(args.wm_text), "W-w-30", "30")
        elif mode == "universal":
            pngs = ensure_universal_stickers()
            pick = rng.choice(pngs)
            # 每条视频换一张贴纸 + 四个角落轮换, 去重更稳
            pos = [("W-w-30", "30"), ("30", "30"),
                   ("W-w-30", "H-h-330"), ("30", "H-h-330")][n % 4]
            add_overlay(pick, pos[0], pos[1])
        elif mode == "cute":
            pngs = ensure_cute_stickers()
            pick = rng.choice(pngs)
            pos = [("W-w-30", "30"), ("30", "30"),
                   ("W-w-30", "H-h-330"), ("30", "H-h-330")][n % 4]
            add_overlay(pick, pos[0], pos[1])
        elif mode == "ai":
            script_text = " / ".join(
                (tg.split("-", 1)[1] if "-" in tg else tg).replace(" / ", " ")
                for _, _, _, tg in segs)
            txt = ai_pick_sticker_text(script_text, load_llm_cfg())
            col = UNIVERSAL_COLORS[n % len(UNIVERSAL_COLORS)]
            badge = make_badge_sticker(txt, col)
            bpath = os.path.join(STICKER_DIR, "ai_badge_%d.png" % n)
            try:
                os.makedirs(STICKER_DIR, exist_ok=True)
                badge.save(bpath)
            except OSError:
                pass
            add_overlay(bpath, "W-w-30", "30")
        elif mode not in (None, "none") and os.path.exists(mode):
            add_overlay(mode, "W-w-30", "30")

        # 统一品牌字幕条: 底部半透明黑条+白字, 文案跟随每段口播
        # (盖住源视频字幕被切的问题; xfade 模式下时间轴按每转场-0.15s修正)
        if getattr(args, "subtitle", "none") == "brand":
            font = find_font()
            if font:
                font_esc = font.replace("\\", "/").replace(":", r"\:")
                subs_dir = os.path.join(BUILD, "subs_txt")
                os.makedirs(subs_dir, exist_ok=True)
                drift = xf_d if xf_on else 0.0
                t_start = 0.0
                for si, (src, t0, t1, tag) in enumerate(segs):
                    sd = t1 - t0
                    text = (tag.split("-", 1)[1] if "-" in tag else tag)
                    text = text.replace(" / ", " ").strip()
                    if len(text) > 26:          # 超长时在空格处断句, 不切半个词
                        cut = text.rfind(" ", 20, 26)
                        text = text[:cut if cut > 0 else 26]
                    if len(text) >= 2:
                        tf = os.path.join(subs_dir, f"s{n}_{si}.txt")
                        with open(tf, "w", encoding="utf-8") as fp:
                            fp.write(text)
                        tf_esc = tf.replace("\\", "/").replace(":", r"\:")
                        st = max(0.0, t_start - drift * si)
                        en = max(st + 0.5, t_start + sd - drift * si)
                        chains.append(
                            f"[{v_now}]drawtext=fontfile='{font_esc}':"
                            f"textfile='{tf_esc}':fontcolor=white:fontsize=42:"
                            f"box=1:boxcolor=black@0.45:boxborderw=16:"
                            f"x=(w-text_w)/2:y=h-300:"
                            f"enable='between(t,{st:.2f},{en:.2f})'[sb{si}]")
                        v_now = f"sb{si}"
                    t_start += sd
                print("[字幕条] 品牌字幕已叠加 (跟随每段口播)")
            else:
                print("[字幕条] 未找到系统中文字体, 跳过")

        audio_idx = len(ins)
        ins.append(mixed)
        if chains:
            k = chains[-1].rfind("[")
            chains[-1] = chains[-1][:k] + "[v]"
            fc = ";".join(chains)
        else:
            fc = "[0:v]null[v]"

        out_name = (f"{base_name}.mp4" if count == 1
                    else f"{base_name}_{n + 1:02d}.mp4")
        out_path = os.path.join(out_dir, out_name)
        cmd = [FFMPEG, "-y",
               *[x for i in ins for x in ("-i", i)],
               "-filter_complex", fc,
               "-map", "[v]", "-map", f"{audio_idx}:a",
                *venc(18), "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "192k",
               "-movflags", "+faststart", out_path]
        sh(cmd, tail=800)
        print(f"FINAL OK: {out_path}  ({total_sec:.1f}s, 方案{n + 1}, "
              f"画面参数{variant}, BGM={bgm_tag})")
        done.append(out_path)

    print(f"\n批量完成: 共 {len(done)} 条")
    for p in done:
        print("  ", p)
    # 把最后一条的方案写入 segments.json, 供自检/GUI 展示本批实际使用的分段
    if count > 1:
        with open(SEG_JSON, "w", encoding="utf-8") as fp:
            json.dump([list(s) for s in plans[-1]], fp, ensure_ascii=False, indent=2)
    # OCR 回读比对(第一条): 抽帧识别成片字幕, 与方案文案比对
    if done:
        try:
            ocr_readback_check(done[0], plans[0])
        except Exception as e:
            print(f"[回读比对] 跳过: {e}")
    # AI 文案审片(可选): 每条方案交 LLM 评叙事连贯/卖点顺序
    if getattr(args, "polish", "off") == "on" and done:
        try:
            ok_ai, res = ai_review_plans(
                [p for p in history if p],
                load_llm_cfg(),
                out_file=os.path.join(BUILD, "ai_report.txt"))
            if ok_ai and res:
                print(f"[AI审片] {len(res)} 条方案得分偏低(<70), "
                      "建议按报告调整素材或重新生成")
        except Exception as e:
            print(f"[AI审片] 跳过: {e}")
        # AI 成片终审: OCR 提取成片实际字幕全文 -> 找多余字/逻辑混乱/半句,
        # 硬伤段自动拉黑, 下次生成自动避开 (闭环)
        for n_i, out_path in enumerate(done):
            if n_i >= len(plans) or not plans[n_i]:
                continue
            try:
                orig = history[n_i] if n_i < len(history) else None
                ai_review_transcript(out_path, plans[n_i], load_llm_cfg(),
                                     orig_segs=orig)
            except Exception as e:
                print(f"[AI终审] 跳过第{n_i + 1}条: {e}")
    # 自动封面
    if done and getattr(args, "cover", "on") == "on":
        try:
            st_png = None
            if args.sticker == "universal":
                st_png = rng.choice(ensure_universal_stickers())
            elif args.sticker == "zhongqiu":
                st_png = os.path.join(STICKER_DIR, "tag_zhongqiu.png")
            elif args.sticker == "watermark":
                st_png = make_watermark(args.wm_text)
            made = []
            for n_i, out_path in enumerate(done):
                hook = (plans[n_i][0][3].split("-", 1)[1]
                        if "-" in plans[n_i][0][3] else "")
                cj = out_path.replace(".mp4", "_封面.jpg")
                if make_cover(out_path, hook, cj, st_png):
                    made.append(os.path.basename(cj))
            if made:
                print("[封面] 已自动生成: " + ", ".join(made))
        except Exception as e:
            print(f"[封面] 生成失败: {e}")
    run_full_check(done[0] if done else None)


# ================= 贴纸生成 =================
def make_stickers():
    from PIL import Image, ImageDraw, ImageFont
    font = find_font() or "arial.ttf"
    os.makedirs(STICKER_DIR, exist_ok=True)

    # 中秋特惠角标 (360x130 渐变)
    w, h = 360, 130
    img = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    d.rounded_rectangle((6, 16, w - 4, h - 6), radius=26, fill=(0, 0, 0, 70))
    top, bot = (255, 106, 61), (232, 52, 88)
    x0, y0, x1, y1 = 4, 8, w - 8, h - 12
    steps = 60
    for i in range(steps):
        t = i / (steps - 1)
        c = tuple(int(top[k] + (bot[k] - top[k]) * t) for k in range(3)) + (235,)
        yy0 = y0 + (y1 - y0) * i / steps
        yy1 = y0 + (y1 - y0) * (i + 1) / steps
        d.rectangle((x0, yy0, x1, yy1), fill=c)
    d.rounded_rectangle((x0, y0, x1, y1), radius=26, outline=(255, 255, 255, 210), width=4)
    f1 = ImageFont.truetype(font, 56)
    d.text((w // 2 - 4, (h - 20) // 2 - 30), "中秋特惠", font=f1,
           fill=(255, 255, 255, 255), anchor="mm")
    fx, fy = 58, h // 2 - 4
    d.polygon([(fx, fy + 26), (fx - 16, fy + 2), (fx - 6, fy - 12), (fx, fy - 26),
               (fx + 10, fy - 8), (fx + 18, fy + 4), (fx + 12, fy + 26)],
              fill=(255, 214, 90, 255))
    d.polygon([(fx, fy + 24), (fx - 8, fy + 8), (fx + 2, fy - 6), (fx + 8, fy + 8)],
              fill=(255, 244, 200, 255))
    img.save(os.path.join(STICKER_DIR, "tag_zhongqiu.png"))

    # 恒温护鱼气泡
    w2, h2 = 420, 120
    img2 = Image.new("RGBA", (w2, h2), (0, 0, 0, 0))
    d2 = ImageDraw.Draw(img2)
    d2.rounded_rectangle((6, 14, w2 - 6, h2 - 6), radius=30, fill=(0, 0, 0, 60))
    d2.rounded_rectangle((2, 6, w2 - 10, h2 - 12), radius=30, fill=(28, 160, 158, 225))
    d2.rounded_rectangle((2, 6, w2 - 10, h2 - 12), radius=30, outline=(255, 255, 255, 200), width=4)
    f2 = ImageFont.truetype(font, 52)
    d2.text((w2 // 2, (h2 - 10) // 2), "恒温护鱼", font=f2,
            fill=(255, 255, 255, 255), anchor="mm")
    img2.save(os.path.join(STICKER_DIR, "bubble_hengwen.png"))

    # 小鱼印
    img3 = Image.new("RGBA", (160, 160), (0, 0, 0, 0))
    d3 = ImageDraw.Draw(img3)
    d3.ellipse((20, 40, 120, 120), fill=(255, 149, 128, 220))
    d3.polygon([(118, 80), (152, 58), (152, 102)], fill=(255, 149, 128, 220))
    d3.ellipse((44, 62, 60, 78), fill=(255, 255, 255, 255))
    d3.ellipse((48, 66, 58, 76), fill=(40, 40, 40, 255))
    d3.arc((28, 30, 132, 130), 200, 250, fill=(255, 255, 255, 180), width=5)
    img3.save(os.path.join(STICKER_DIR, "fish.png"))
    print("stickers generated")


# 通用带货贴纸: 任意品类都能用的彩色徽章, 批量时每条随机选一张+四角轮换
UNIVERSAL_STICKERS = ("限时特惠", "正品保障", "工厂直发", "好物推荐",
                      "爆款热卖", "亏本冲量", "新品上市", "假一赔十")
UNIVERSAL_COLORS = ((232, 52, 88), (255, 106, 61), (28, 160, 158),
                    (86, 105, 255), (155, 81, 224), (22, 163, 74))


def ensure_universal_stickers():
    """生成(缺失时)并返回通用贴纸 PNG 路径列表"""
    from PIL import Image, ImageDraw, ImageFont
    out = []
    for i, text in enumerate(UNIVERSAL_STICKERS):
        p = os.path.join(STICKER_DIR, f"uni_{text}.png")
        if not os.path.exists(p):
            font = find_font() or "arial.ttf"
            w, h = 340, 104
            img = Image.new("RGBA", (w, h), (0, 0, 0, 0))
            d = ImageDraw.Draw(img)
            c = UNIVERSAL_COLORS[i % len(UNIVERSAL_COLORS)]
            d.rounded_rectangle((6, 14, w - 2, h - 2), radius=28, fill=(0, 0, 0, 60))
            d.rounded_rectangle((2, 4, w - 8, h - 10), radius=28, fill=c + (232,))
            d.rounded_rectangle((2, 4, w - 8, h - 10), radius=28,
                                outline=(255, 255, 255, 215), width=4)
            f1 = ImageFont.truetype(font, 50)
            d.text(((w - 6) // 2, (h - 12) // 2), text, font=f1,
                   fill=(255, 255, 255, 255), anchor="mm")
            img.save(p)
        out.append(p)
    return out


# ================= 子命令: all =================
def cmd_all(args):
    need_ffmpeg()
    ensure_dirs()
    cmd_scan(args)
    with open(VIDEOS_JSON, encoding="utf-8") as f:
        vids = {os.path.splitext(v["name"])[0]: v for v in json.load(f)}
    need_plan = False
    if os.path.exists(SEG_JSON):
        need_plan = False   # 已有分段表直接用
    elif os.path.exists(SUBS_JSON):
        with open(SUBS_JSON, encoding="utf-8") as f:
            subs = json.load(f)
        if any(isinstance(v, dict) and v.get("lines") for v in subs.values()):
            cmd_plan(args)
            need_plan = True
    if not os.path.exists(SEG_JSON):
        print("缺少 data/segments.json — 请先填好 subtitles.json 后运行 plan, 或手工提供分段表")
        sys.exit(1)
    cmd_audio(args)
    cmd_sep(args)
    cmd_mix(args)


# ================= 入口 =================
def cmd_fetchassets(args):
    """联网获取可商用素材(BGM/贴纸)到本地曲库/贴纸目录"""
    ensure_dirs()
    fetch_online_assets()


def main():
    # 多项目支持: 项目工作目录是刚新建出来的, 里面还没有 data/ , 这里兜底创建。
    # 否则 scan/subs/plan 往 data/*.json 写会 FileNotFoundError
    # (新建项目第一次出片必踩: 第 1 步"扫描视频"就失败)
    try:
        os.makedirs(DATA, exist_ok=True)
        os.makedirs(OUTDIR, exist_ok=True)
    except OSError as e:
        print("错误: 无法创建数据目录: %s" % DATA)
        print("      %s" % e)
        print("提示: 请确认项目目录所在磁盘可写, 或换一个导出目录")
        sys.exit(1)

    ap = argparse.ArgumentParser(prog="VideoMixCut",
                                 description="带货视频智能混剪工具",
                                 formatter_class=argparse.RawDescriptionHelpFormatter,
                                 epilog=__doc__)
    sub = ap.add_subparsers(dest="cmd", required=True)

    p = sub.add_parser("scan", help="扫描视频目录")
    p.add_argument("--src", required=True)
    p.set_defaults(func=cmd_scan)

    p = sub.add_parser("subs", help="生成字幕模板")
    p.add_argument("--src", required=True)
    p.set_defaults(func=cmd_subs)

    sub.add_parser("plan", help="文案分析自动拼装分段表").set_defaults(func=cmd_plan)

    p = sub.add_parser("audio", help="抽取分段音频")
    p.add_argument("--src", required=True)
    p.set_defaults(func=cmd_audio)

    sub.add_parser("sep", help="demucs 人声分离").set_defaults(func=cmd_sep)

    p = sub.add_parser("mix", help="混剪合成出片")
    p.add_argument("--src", required=True)
    p.add_argument("--bgm", default="synth")
    p.add_argument("--variant", type=int, default=1,
                   help="画面参数套数 1-9 (批量出片时自动随机轮换, 此项仅单条生效)")
    p.add_argument("--sticker", default="zhongqiu")
    p.add_argument("--wm-text", dest="wm_text", default="正品好物")
    p.add_argument("--name", default=None)
    p.add_argument("--out", default=None, help="导出目录 (默认 output/)")
    p.add_argument("--count", type=int, default=1,
                   help="批量出片数量: 每条独立随机方案(分段/顺序/文案不同)+随机画面参数")
    p.add_argument("--only-cached", dest="only_cached", action="store_true",
                   help="只用人声已分离的视频出片 (不触发 demucs, 快速预览)")
    p.add_argument("--encoder", default="auto", choices=["auto", "gpu", "cpu"],
                   help="编码器: auto=有N卡就用显卡(默认), gpu=强制显卡, cpu=只用CPU")
    p.add_argument("--mirror", default="auto", choices=["auto", "on", "off"],
                   help="画面镜像: auto=不镜像(默认, 内嵌字幕不反字), on=全部镜像, off=同auto")
    p.add_argument("--duration", type=int, default=0, choices=[0, 30, 45, 60],
                   help="目标时长: 30/45/60秒(收缩槽位结构), 0=自动完整结构(批量生效)")
    p.add_argument("--transition", default="none", choices=["none", "xfade"],
                   help="段间转场: none=硬切(默认), xfade=0.15秒柔和溶解")
    p.add_argument("--voice", default="auto", choices=["auto", "same", "alternate"],
                   help="音色策略: auto=随机 / same=同条尽量同一主播 / alternate=每段换主播")
    p.add_argument("--flow", default="off", choices=["off", "on"],
                   help="过渡句: on=在话题切换处插入转场口播(再来看/接下来...)")
    p.add_argument("--broll", default="auto", choices=["auto", "on", "off"],
                   help="B-roll空镜: 切换点用产品空镜盖住0.7秒(素材放 build/broll/)")
    p.add_argument("--subtitle", default="none", choices=["none", "brand"],
                   help="统一字幕条: brand=底部黑条白字跟随口播(盖住源字幕错位)")
    p.add_argument("--polish", default="off", choices=["off", "on"],
                   help="AI审片: on=方案评审+成片终审(OCR全文找多余字/逻辑混乱), 硬伤段自动拉黑")
    p.add_argument("--ai-plan", dest="ai_plan", default="off", choices=["off", "on"],
                   help="AI选段: on=由AI从候选素材里组合方案(叙事更连贯), 失败自动回退规则选段")
    p.add_argument("--cover", default="on", choices=["on", "off"],
                   help="自动封面: 出片后生成带钩子标题的封面图")
    p.set_defaults(func=cmd_mix)

    p = sub.add_parser("all", help="一键全流程")
    p.add_argument("--src", required=True)
    p.add_argument("--bgm", default="synth")
    p.add_argument("--variant", type=int, default=1,
                   help="画面参数套数 1-9 (批量出片时自动随机轮换, 此项仅单条生效)")
    p.add_argument("--sticker", default="zhongqiu")
    p.add_argument("--wm-text", dest="wm_text", default="正品好物")
    p.add_argument("--name", default=None)
    p.add_argument("--out", default=None, help="导出目录 (默认 output/)")
    p.add_argument("--count", type=int, default=1,
                   help="批量出片数量: 每条独立随机方案(分段/顺序/文案不同)+随机画面参数")
    p.add_argument("--mirror", default="auto", choices=["auto", "on", "off"],
                   help="画面镜像: auto=不镜像(默认, 内嵌字幕不反字), on=全部镜像, off=同auto")
    p.add_argument("--duration", type=int, default=0, choices=[0, 30, 45, 60],
                   help="目标时长: 30/45/60秒(收缩槽位结构), 0=自动完整结构")
    p.add_argument("--transition", default="none", choices=["none", "xfade"],
                   help="段间转场: none=硬切(默认), xfade=0.15秒柔和溶解")
    p.set_defaults(func=cmd_all)

    sub.add_parser("selfcheck",
                   help="完整自检: 文案(重复/截断) + 画面(黑屏/卡帧) + 音频(静音/爆音)"
                   ).set_defaults(func=run_full_check)

    sub.add_parser("bgm", help="查看 BGM 曲库").set_defaults(func=lambda a: resolve_bgm("list"))

    sub.add_parser("library",
                   help="拆分素材库: 开头钩子/中间卖点/结尾号召 -> data/clip_library.json"
                   ).set_defaults(func=cmd_library)

    sub.add_parser("ailib",
                   help="AI 优化素材库: 评审库归属+质量分, 结果缓存后出片自动生效"
                   ).set_defaults(func=lambda a: ai_optimize_library())

    pg = sub.add_parser("grab",
                        help="链接提取: 无水印视频下载 (+文案提取), 单链接或txt批量")
    pg.add_argument("url_or_txt", help="分享链接 或 包含链接的txt文件")
    pg.add_argument("--out", default=None, help="保存目录 (默认 output/)")
    pg.add_argument("--name", default="{index}_{title}",
                    help="文件名模板: {title} {author} {index} {id} {date}")
    pg.add_argument("--engine", default="auto", choices=["auto", "douyin", "ytdlp"])
    pg.add_argument("--text", action="store_true", help="同时提取口播文案(OCR字幕)")
    pg.add_argument("--cookie", default="", help="抖音Cookie(风控时兜底)")
    pg.add_argument("--retry", type=int, default=2)
    pg.add_argument("--redo", action="store_true", help="忽略已提取记录强制重下")
    pg.set_defaults(func=cmd_grab)

    sub.add_parser("stickers", help="重新生成贴纸").set_defaults(
        func=lambda a: make_stickers())

    sub.add_parser("fetchassets",
                   help="联网获取可商用素材(BGM/贴纸)到本地曲库").set_defaults(
        func=cmd_fetchassets)

    # 硬件体检: 界面开机自检用, 每台电脑配置不同 -> 自动选最优编码方案
    def cmd_hwinfo(a):
        d = detect_hw(refresh=getattr(a, "refresh", False))
        print(json.dumps(d, ensure_ascii=False))
        print("本机: " + hw_note())

    p = sub.add_parser("hwinfo", help="打印本机硬件体检结果")
    p.add_argument("--refresh", action="store_true", help="重新检测(忽略缓存)")
    p.set_defaults(func=cmd_hwinfo)

    # 激活 (客户入口, 供界面/命令行调用)
    def cmd_activate(a):
        if a.show:
            print(activation.machine_code())
            return
        if not a.code:
            print("机器码: " + activation.machine_code())
            print("请用: activate --code XXXX-XXXXX-XXXXX-XXXXX 激活")
            return
        ok, msg = activation.write_license(activation.machine_code(), a.code)
        print(msg)
        sys.exit(0 if ok else 3)

    p = sub.add_parser("activate", help="软件激活")
    p.add_argument("--show", action="store_true", help="显示本机机器码")
    p.add_argument("--code", default=None, help="输入激活码")
    p.set_defaults(func=cmd_activate)

    args = ap.parse_args()
    # 编码器选择 (界面/命令行都可指定 auto/gpu/cpu)
    global ENC_MODE
    if getattr(args, "encoder", None):
        ENC_MODE = args.encoder
    # ---- 激活门禁: activate 自身放行, 其余命令需已激活 ----
    if args.func is not cmd_activate:
        ok, info = activation.verify_license()
        if not ok:
            print("=" * 46)
            print(" 软件未激活: " + info.get("reason", ""))
            print(" 本机机器码: " + activation.machine_code())
            print(" 请联系卖家获取激活码后在软件界面激活")
            print("=" * 46)
            sys.exit(3)
    args.func(args)


if __name__ == "__main__":
    main()
